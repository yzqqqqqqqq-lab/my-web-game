# Spark Analytics SDK 开发者指南 (v1.0.0)

> 📚 [[spark-analytics-sdk]数据采集与多级脱敏上报流程详解](./%5Bspark-analytics-sdk%5D数据采集与多级脱敏上报流程详解.md)

> **专为 H5/PWA 应用打造的高级分析与归因套件。**
> 集自归因、加密埋点、跨端识别于一体，助力开发者快速构建稳健的数据采集体系。

---

## 快速导航

- [安装方式](#install)
- [运行逻辑](#logic)
- [快速开始](#start)
- [配置详解](#config)
- [API 参考](#api)
- [便捷追踪](#convenience)
- [归因模型](#attribution)
- [相关文档](#docs)

---

## <span id="install">安装方式</span>

```javascript
import TrackingSDK from 'spark-analytics-sdk';
```

### Script Tag (UMD)

适用于传统 HTML 页面。

```html
<script src="/path/to/spark-analytics-sdk.umd.js"></script>
<script>
    // 全局变量 TrackingSDK 自动挂载
    console.log(TrackingSDK);
</script>
```

---

## <span id="logic">运行逻辑</span>

Spark SDK 采用 **Client-Side Self-Attribution (客户端自归因)** 模式。

1. **捕获**: 自动扫描 URL 中的广告参数 (如 `gclid`, `utm_source`, `qid`)。
2. **锁定**: 参数存入持久化存储 (First Touch)。
3. **清洗**: URL 自动清洗，移除敏感参数。
4. **同步**: 归因数据自动同步至服务器，实现账号绑定。

## 🏢 架构设计

```mermaid
graph TD
    subgraph "输入层 (Intake)"
        URL[URL 参数扫描]
        UA[User-Agent 解析]
        BF[浏览器指纹 BrowserUUID]
    end

    subgraph "核心逻辑层 (Core)"
        AM[归因管理器 AttributionManager]
        EM[事件管理器 EventManager]
        SM[存储管理器 StorageManager]
    end

    subgraph "安全层 (Security)"
        ENC[指纹/正文 AES 加密]
        HASH[敏感字段 SHA256 哈希]
    end

    subgraph "输出层 (Sink)"
        DL[dataLayer/GTM 同步]
        API[持久化后端 API]
    end

    URL --> AM
    UA --> BF
    BF --> AM
    AM --> SM
    EM --> HASH
    HASH --> ENC
    ENC --> API
    EM --> DL
```

### 关键架构组件

1.  **归因管理器 (First Touch Engine)**: 采用“写后即锁”策略。一旦在本地检测到有效的 `qid`
    或广告参数，即刻冻结状态，后续的参数变更不会覆盖原始来源，确保推广效果统计的公正性。
2.  **双指纹识别系统**: 同时生成 `uuid` (持久化 ID) 和 `browser_uuid`
    (基于 Canvas 和 WebGL 的非持久化指纹)，即使在无 Cookie 环境下也能保持 95% 以上的用户识别率。
3.  **多级加密管道**: 事件上报前会经过 `SHA256`（脱敏） + `AES-CBC`（正文加密）+ `RSA`（动态密钥交换，可选）的三重保护。
4.  **同步队列**: 内置 Retry 机制。当网络环境极差时，事件会暂存在 IndexedDB 中，并在网络恢复后以时间戳对齐的方式进行批量重发。

---

## <span id="start">快速开始</span>

在应用入口文件 (如 `main.ts`, `App.js`) 调用 `init`：

```javascript
await TrackingSDK.init({
    debug: true, // 开启调试日志
    versionName: '1.0',
    versionCode: 100,
});
```

---

## <span id="config">配置详解</span>

初始化 `init(config)` 支持的配置项：

| 参数          | 类型      | 必填 | 默认    | 说明                         |
| :------------ | :-------- | :--- | :------ | :--------------------------- |
| `debug`       | `boolean` | 否   | `false` | 是否在控制台打印详细调试日志 |
| `versionName` | `string`  | 否   | -       | 应用展示版本号 (如 "1.0.0")  |
| `versionCode` | `number`  | 否   | -       | 应用内部版本代码 (如 100)    |

---

## <span id="api">API 参考</span>

### 核心功能

#### `track(eventName, properties)`

发送自定义事件。

- `eventName`: 事件名称 (string)
- `properties`: 事件属性 (object)

```javascript
TrackingSDK.track('level_complete', {
    level: 5,
    score: 1200,
});
```

#### `setUserId(userId)`

设置用户 ID。**登录或注册成功后必须调用**。调用后会立即触发一次归因同步，将设备归因信息与该 UserID 绑定。

```javascript
await TrackingSDK.setUserId('u_123456');
```

### 数据获取

#### `getAttribution()`

获取当前锁定的归因数据对象。

```javascript
const attr = TrackingSDK.getAttribution();
if (attr) {
    console.log('Source:', attr.source);
    console.log('QID:', attr.qid);
}
```

#### `getEncryptedAttribution()`

获取经过加密处理的归因数据。返回包含 `attribution_data`
字段的对象，值为加密字符串。通常用于需要直接传输加密归因数据的场景。

```javascript
const result = TrackingSDK.getEncryptedAttribution();
// { attribution_data: "U2FsdGVkX1..." }
console.log(result.attribution_data);
```

#### `getDeviceInfo()`

获取 SDK 采集的设备信息快照。

```javascript
const device = TrackingSDK.getDeviceInfo();
console.log(device.uuid); // 设备唯一标识
console.log(device.browserUUID); // 浏览器指纹 ID
console.log(device.osType); // 操作系统
```

#### `getBasic()`

获取 SDK 的基础上下文信息，用于构建 HTTP 请求头。返回包含设备、归因、应用版本等核心字段的对象。

**用途**：为业务 API 请求提供统一的 Header 信息。

**返回值**：包含以下关键字段的对象：

- `uuid`: 设备唯一标识
- `browser_uuid`: 浏览器指纹 ID
- `session_id`: 会话 ID
- `userId` / `user_id`: 用户 ID（登录后）
- `package_name`: 应用包名
- `version_code` / `version_name`: 应用版本信息
- `product_id`: 产品 ID
- `os`: 操作系统类型（1=Android, 2=iOS）
- `os_version`: 操作系统版本
- `country`: 国家代码
- `media_source`: 归因来源
- `h5_channel_qid`: 渠道 QID
- `abtest`: AB 测试标识
- 以及其他设备和归因相关字段

**示例**：

```javascript
const basicInfo = TrackingSDK.getBasic();
```

---

## <span id="convenience">便捷追踪</span>

针对常用关键行为的语义化封装方法。会自动处理敏感字段哈希。

| 方法                      | 对应事件                | 参数说明                                      |
| :------------------------ | :---------------------- | :-------------------------------------------- |
| `pushSignup(data)`        | `registration_complete` | `{ user_email, method }`                      |
| `pushPurchase(data)`      | `purchase_complete`     | `{ order_id, purchase_value, currency, ... }` |
| `pushFirstPurchase(data)` | `first_purchase`        | 同 `pushPurchase`                             |
| `pushClickSignup(data)`   | `click_sign_button`     | `{ location }`                                |
| `pushClickBuy(data)`      | `iap_page_click`        | `{ location, purchase_value }`                |

### 如何测试验证

为确保便捷追踪功能正常工作，建议从以下三个维度进行验证：

#### 1. 控制台日志验证 (SDK Debug)

在 `init` 时开启 `debug: true`。在控制台 (Console) 会看到类似如下的日志：

```text
[SDK] Track: registration_complete { "user_email": "e6***...", "method": "email" }
```

> [!TIP] 检查敏感字段（如 `user_email`）是否已被正确哈希（SHA256）。

#### 2. GTM 容器验证 (dataLayer)

在控制台输入 `dataLayer` 并展开，检查最近的事件对象：

- 事件名应为 `gg_event`。
- `event_name` 应为对应的语义化名称（如 `signup`）。
- 包含所有传入的扩展属性。

#### 3. 网络请求验证 (Post Payload)

在 Network 面板中寻找上报路径（如 `/collect/encrypt`）：

- 检查 `Post Data` 是否存在。
- 若环境支持，解密后验证 `eventName` 和 `properties` 是否完整。

---

## <span id="attribution">归因模型</span>

### 首次触点锁定 (First Touch)

SDK 严格遵循“首次胜出”原则。即用户的第一次带参访问决定了其归因来源。

### 支持的参数

SDK 会按照优先级自动识别以下 URL 参数作为归因依据：

1. **自定义渠道**: `qid` (最高优先级)
2. **广告参数**: `gclid`, `fbclid`, `ttclid`
3. **UTM 参数**: `utm_source`, `utm_medium`, `utm_campaign` 等
4. **其他**: `aff_id`, `sub1` - `sub5`

### URL 清洗

识别并向本地存储写入归因数据后，SDK 会自动使用 `history.replaceState`
清除 URL 中的上述参数，保持地址栏整洁，避免用户分享链接时导致归因污染。

---

## TypeScript 支持

SDK 内置了完整的 TypeScript 定义文件 (`.d.ts`)。主要类型导出：

- `TrackingSDK` (Class)
- `SDKConfig` (Interface)
- `TrackEvent` (Interface)
- `AttributionData` (Interface)

---

## <span id="docs">相关文档</span>

- [集成指南](INTEGRATION.md) - 详细的协议说明与后端对接指南
- [构建指南](BUILD.md) - 源码编译与打包说明
- [测试指南](TESTING.md) - 单元测试与 E2E 测试指南
- [架构说明](ARCHITECTURE.md)

---

© 2025 Spark Team.
