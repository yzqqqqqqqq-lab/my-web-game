# @iap/kit-http 使用指南

## 📋 概述

`@iap/kit-http` 是一个统一的 HTTP 请求管理库，支持多种请求库（alova、axios、ky、swr），提供统一的请求接口、自动加解密、错误处理、性能监控等功能。

## ✨ 核心特性

- 🔄 **多请求库支持** - 支持 alova、axios、ky、swr，可动态切换
- 🔐 **自动加解密** - 支持 RSA（混合 AES+RSA）、none、Binary 三种加密类型
- 🛡️ **统一错误处理** - 集中管理业务错误码和错误提示
- ⚡ **性能监控** - 自动记录请求耗时，便于性能分析
- 🚦 **请求节流** - 防止短时间内重复请求
- 📦 **请求拦截** - 支持请求前/响应后拦截器
- 🎯 **TypeScript 支持** - 完整的类型定义

## 📦 安装

```bash
npm install @iap/kit-http
# 或
pnpm add @iap/kit-http
```

## 🚀 快速开始

### 1. 初始化 Http 实例

```typescript
import Http from '@iap/kit-http';
import type { HttpConfig, HttpResponse } from '@iap/kit-http';

// 创建 Http 实例
const http = new Http({
  baseUrl: '/api',                    // 基础 URL
  encryptionType: 'RSA',              // 加密类型：'RSA' | 'none' | 'Binary'
  httpLib: 'alova',                   // 请求库：'alova' | 'axios' | 'ky' | 'swr'
  headerBasic: {                      // 基础请求头信息
    deviceId: 'xxx',
    version: '1.0.0',
  },
  errorHandler: (data, config) => {
    // 错误处理函数（必须返回处理后的数据）
    // data: 响应数据（可能包含错误码）
    // config: 请求配置
    
    // 示例：根据错误码处理
    if (data.code !== 200) {
      console.error('请求错误:', data.message);
      // 可以在这里显示错误提示、跳转登录页等
    }
    
    // 【重要】必须返回数据，不能返回 undefined
    return data;
  },
});
```

### 2. 发起请求

```typescript
// GET 请求
const response = await http.comRequest<UserInfo>({
  url: '/user/info',
  method: 'GET',
});

// POST 请求
const response = await http.comRequest<LoginResult>({
  url: '/user/login',
  method: 'POST',
  body: {
    username: 'admin',
    password: '123456',
  },
});

// 带自定义配置的请求
const response = await http.comRequest<Data>({
  url: '/api/data',
  method: 'POST',
  body: { key: 'value' },
  headers: {
    'X-Custom-Header': 'custom-value',
  },
  timeout: 5000,                      // 超时时间（毫秒）
  encryptionType: 'RSA',              // 本次请求的加密类型（覆盖全局）
  isToken: true,                      // 是否携带 Token
  isBasic: true,                      // 是否添加基础头信息
});
```

### 3. 错误处理

```typescript
// 定义错误处理器
const errorHandler = (data: any, config: HttpConfig) => {
  // data: 后端返回的响应数据
  // config: 请求配置
  
  if (data.code === 401) {
    // 未登录，跳转到登录页
    window.location.href = '/login';
    return data;
  }
  
  if (data.code === 403) {
    // 无权限，显示提示
    if (config.isSerErrTips) {
      alert('无权限访问');
    }
    return data;
  }
  
  // 其他错误码处理...
  return data;
};

// 初始化时设置错误处理器
const http = new Http({
  // ... 其他配置
  errorHandler: (data, config) => {
    // data: 响应数据
    // config: 请求配置
    
    // 处理业务错误码
    if (data.code === 401) {
      // 未登录，跳转登录页
      window.location.href = '/login';
    } else if (data.code === 500) {
      // 服务器错误
      console.error('服务器错误:', data.message);
    }
    
    // 必须返回数据
    return data;
  },
});
```

## 📖 API 文档

### Http 类

#### 构造函数

```typescript
new Http(props: HttpProps)
```

**参数说明：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `baseUrl` | `string` | 否 | 基础 URL，默认 `'/api'` |
| `encryptionType` | `'RSA' \| 'none' \| 'Binary'` | 否 | 加密类型，默认 `'RSA'` |
| `httpLib` | `'alova' \| 'axios' \| 'ky' \| 'swr'` | 否 | 请求库，默认 `'alova'` |
| `headerBasic` | `Record<string, any>` | 是 | 基础请求头信息 |
| `errorHandler` | `(data: any, config: HttpConfig) => any` | 是 | 错误处理函数，**必须返回处理后的数据** |

#### 方法

##### `comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>>`

发起 HTTP 请求。

**参数：**

```typescript
interface HttpConfig {
  url: string;                       // 请求路径（必填）
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';  // 请求方法，默认 'GET'
  baseUrl?: string;                   // 基础 URL（覆盖全局）
  headers?: Record<string, string>;  // 自定义请求头
  body?: any;                        // 请求体
  timeout?: number;                  // 超时时间（毫秒），默认 10000
  retry?: number;                    // 重试次数，默认 0
  retryDelay?: number;               // 重试间隔（毫秒），默认 1000
  signal?: AbortSignal;              // 请求中断信号
  isToken?: boolean;                 // 是否携带 Token，默认 true
  isMergeBody?: boolean;             // 是否合并默认请求体，默认 true
  isBasic?: boolean;                 // 是否添加基础头信息，默认 true
  isForce?: boolean;                 // 是否强制请求，默认 false
  isSerErrTips?: boolean;            // 是否显示服务端错误提示，默认 true
  encryptionType?: 'RSA' | 'none' | 'Binary';  // 加密类型（覆盖全局）
  throttle?: number;                 // 节流时间（毫秒）
  requestCount?: number;             // 请求次数限制，默认 1
  options?: {
    setLoading?: (loading: boolean) => void;  // Loading 状态控制
  };
}
```

**返回值：**

```typescript
interface HttpResponse<T> {
  code: number;        // 业务状态码
  message: string;      // 业务消息
  data: T;             // 响应数据（泛型）
  etag: string;        // 缓存标识
  description: string; // 错误详细描述
  timestamp: number;   // 响应时间戳
  status?: string;     // 响应状态
}
```

##### `setInterceptor(config: IInterceptor): void`

设置拦截器（主要用于 alova 库）。

```typescript
http.setInterceptor({
  errorInterceptor: (error, method) => {
    // 自定义错误拦截逻辑
    console.error('请求错误:', error);
  },
});
```

##### `setHeaderBasic(basic: Record<string, any>): void`

更新基础请求头信息。

```typescript
http.setHeaderBasic({
  deviceId: 'new-device-id',
  version: '2.0.0',
});
```

## 🔐 加密配置

### 默认加密方式

`kit-http` 使用 `@iap/kit-encryptor` 进行加密，支持三种加密类型：

1. **RSA**（默认）- 混合加密（AES + RSA）
   - 使用 AES 加密请求数据
   - 使用 RSA 加密 AES 的 IV（初始化向量）
   - 生成 MD5 签名防篡改
   - 支持 gzip 压缩

2. **none** - 不加密
   - 开发环境默认，便于调试
   - 请求体直接序列化为 JSON

3. **Binary** - 二进制加密
   - 适用于文件、流等二进制数据
   - 请求体原样返回，不序列化

### 配置加密参数

通过配置 `@iap/kit-encryptor` 的全局配置来修改加密参数：

```typescript
import { encryptConfigure } from '@iap/kit-encryptor';

// 在应用启动时配置加密参数
encryptConfigure({
  isEncrypted: true,
  SIGN_KEY: 'your-sign-key',        // 签名密钥
  DATA_KEY: 'your-data-key',        // 数据加密密钥
  RSA_KEY: 'your-rsa-public-key',   // RSA 公钥（PEM 格式）
  AES_KEY_WEB: 'your-aes-key',      // AES Web 版本密钥（16 字符）
  AES_IV_WEB: 'your-aes-iv',        // AES Web 版本初始化向量（16 字符）
});
```

### 自定义加解密逻辑

如果需要完全自定义加解密逻辑，有以下几种方式：

#### 方式一：修改源码（不推荐）

直接修改 `packages/kit-http/src/utils/httpUtils.ts` 中的 `encryptRequestBody` 和 `decryptResponseData` 函数。

#### 方式二：扩展 Http 类（推荐）

创建一个扩展类，重写加解密逻辑：

```typescript
import Http from '@iap/kit-http';
import type { HttpConfig, HttpResponse } from '@iap/kit-http';

class CustomHttp extends Http {
  // 重写 comRequest 方法，在请求前自定义加密逻辑
  async comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 自定义加密逻辑
    if (config.encryptionType === 'RSA') {
      // 使用自定义加密方法
      const customEncryptedBody = this.customEncrypt(config.body);
      config.body = customEncryptedBody;
    }
    
    // 调用父类方法
    return super.comRequest<T>(config);
  }
  
  // 自定义加密方法
  private customEncrypt(body: any): string {
    // 实现你的加密逻辑
    // 例如：使用不同的加密算法、密钥等
    return JSON.stringify(body); // 示例
  }
  
  // 自定义解密方法（需要在响应拦截器中调用）
  private customDecrypt(encryptedData: string): any {
    // 实现你的解密逻辑
    return JSON.parse(encryptedData); // 示例
  }
}

// 使用自定义 Http 类
const http = new CustomHttp({
  // ... 配置
});
```

#### 方式三：使用拦截器（适用于 alova）

如果使用 alova 作为请求库，可以通过拦截器自定义加解密：

```typescript
import Http from '@iap/kit-http';
import { alovaInstance } from '@iap/kit-http/src/comRequest-alova';

// 设置请求拦截器
alovaInstance.beforeRequest((method) => {
  const httpConfig = (method as any).httpConfig;
  
  // 自定义加密逻辑
  if (httpConfig.encryptionType === 'RSA') {
    const customEncrypted = yourCustomEncrypt(method.data);
    method.data = customEncrypted;
  }
});

// 设置响应拦截器
alovaInstance.responded.onSuccess((response, method) => {
  return response.json().then((data) => {
    const httpConfig = (method as any).httpConfig;
    
    // 自定义解密逻辑
    if (httpConfig.encryptionType === 'RSA') {
      return yourCustomDecrypt(data);
    }
    return data;
  });
});
```

#### 方式四：创建自定义请求函数（最灵活）

完全自定义请求函数，不依赖 `kit-http` 的加解密逻辑：

```typescript
import type { HttpConfig, HttpResponse } from '@iap/kit-http';

async function customRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
  // 1. 构建请求体
  let requestBody = config.body;
  
  // 2. 自定义加密
  if (config.encryptionType === 'RSA') {
    requestBody = await yourEncryptFunction(requestBody);
  }
  
  // 3. 发起请求（使用 fetch 或其他库）
  const response = await fetch(`${config.baseUrl}${config.url}`, {
    method: config.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...config.headers,
    },
    body: requestBody ? JSON.stringify(requestBody) : undefined,
  });
  
  // 4. 解析响应
  let responseData = await response.json();
  
  // 5. 自定义解密
  if (config.encryptionType === 'RSA') {
    responseData = await yourDecryptFunction(responseData);
  }
  
  // 6. 返回标准化响应
  return responseData as HttpResponse<T>;
}

// 使用
const result = await customRequest<UserInfo>({
  url: '/user/info',
  method: 'GET',
  encryptionType: 'RSA',
});
```

### 初始化自定义加解密的完整示例

```typescript
import Http from '@iap/kit-http';
import { encryptConfigure } from '@iap/kit-encryptor';

// 1. 配置加密器（可选，如果使用默认加密）
encryptConfigure({
  SIGN_KEY: process.env.SIGN_KEY!,
  RSA_KEY: process.env.RSA_PUBLIC_KEY!,
  AES_KEY_WEB: process.env.AES_KEY_WEB!,
  AES_IV_WEB: process.env.AES_IV_WEB!,
});

// 2. 创建自定义 Http 实例
class MyCustomHttp extends Http {
  async comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 在请求前处理
    if (config.encryptionType === 'RSA') {
      // 使用自定义加密
      config.body = this.myEncrypt(config.body);
    }
    
    // 调用父类方法
    const response = await super.comRequest<T>(config);
    
    // 在响应后处理
    if (config.encryptionType === 'RSA') {
      // 使用自定义解密
      response.data = this.myDecrypt(response.data);
    }
    
    return response;
  }
  
  private myEncrypt(data: any): string {
    // 实现你的加密逻辑
    // 例如：调用第三方加密库、使用不同的密钥等
    return JSON.stringify(data);
  }
  
  private myDecrypt(encrypted: any): any {
    // 实现你的解密逻辑
    return encrypted;
  }
}

// 3. 初始化 Http 实例
const http = new MyCustomHttp({
  baseUrl: '/api',
  encryptionType: 'RSA',
  httpLib: 'alova',
  headerBasic: {
    deviceId: 'xxx',
  },
  errorHandler: (data, config) => {
    // 错误处理逻辑
    if (data.code !== 200) {
      console.error('请求错误:', data.message);
    }
    return data; // 必须返回数据
  },
});

// 4. 使用
const result = await http.comRequest<UserInfo>({
  url: '/user/info',
  method: 'GET',
});
```

## 🎯 使用场景示例

### 场景一：登录请求

```typescript
const loginResponse = await http.comRequest<LoginResult>({
  url: '/user/login',
  method: 'POST',
  body: {
    username: 'admin',
    password: '123456',
  },
  encryptionType: 'RSA',  // 登录接口使用 RSA 加密
  isToken: false,          // 登录接口不携带 Token
});

if (loginResponse.code === 200) {
  // 登录成功，保存 Token
  localStorage.setItem('Admin-Token', loginResponse.data.token);
}
```

### 场景二：文件上传

```typescript
const file = document.querySelector('input[type="file"]').files[0];

const uploadResponse = await http.comRequest<UploadResult>({
  url: '/upload/file',
  method: 'POST',
  body: file,
  encryptionType: 'Binary',  // 文件使用 Binary 类型
  headers: {
    'Content-Type': file.type,
  },
});
```

### 场景三：带 Loading 的请求

```typescript
import { useState } from 'react';

function MyComponent() {
  const [loading, setLoading] = useState(false);
  
  const fetchData = async () => {
    const response = await http.comRequest<Data>({
      url: '/api/data',
      method: 'GET',
      options: {
        setLoading: setLoading,  // 自动控制 Loading 状态
      },
    });
    
    return response.data;
  };
  
  return (
    <div>
      {loading && <div>加载中...</div>}
      <button onClick={fetchData}>获取数据</button>
    </div>
  );
}
```

### 场景四：请求节流

```typescript
// 防止用户快速点击提交按钮
const submitForm = async () => {
  const response = await http.comRequest<SubmitResult>({
    url: '/form/submit',
    method: 'POST',
    body: formData,
    throttle: 1000,  // 1 秒内只能请求一次
  });
};
```

### 场景五：请求重试

```typescript
// 网络不稳定时自动重试
const fetchData = async () => {
  const response = await http.comRequest<Data>({
    url: '/api/data',
    method: 'GET',
    retry: 3,        // 最多重试 3 次
    retryDelay: 1000, // 每次重试间隔 1 秒
  });
};
```

### 场景六：取消请求

```typescript
const controller = new AbortController();

// 发起请求
const requestPromise = http.comRequest<Data>({
  url: '/api/data',
  method: 'GET',
  signal: controller.signal,  // 传入中断信号
});

// 取消请求
setTimeout(() => {
  controller.abort();
}, 5000);
```

## 🔧 高级配置

### 切换请求库

```typescript
// 使用 axios
const httpAxios = new Http({
  httpLib: 'axios',
  // ... 其他配置
});

// 使用 ky
const httpKy = new Http({
  httpLib: 'ky',
  // ... 其他配置
});

// 使用 swr
const httpSWR = new Http({
  httpLib: 'swr',
  // ... 其他配置
});
```

### 环境差异化配置

```typescript
const http = new Http({
  baseUrl: process.env.NODE_ENV === 'production' 
    ? 'https://api.example.com' 
    : '/api',
  encryptionType: process.env.NODE_ENV === 'production' 
    ? 'RSA' 
    : 'none',  // 开发环境不加密，便于调试
  // ... 其他配置
});
```

## 📝 注意事项

1. **错误处理器必须初始化**：在使用 `comRequest` 前，必须在构造函数中传入 `errorHandler` 错误处理函数，否则会抛出错误。**错误处理函数必须返回处理后的数据**，不能返回 `undefined`。

2. **加密类型选择**：
   - 生产环境建议使用 `RSA`
   - 开发环境可以使用 `none` 便于调试
   - 文件上传使用 `Binary`

3. **Token 管理**：Token 默认从 `localStorage` 的 `Admin-Token` 键读取，确保登录后正确存储 Token。

4. **请求体合并**：默认会合并 `defaultRequestBody`（包含 `sign`、`timestamp` 等），如果不需要合并，设置 `isMergeBody: false`。

5. **性能监控**：所有请求会自动记录性能数据，可通过 `@iap/kit-util` 的 `performanceMonitor` 查看。

## 🐛 常见问题

### Q: 如何禁用某个请求的加密？

```typescript
const response = await http.comRequest({
  url: '/api/data',
  encryptionType: 'none',  // 设置为 none 禁用加密
});
```

### Q: 如何自定义错误处理？

在初始化时传入 `errorHandler` 函数，并在其中实现自定义逻辑。**注意：错误处理函数必须返回处理后的数据，不能返回 `undefined`。**

```typescript
const http = new Http({
  // ... 其他配置
  errorHandler: (data, config) => {
    // 根据错误码处理
    if (data.code === 401) {
      // 未登录
      window.location.href = '/login';
    } else if (data.code !== 200) {
      // 其他错误
      message.error(data.message || '请求失败');
    }
    
    // 【关键】必须返回数据
    return data;
  },
});
```

### Q: 如何修改加密密钥？

通过 `@iap/kit-encryptor` 的 `encryptConfigure` 函数配置。

### Q: 支持哪些请求库？

目前支持：alova（默认）、axios、ky、swr。

### Q: 如何实现请求缓存？

可以使用 swr 作为请求库，它内置了缓存功能。

## 📚 相关文档

- [@iap/kit-encryptor 文档](../../kit-encryptor/README.md) - 加密工具库文档
- [@iap/kit-logger 文档](../../kit-logger/README.md) - 日志工具库文档
- [@iap/kit-util 文档](../../kit-util/README.md) - 工具函数库文档

## 📄 许可证

MIT
