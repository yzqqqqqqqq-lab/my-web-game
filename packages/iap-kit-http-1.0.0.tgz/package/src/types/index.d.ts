declare module 'pako';
