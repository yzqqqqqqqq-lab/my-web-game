import useSWR, { type SWRConfiguration, mutate } from 'swr';
import { defaultConfig, type HttpConfig, type HttpResponse } from './utils/HttpConfig';
import { handleErrorCode } from './utils/handleErrorCode';
import {
    buildRequestBody,
    encryptRequestBody,
    decryptResponseData,
    checkThrottle,
    mergeConfig,
    createErrorResponse,
    DebugLogger,
    PerformanceTracker,
    ErrorLogger
} from './utils/httpUtils';

export const comTag = 'Http-SWR'; // SWR versions of log tags

// SWR fetcher - 基于fetch API的请求执行函数，通过拦截器处理业务逻辑
async function swrFetcher<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 合并默认配置，确保 encryptionType 等配置正确传递
    const finalConfig = mergeConfig(config);
    const timerId = PerformanceTracker.start('Fetch');

    // 请求拦截器 - 处理节流检查、加密等业务逻辑
    checkThrottle(finalConfig);

    // 构建请求体并加密
    const { body: encryptedBody, headers: encryptedHeaders } = encryptRequestBody(
        { ...finalConfig, comTag },
        buildRequestBody(finalConfig)
    );

    DebugLogger.logEncryptBefore('SWR', finalConfig.url, {
        method: finalConfig.method,
        encryptionType: finalConfig.encryptionType,
        body: finalConfig.body
    });

    // 创建超时控制器
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), finalConfig.timeout || defaultConfig.timeout!);

    try {
        // 发送HTTP请求
        const response = await fetch(`${finalConfig.baseUrl || defaultConfig.baseUrl}${finalConfig.url}`, {
            method: finalConfig.method || defaultConfig.method,
            headers: {
                ...defaultConfig.headers,
                ...(finalConfig.headers || {}),
                ...encryptedHeaders
            },
            body: encryptedBody,
            signal: finalConfig.signal || controller.signal
        });

        // 响应拦截器 - 处理解密、错误处理等业务逻辑
        clearTimeout(timeoutId);

        try {
            let responseData = await response.json();

            // RSA解密
            if (finalConfig.encryptionType === 'RSA') {
                responseData = decryptResponseData(responseData);
            } else {
                DebugLogger.logSkipDecrypt('SWR');
            }
            DebugLogger.logDecryptAfter('SWR', finalConfig.url, responseData);

            // 根据错误码映射表处理业务错误
            responseData = handleErrorCode(responseData, finalConfig);

            PerformanceTracker.endSuccess(timerId, finalConfig.url);
            return responseData;
        } catch (error: any) {
            ErrorLogger.logParseError(comTag, error, finalConfig.url);
            PerformanceTracker.endFailure(timerId, finalConfig.url, 'Parse Failed');

            return createErrorResponse<T>(error.message || 'Response Parse Error', 'Response data parse failed');
        }
    } catch (error: any) {
        // 错误拦截器 - 处理网络错误
        clearTimeout(timeoutId);
        ErrorLogger.logNetworkError(comTag, error, finalConfig.url);
        PerformanceTracker.endFailure(timerId, finalConfig.url);

        return createErrorResponse<T>(error.message || 'Network Error');
    }
}

// 主导出函数 - SWR版本的核心请求方法，兼容原有API
export async function comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    return swrFetcher<T>(config);
}

// React Hook导出函数 - 提供SWR数据获取能力，支持缓存和自动重试
export function useComRequest<T>(config: HttpConfig | null, swrOptions?: SWRConfiguration<HttpResponse<T>>) {
    const key = config ? `${config.url}_${JSON.stringify(config.body)}_${config.method}` : null;

    return useSWR(key, () => (config ? swrFetcher<T>(config) : Promise.reject(new Error('No config provided'))), {
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
        dedupingInterval: 1000,
        ...swrOptions
    });
}

// 手动刷新函数 - 用于主动更新缓存中的数据
export function mutateRequest(key: string) {
    mutate(key); // 调用SWR的mutate函数更新指定key的缓存
}

// SWR全局配置 - 默认配置，可被useComRequest的swrOptions覆盖
export const swrConfig: SWRConfiguration = {
    revalidateOnFocus: false, // 禁用窗口焦点重新验证，避免不必要的请求
    revalidateOnReconnect: false, // 禁用网络重连重新验证，由业务层控制
    dedupingInterval: 1000, // 1秒内相同请求会被去重
    errorRetryCount: 3, // 出错时重试3次
    errorRetryInterval: 1000, // 重试间隔1秒
    shouldRetryOnError: (error) => error.name === 'NetworkError' // 只对网络错误重试，不重试业务错误
};
