import ky, { type Options } from 'ky';
import { defaultConfig, type HttpConfig, type HttpResponse } from './utils/HttpConfig';
import { errorHandlerManager } from './utils/ErrorHandlerManager';
import {
    buildRequestBody,
    encryptRequestBody,
    decryptResponseData,
    checkThrottle,
    mergeConfig,
    createErrorResponse,
    DebugLogger,
    PerformanceTracker,
    ErrorLogger
} from './utils/httpUtils';
import PerformanceMonitor from './utils/PerformanceMonitor';

export const comTag = 'Http-Ky'; // Ky versions of log tags

// Ky 请求器 - 核心请求执行函数，通过拦截器处理业务逻辑
async function kyFetcher<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 检查错误处理器是否已初始化
    if (!errorHandlerManager.isReady()) {
        throw new Error('ErrorHandler not initialized. Please call errorHandlerManager.init() before making requests.');
    }

    // 合并默认配置，确保 encryptionType 等配置正确传递
    const finalConfig = mergeConfig(config);
    const { headers = {}, timeout, signal } = finalConfig;

    // 直接构建 ky 配置
    const kyConfig: Options & { httpConfig?: HttpConfig } = {
        method: defaultConfig.method as any,
        headers: { ...defaultConfig.headers, ...headers },
        timeout: timeout || defaultConfig.timeout,
        signal,
        // 禁用 Ky 的自动状态码检查，由业务层处理
        throwHttpErrors: false,
        // 禁用 Ky 的默认 JSON 序列化，避免重复序列化
        json: undefined,
        // 将原始 HttpConfig 存储在 ky config 中，供拦截器使用
        httpConfig: finalConfig
    };

    try {
        const response = await ky(`${finalConfig.baseUrl || defaultConfig.baseUrl}${finalConfig.url}`, kyConfig);
        // 拦截器已经处理了响应数据，直接返回
        return await response.json();
    } catch (error: any) {
        // 拦截器处理后的错误响应
        return error.response?.data || createErrorResponse<T>(error.message || 'Network Error');
    }
}

// 初始化 ky 全局配置
function initKyConfig() {
    ky.extend({
        timeout: defaultConfig.timeout,
        headers: defaultConfig.headers,
        hooks: {
            beforeRequest: [
                (request, options) => {
                    // 从 ky options 中提取原始 HttpConfig
                    const httpConfig = (options as any).httpConfig as HttpConfig;
                    if (!httpConfig) return request;

                    // 节流检查
                    checkThrottle(httpConfig);

                    // 构建请求体并加密
                    const { body: encryptedBody, headers: encryptedHeaders } = encryptRequestBody(
                        { ...httpConfig, comTag },
                        buildRequestBody(httpConfig)
                    );

                    DebugLogger.logEncryptBefore('Ky', httpConfig.url, {
                        method: httpConfig.method,
                        encryptionType: httpConfig.encryptionType,
                        body: options.body
                    });

                    // 更新请求配置并记录性能监控开始
                    const newOptions = {
                        ...options,
                        ...(encryptedBody && options.method !== 'GET' && { body: encryptedBody }),
                        headers: { ...options.headers, ...encryptedHeaders },
                        timerId: PerformanceTracker.start('Ky')
                    };

                    return new Request(request.url, { ...request, ...newOptions });
                }
            ],
            afterResponse: [
                async (request, options, response) => {
                    // 从 ky options 中提取原始 HttpConfig
                    const httpConfig = (options as any).httpConfig as HttpConfig;
                    const timerId = (options as any).timerId;

                    if (!httpConfig) return response;

                    let responseData: any;

                    try {
                        responseData = await response.json();
                    } catch (e) {
                        // 如果不是JSON响应，返回原始响应
                        return response;
                    }

                    // RSA解密
                    if (httpConfig.encryptionType === 'RSA') {
                        responseData = decryptResponseData(responseData);
                    } else {
                        DebugLogger.logSkipDecrypt('Ky');
                    }
                    DebugLogger.logDecryptAfter('Ky', httpConfig.url, responseData);

                    // 根据错误码映射表处理业务错误
                    responseData = errorHandlerManager.handleError(responseData, httpConfig);

                    // 检查是否为网络错误（HTTP 状态码非 2xx）
                    if (!response.ok) {
                        ErrorLogger.logHttpError(comTag, response.status, responseData, request.url);
                        PerformanceTracker.endFailure(timerId, httpConfig.url, `Network Error (${response.status})`);

                        return new Response(
                            JSON.stringify({
                                code: response.status,
                                data: null,
                                message: response.statusText || 'HTTP Error',
                                timestamp: Date.now(),
                                description: `HTTP ${response.status}: ${response.statusText}`,
                                etag: '',
                                status: 'error'
                            }),
                            {
                                status: response.status,
                                headers: response.headers
                            }
                        );
                    }

                    // 网络成功，记录性能监控结束
                    PerformanceTracker.endSuccess(timerId, httpConfig.url);

                    // 返回处理后的响应
                    return new Response(JSON.stringify(responseData), {
                        status: response.status,
                        headers: response.headers
                    });
                }
            ]
        }
    });
}

// 延迟初始化，避免循环依赖
if (typeof window !== 'undefined') {
    // 客户端环境
    setTimeout(initKyConfig, 0);
}

// 主导出函数 - Ky版本的核心请求方法，兼容原有API
export async function comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    return kyFetcher<T>(config);
}

// React Hook导出函数 - 提供SWR数据获取能力，支持缓存和自动重试
export function useComRequest<T>(config: HttpConfig | null, swrOptions?: any) {
    const key = config ? `${config.url}_${JSON.stringify(config.body)}_${config.method}` : null;

    // 使用动态导入避免SSR问题
    if (typeof window === 'undefined') {
        return { data: undefined, error: undefined, isLoading: false };
    }

    // 动态导入SWR
    const { default: useSWR } = require('swr');

    return useSWR(key, () => (config ? kyFetcher<T>(config) : Promise.reject(new Error('No config provided'))), {
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
        dedupingInterval: 1000,
        ...swrOptions
    });
}

// 导出性能监控工具，方便在控制台查看统计
export { PerformanceMonitor };
