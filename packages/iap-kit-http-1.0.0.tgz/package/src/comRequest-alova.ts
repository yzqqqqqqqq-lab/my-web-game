/**
 * 基于 Alova.js 的 HTTP 请求封装（支持 SSR、加密、节流、错误统一处理）
 * 核心能力：整合请求加密、性能监控、错误拦截、Loading 管理，提供标准化请求入口 `comRequest`
 */
import { createAlova } from 'alova';
// 导入HTTP配置类型、默认配置（定义请求格式与默认行为）
import { defaultConfig, type HttpConfig, type HttpResponse } from './utils/HttpConfig';
// 导入错误统一处理器（管理业务错误码、错误提示逻辑）
import { errorHandlerManager } from './utils/ErrorHandlerManager';
// 导入HTTP工具函数（请求体构建、加解密、节流、日志等）
import {
    buildRequestBody, // 构建标准化请求体（合并公共参数如sign、timestamp）
    encryptRequestBody, // 加密请求体（根据encryptionType选择RSA/Binary/不加密）
    decryptResponseData, // 解密响应数据（与请求加密对应）
    checkThrottle, // 节流检查（防止单位时间内重复请求）
    NetworkError, // 自定义网络错误类（如节流触发的错误）
    mergeConfig, // 合并用户配置与默认配置（补全缺失项）
    createErrorResponse, // 生成标准化错误响应（统一错误格式）
    DebugLogger, // 调试日志工具（记录加密前后、跳过解密等日志）
    PerformanceTracker, // 性能监控工具（记录请求开始/结束时间）
    ErrorLogger // 错误日志工具（记录网络错误详情）
} from './utils/httpUtils';
// 导入全局日志工具（输出请求相关日志）
import { logger } from '@iap/kit-logger';

/** 日志标签（用于区分Alova请求模块的日志，便于问题定位） */
export const comTag = 'Http-Alova';

export interface IInterceptor {
    errorInterceptor?: (error: any, method: any) => void; // 自定义错误拦截器（可选）
}

/**
 * 公共请求配置（存储全局拦截器等可配置项）
 * 支持通过 `setInterceptor` 动态修改，如自定义错误拦截逻辑
 */
let interceptor: IInterceptor = {};

let headerBasic: Record<string, any> = {};

function getHeaderBasic(): any {
    return headerBasic;
}

/**
 * 动态导入 Alova Fetch 适配器（适配 SSR 环境）
 * 原因：SSR 环境（如Node.js）中无浏览器原生fetch，直接导入可能报错，故采用动态导入+失败降级
 */
// 静态导入 Alova Fetch 适配器
import GlobalFetch from 'alova/fetch';


/**
 * 1. 创建 Alova 实例（全局唯一，统一请求配置）
 * 包含基础URL、请求适配器、超时、请求/响应拦截器等核心配置
 */
const alovaInstance = createAlova({
    // 基础请求路径（默认取HttpConfig的baseUrl，可被单个请求的baseUrl覆盖）
    baseURL: defaultConfig.baseUrl,

    // 请求适配器（使用官方适配器）
    requestAdapter: GlobalFetch(),

    // 全局请求超时时间（默认10秒，单个请求可通过timeout配置覆盖）
    timeout: defaultConfig.timeout,

    /**
     * 2. 请求前拦截器（处理请求发送前的逻辑）
     * 执行顺序：打开Loading → 检查错误处理器 → 节流 → 构建加密请求体 → 记录性能开始
     * @param method Alova请求方法实例（包含请求配置、数据等）
     */
    beforeRequest: (method: any) => {
        // 打开Loading（通过请求配置的options.setLoading控制，适配UI框架的Loading状态）
        method.config?.options?.setLoading?.(true);

        // 检查错误处理器是否初始化（未初始化则抛出错误，避免后续错误处理失效）
        if (!errorHandlerManager.isReady()) {
            throw new Error(
                'ErrorHandler not initialized. Please call errorHandlerManager.init() before making requests.'
            );
        }

        // 从Alova method中获取当前请求的HttpConfig配置（单个请求的自定义配置）
        const httpConfig = (method as any).httpConfig as HttpConfig;
        if (!httpConfig) return; // 无配置则跳过后续处理

        // 节流检查（单位时间内重复请求会抛出NetworkError，防止重复提交）
        try {
            checkThrottle(httpConfig);
        } catch (error) {
            throw error; // 抛出节流错误，进入onError拦截器
        }

        // 构建标准化请求体（合并defaultRequestBody与用户body）+ 加密请求体/头
        const { body: encryptedBody, headers: encryptedHeaders } = encryptRequestBody(
            { ...httpConfig, comTag }, // 传入请求配置+日志标签
            buildRequestBody(httpConfig, getHeaderBasic()) // 先构建基础请求体
        );

        // 打印加密前的调试日志（记录请求方法、加密类型、原始body）
        DebugLogger.logEncryptBefore('Alova', httpConfig.url, {
            method: httpConfig.method,
            encryptionType: httpConfig.encryptionType,
            body: {
                ...method.data,
                ...getHeaderBasic()
            }
        });

        // 更新Alova请求的body（仅非GET请求，GET请求body会被忽略）
        if (encryptedBody && httpConfig.method !== 'GET') {
            method.data = encryptedBody;
        }

        // 合并请求头（默认头 → 用户头 → 加密生成的头，后者覆盖前者）
        method.config.headers = {
            ...method.config.headers,
            ...encryptedHeaders
        };

        // 记录请求性能监控的开始时间（返回timerId，用于后续结束计时）
        (method as any).timerId = PerformanceTracker.start('Alova');
    },

    /**
     * 3. 响应拦截器（处理请求响应后的逻辑，分成功/失败分支）
     */
    responded: {
        /**
         * 成功响应处理（HTTP状态码2xx，如200）
         * 执行顺序：关闭Loading → 解密响应 → 业务错误处理 → 记录性能成功
         * @param response 浏览器原生Response对象
         * @param method Alova请求方法实例
         */
        onSuccess: (response: Response, method: any) => {
            // 关闭Loading（与beforeRequest的打开对应）
            method.config?.options?.setLoading?.(false);
            logger.info(`${comTag} - Request Success`, method);

            // 获取当前请求配置与性能监控ID
            const httpConfig = (method as any).httpConfig as HttpConfig;
            const timerId = (method as any).timerId;

            // 解析响应体为JSON（Alova需返回处理后的数据，供后续then接收）
            return response.json().then((responseData) => {
                if (httpConfig) {
                    // 响应解密（仅当请求加密类型为RSA时执行）
                    if (httpConfig.encryptionType === 'RSA') {
                        responseData = decryptResponseData(responseData);
                    } else {
                        // 非RSA加密：打印跳过解密的调试日志
                        DebugLogger.logSkipDecrypt('Alova');
                    }

                    // 打印解密后的响应日志（便于调试业务数据）
                    DebugLogger.logDecryptAfter('Alova', httpConfig.url, responseData);

                    // 业务错误处理（根据后端错误码映射提示，如401未登录、500服务错误）
                    responseData = errorHandlerManager.handleError(responseData, httpConfig);

                    // 记录性能监控的成功结束（传入timerId和请求URL，统计耗时）
                    PerformanceTracker.endSuccess(timerId, httpConfig.url);
                }

                // 返回处理后的响应数据（最终会被comRequest的await接收）
                return responseData;
            });
        },

        /**
         * 错误响应处理（HTTP状态码非2xx、超时、网络错误、节流错误等）
         * 执行顺序：关闭Loading → 超时判断 → 错误日志 → 性能失败记录 → 自定义拦截 → 抛出错误
         * @param error 错误对象（可能是网络错误、超时错误、自定义NetworkError等）
         * @param method Alova请求方法实例
         */
        onError: (error: any, method: any) => {
            // 获取当前请求配置与性能监控ID
            const httpConfig = (method as any).httpConfig as HttpConfig;
            const timerId = (method as any).timerId;

            // 异常场景关闭Loading（防止请求失败后Loading一直显示）
            method.config?.options?.setLoading?.(false);

            // 超时错误判断（根据错误信息识别，可扩展自定义超时逻辑）
            if (error.message && error.message.includes('network timeout')) {
                logger.error(`${comTag} - Request Timeout`, method.url);
            }

            if (httpConfig) {
                const requestUrl = method.url;
                // 记录网络错误日志（包含错误详情、请求URL，便于排查）
                ErrorLogger.logNetworkError(comTag, error, requestUrl);
                // 记录性能监控的失败结束（标记请求异常）
                PerformanceTracker.endFailure(timerId, requestUrl);
            }

            // 执行自定义错误拦截器（若用户通过setComRequestConfig设置）
            if (typeof interceptor.errorInterceptor === 'function') {
                interceptor.errorInterceptor(error, method);
            }

            // Alova要求onError必须抛出错误（否则会被误认为成功）
            throw error;
        }
    }
});

/**
 * 4. Alova 请求执行器（内部核心函数，处理配置合并、方法映射、错误捕获）
 * @param config 单个请求的配置（用户传入，可能缺失部分字段）
 * @returns 标准化的HttpResponse<T>（泛型T为响应data的类型）
 */
async function alovaFetcher<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 合并用户配置与默认配置（补全缺失项，如method默认GET、timeout默认10秒）
    const finalConfig = mergeConfig(config);
    // 解构合并后的配置（提取关键字段，简化后续代码）
    const {
        url, // 请求相对路径（如"/user/login"）
        baseUrl, // 单个请求的基础路径（优先于全局baseURL）
        method, // HTTP方法（GET/POST等）
        headers = {}, // 请求头（用户自定义）
        timeout, // 单个请求超时（覆盖全局timeout）
        signal, // 请求中断信号（AbortSignal，用于取消请求）
        body // 请求体（仅非GET方法有效）
    } = finalConfig;

    // 构建完整请求URL（基础路径 + 相对路径，优先用单个请求的baseUrl）
    const fullUrl = `${baseUrl || defaultConfig.baseUrl}${url}`;
    // 将HTTP方法转为小写（适配methodMap的键名，如"POST"→"post"）
    const httpMethod = (method || defaultConfig.method)?.toLowerCase();

    // Alova请求的公共配置（整合头、超时、中断信号、自定义options）
    const commonAlovaConfig = {
        headers: { ...defaultConfig.headers, ...headers }, // 合并默认头与用户头
        timeout: timeout || defaultConfig.timeout, // 单个请求超时
        ...(signal && { signal }), // 可选：请求中断信号
        options: config?.options // 自定义选项（如setLoading）
    };

    /**
     * HTTP方法映射表（将用户传入的method映射为Alova的对应方法）
     * 键：小写HTTP方法；值：Alova方法调用（Get无body，Post/Put等有body）
     */
    const methodMap = {
        get: () => alovaInstance.Get(fullUrl, commonAlovaConfig), // GET：参数通过query传递
        post: () => alovaInstance.Post(fullUrl, body, commonAlovaConfig), // POST：body为请求体
        put: () => alovaInstance.Put(fullUrl, body, commonAlovaConfig), // PUT：类似POST
        patch: () => alovaInstance.Patch(fullUrl, body, commonAlovaConfig), // PATCH：部分更新
        delete: () => alovaInstance.Delete(fullUrl, commonAlovaConfig) // DELETE：无body
    };

    // 获取当前方法对应的Alova处理器（如method为POST则取methodMap.post）
    const methodHandler = methodMap[httpMethod as keyof typeof methodMap];
    if (!methodHandler) {
        // 不支持的HTTP方法：抛出标准化错误
        throw new Error(`Unsupported HTTP method: ${method} (Only GET/POST/PUT/PATCH/DELETE are supported)`);
    }

    // 创建Alova请求方法实例（调用映射表中的函数）
    const alovaMethod = methodHandler();
    // 将合并后的完整配置挂载到Alova实例上（供beforeRequest/responded拦截器访问）
    (alovaMethod as any).httpConfig = finalConfig;

    try {
        // 执行请求并获取响应（拦截器会在此过程中处理加密、日志、性能等）
        const response = await alovaMethod;
        // 返回标准化响应（拦截器已处理业务错误，此处直接返回）
        return response as HttpResponse<T>;
    } catch (error: any) {
        // 捕获错误：区分自定义NetworkError（如节流）和其他错误
        if (error instanceof NetworkError) {
            throw error; // 节流错误直接抛出，由业务层处理
        }

        // 其他错误（如网络异常、超时）：返回标准化错误响应（统一格式）
        return createErrorResponse<T>(error.message || 'Network Error (Network abnormality or request failure)');
    }
}

/**
 * 5. 对外暴露的核心请求方法（标准化入口，兼容原有业务调用）
 * @param config 单个请求的配置（用户传入，支持覆盖默认值）
 * @param interceptorJson
 * @param headerBic
 * @returns 标准化的HttpResponse<T>（泛型T指定响应data的类型，提升类型安全）
 */
export async function comRequest<T>(
    config: HttpConfig,
    interceptorJson: IInterceptor,
    headerBic: Record<string, any>
): Promise<HttpResponse<T>> {
    interceptor = interceptorJson;
    headerBasic = headerBic;
    // 委托给alovaFetcher执行请求，对外隐藏内部实现
    return alovaFetcher<T>(config);
}

/**
 * 导出全局Alova实例与工具（供特殊场景使用，如手动取消请求、查看请求状态）
 */
export { alovaInstance };
