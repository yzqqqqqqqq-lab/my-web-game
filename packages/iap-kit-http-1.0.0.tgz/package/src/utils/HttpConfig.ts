/**
 * HTTP请求配置模块（基础定义层，支持SSR环境、客户端动态配置更新、标准化请求/响应格式）
 * 核心作用：统一请求参数类型、默认配置、响应结构，为上层请求工具（如Alova、原生fetch）提供基础定义
 */

/**
 * HTTP请求方法枚举（覆盖RESTful API常用方法，避免拼写错误导致的请求异常）
 * 说明：限定请求方法为固定字符串，确保类型安全，防止传入无效方法（如"get"小写、"POSTS"拼写错误）
 */
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

/**
 * 加密类型枚举（修正原"noe"笔误为"none"，确保类型与业务逻辑一致）
 * 用途：指定请求体的加密方式，适配不同环境的安全需求
 * - "RSA"：非对称加密（生产环境默认，适合敏感数据传输）
 * - "none"：不加密（开发环境默认，便于调试请求数据）
 * - "Binary"：二进制加密（适用于文件、流等二进制数据场景）
 */
export type EncryptionType = 'RSA' | 'none' | 'Binary';

/**
 * HTTP请求配置接口（定义单次请求的所有可配置项，涵盖路径、方法、头信息、加密、节流等核心能力）
 * 说明：所有可选字段均有默认值（见defaultConfig），必填字段仅`url`（请求相对路径）
 */
export interface HttpConfig {
    /**
     * 请求次数限制（防重复提交/重复请求）
     * - 0：无限制（允许无限次发起相同请求）
     * - 1/2/...：限制最大请求次数（如1=仅允许1次请求，避免表单重复提交）
     * 可选，默认值：1（见defaultConfig）
     */
    requestCount?: number;

    /**
     * 请求的相对路径（必填，如"/user/login"、"/goods/list"）
     * 说明：需与baseUrl拼接为完整请求地址（如baseUrl="/api" → 完整地址"/api/user/login"）
     */
    url: string;

    /**
     * 请求的基础路径（可选，用于覆盖默认baseUrl）
     * 场景：多服务调用时指定不同基础路径（如"/api/v2"、"https://pay.example.com"）
     * 默认值："/api"（见defaultConfig，支持客户端动态更新）
     */
    baseUrl?: string;

    /**
     * HTTP请求方法（可选，默认值："GET"，见defaultConfig）
     * 说明：需从HttpMethod枚举中选择，确保类型安全
     */
    method?: HttpMethod;

    /**
     * 自定义扩展参数（可选，用于传递非标准请求配置）
     * 核心字段：
     * - setLoading：加载状态控制函数（如UI框架的Loading显示/隐藏，参数为boolean）
     * 场景：适配不同UI库的加载状态管理，避免请求工具与UI强耦合
     */
    options?: {
        setLoading?: (loading: boolean) => void;
    };

    /**
     * 请求头配置（可选，键值对格式）
     * 说明：会与默认请求头（defaultConfig.headers）合并，用户配置优先级更高
     * 示例：{ "X-Request-Source": "web", "Authorization": "Bearer token" }
     * 默认值：{ "Content-Type": "application/json" }（见defaultConfig）
     */
    headers?: {
        [key: string]: string;
    };

    /**
     * 请求体数据（可选，仅POST/PUT/PATCH等方法有效）
     * 说明：
     * - 若isMergeBody为true（默认），会与defaultRequestBody合并（补充sign、timestamp等公共参数）
     * - GET请求的参数建议通过URL查询参数传递，而非此字段
     * 默认值：null（见defaultConfig）
     */
    body?: any;

    /**
     * 请求超时时间（单位：毫秒，可选）
     * 说明：超时后请求会被中断，避免长期阻塞
     * 默认值：10000（10秒，见defaultConfig）
     */
    timeout?: number;

    /**
     * 请求失败后的重试次数（可选）
     * 说明：仅幂等接口（如GET查询）建议设置重试，非幂等接口（如POST创建）不建议重试
     * 默认值：0（不重试，见defaultConfig）
     */
    retry?: number;

    /**
     * 重试间隔时间（单位：毫秒，可选）
     * 说明：两次重试之间的等待时间，避免短时间内频繁重试给服务端造成压力
     * 默认值：1000（1秒，见defaultConfig）
     */
    retryDelay?: number;

    /**
     * 请求中断信号（可选，基于AbortController API）
     * 用途：手动中断请求（如页面切换、用户取消操作时）
     * 使用示例：new AbortController().signal
     */
    signal?: AbortSignal;

    /**
     * 是否在请求头携带Token（可选，布尔值）
     * 说明：Token通常从本地存储获取（如Admin-Token），用于身份验证
     * 默认值：true（携带Token，见defaultConfig）
     */
    isToken?: boolean;

    /**
     * 是否合并默认请求体（可选，布尔值）
     * 说明：true时将自定义body与defaultRequestBody（含sign、timestamp）合并，false仅使用自定义body
     * 默认值：true（合并，见defaultConfig）
     */
    isMergeBody?: boolean;

    /**
     * 是否添加基础Basic头信息（可选，布尔值）
     * 说明：true时通过getHeaderBasic()获取基础数据（如设备信息、版本号）并添加到请求体
     * 默认值：true（添加，见defaultConfig）
     */
    isBasic?: boolean;

    /**
     * 是否强制请求（可选，布尔值）
     * 说明：true时忽略部分前置校验（如请求次数限制），但会弹出提示内容（需上层业务实现）
     * 场景：紧急操作（如强制提交表单、忽略重复请求限制）
     * 默认值：false（不强制，见defaultConfig）
     */
    isForce?: boolean;

    /**
     * 服务端返回错误时是否显示提示（可选，布尔值）
     * 说明：true时自动弹出错误提示（如Toast、Alert），false需上层业务手动处理
     * 默认值：true（显示提示，见defaultConfig）
     */
    isSerErrTips?: boolean;

    /**
     * 请求加密类型（可选，从EncryptionType枚举选择）
     * 说明：开发环境默认"none"（便于调试），生产环境默认"RSA"（保障安全）
     * 默认值：process.env.NODE_ENV === "development" ? "none" : "RSA"（见defaultConfig）
     */
    encryptionType?: EncryptionType;

    /**
     * 节流时间（单位：毫秒，可选）
     * 说明：限制单位时间内的请求频率（如500ms内仅允许1次请求），防止重复点击/快速触发
     * 示例：throttle: 500 → 500ms内同一请求仅执行1次
     * 默认值：无（不节流，需手动配置）
     */
    throttle?: number;
}

/**
 * HTTP响应通用结构接口（标准化前后端交互的响应格式，T为data字段的泛型类型）
 * 说明：所有接口响应需遵循此结构，确保上层工具可统一处理错误、数据解析
 */
export interface HttpResponse<T = any> {
    /**
     * 业务状态码（非HTTP状态码，与后端约定）
     * 示例：200=成功，401=未登录，403=无权限，500=服务端错误
     */
    code: number;

    /**
     * 业务消息（用户可见的提示文案）
     * 示例："操作成功"、"账号或密码错误"、"系统繁忙，请稍后再试"
     */
    message: string;

    /**
     * 响应核心数据（泛型T，适配不同接口的返回格式）
     * 说明：成功时为业务数据（如列表、详情），失败时可能为null/undefined
     */
    data: T;

    /**
     * 缓存标识（ETag，用于HTTP缓存机制）
     * 用途：配合304 Not Modified状态码，减少重复数据传输，优化性能
     */
    etag: string;

    /**
     * 错误详细描述（开发调试用，不建议展示给用户）
     * 示例："数据库连接超时"、"参数校验失败：username不能为空"
     */
    description: string;

    /**
     * 响应时间戳（毫秒级，服务端返回）
     * 用途：前端可用于时间差计算（如请求耗时）、时间相关业务逻辑
     */
    timestamp: number;

    /**
     * 响应状态字符串（可选，补充code的文字描述）
     * 示例："success"（成功）、"fail"（失败）、"error"（错误）
     */
    status?: string;
}

/**
 * HTTP请求默认配置（Omit<HttpConfig, "url"> 排除必填的url字段，确保默认配置无缺失）
 * 特点：
 * 1. 支持SSR环境：baseUrl默认"/api"，避免SSR初始化时依赖window导致的问题
 * 2. 环境差异化：加密类型、超时时间等配置按环境默认，减少手动配置
 * 3. 安全默认：默认携带Token、合并请求体、添加Basic信息，保障请求合法性
 */
export const defaultConfig: Omit<HttpConfig, 'url'> = {
    requestCount: 1, // 默认限制1次请求，防重复提交
    encryptionType: process.env.NODE_ENV === 'development' ? 'none' : 'RSA', // 环境差异化加密
    baseUrl: '/api', // 默认基础路径（客户端可动态更新）
    method: 'GET', // 默认请求方法
    headers: {
        'Content-Type': 'application/json' // 默认JSON格式请求体（适配大多数接口）
    },
    body: null, // 默认无请求体
    timeout: 10000, // 默认超时10秒（平衡用户体验与网络容错）
    retry: 0, // 默认不重试（避免非幂等接口重复执行）
    retryDelay: 1000, // 若开启重试，默认间隔1秒
    isToken: true, // 默认携带身份Token
    isMergeBody: true, // 默认合并默认请求体（补充公共参数）
    isBasic: true, // 默认添加基础Basic头信息
    isForce: false, // 默认不强制请求（遵循前置校验）
    isSerErrTips: true // 默认显示服务端错误提示
};

/**
 * 默认请求体结构（用于与自定义body合并，补充公共参数）
 * 说明：
 * - requestData：非RSA加密场景的业务数据字段（驼峰命名）
 * - request_data：RSA加密场景的业务数据字段（下划线命名，适配后端解析规则）
 * - sign：请求签名（防篡改，由上层工具生成）
 * - timestamp：请求时间戳（防重放攻击，由上层工具生成）
 */
export const defaultRequestBody: any = {
    requestData: {}, // 非RSA加密时的业务数据容器
    request_data: {}, // RSA加密时的业务数据容器（与requestData互斥）
    sign: '', // 请求签名（待加密工具填充）
    timestamp: 0 // 请求时间戳（待时间工具填充）
};
