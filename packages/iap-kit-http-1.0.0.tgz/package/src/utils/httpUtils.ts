/**
 * HTTP工具函数集合（核心能力：请求体构建、加解密、节流控制、错误处理、日志/性能监控）
 * 依赖：pako（gzip压缩）、@iap/kit-logger（日志）
 * 适配场景：与Alova请求封装配合，处理请求标准化、安全加密、异常兼容等通用逻辑
 */
import { defaultConfig, defaultRequestBody, type HttpResponse, type HttpConfig } from './HttpConfig';
import pako from 'pako'; // gzip压缩工具（请求体体积优化）
import { logger } from '@iap/kit-logger'; // 全局日志工具
import Encrypt, { AESHelper, MD5Helper, RSAHelper } from '@iap/kit-encryptor';
import Storage from '@iap/kit-storage';
import toolbox, { performanceMonitor } from '@iap/kit-util';

/**
 * 自定义网络错误类（继承Error）
 * 用途：区分「网络层面错误」（如节流、超时、断网）与「业务错误」（如code=401未登录），
 * 便于上层拦截器精准处理不同类型错误
 */
export class NetworkError extends Error {
    constructor(message: string) {
        super(message); // 错误描述（如"请求过于频繁，请稍后再试"）
        this.name = 'NetworkError'; // 错误名称（用于类型判断）
    }
}

/**
 * 节流控制存储Map（全局唯一）
 * Key：请求唯一标识（URL + 请求头JSON字符串）→ 确保同接口同参数请求唯一
 * Value：上次请求时间戳（毫秒级）→ 用于计算时间差判断是否节流
 */
const throttleMap = new Map<string, number>();

/**
 * 请求节流检查（防止短时间内重复请求，避免接口压力或重复提交）
 * @param config 请求配置（需包含throttle字段，单位ms）
 * @returns true：通过节流检查（可发起请求）；false：被节流（禁止请求）
 */
export function checkThrottle(config: any): boolean {
    // 无节流时间配置或节流时间≤0 → 直接通过
    if (config.throttle && config.throttle > 0) {
        // 生成请求唯一标识：URL + 请求头JSON（确保同参数请求被视为同一个）
        const key = `${config.url}_${JSON.stringify(config.headers)}`;
        const currentTime = Date.now(); // 当前时间戳
        const lastRequestTime = throttleMap.get(key) || 0; // 上次请求时间（默认0）

        // 时间差＜节流时间 → 被节流（返回false）
        if (currentTime - lastRequestTime < config.throttle) {
            return false;
        }

        // 时间差≥节流时间 → 更新上次请求时间（允许本次请求）
        throttleMap.set(key, currentTime);
    }
    return true;
}

/**
 * 构建标准化请求体（合并默认参数、适配加密类型）
 * 核心逻辑：根据isMergeBody配置合并defaultRequestBody，根据加密类型切换字段（request_data/requestData）
 * @param config 请求配置（含isMergeBody、isBasic、encryptionType等）
 * @param headerBasic
 * @returns 标准化请求体（合并后的完整body）
 */
export function buildRequestBody(config: any, headerBasic?: Record<string, any>): any {
    const {
        body, // 用户自定义请求体
        isMergeBody = defaultConfig.isMergeBody, // 是否合并默认请求体（默认true）
        isBasic = defaultConfig.isBasic, // 是否添加基础header信息（默认true）
        encryptionType = defaultConfig.encryptionType // 加密类型
    } = config;

    // 无需合并默认请求体，或无用户自定义body → 直接返回用户body
    if (!isMergeBody || !body) return body;

    // 深拷贝默认请求体（避免修改defaultRequestBody原对象，防止全局污染）
    const newRequestBody = toolbox.DeepClone<any>(defaultRequestBody);
    // 加密类型适配：RSA用下划线字段（request_data），其他用驼峰字段（requestData）
    const isRSA = encryptionType === 'RSA';
    const dataKey = isRSA ? 'request_data' : 'requestData';
    const deleteKey = isRSA ? 'requestData' : 'request_data'; // 删除互斥字段（避免冗余）

    // 合并用户body到对应字段（用户数据覆盖默认空对象）
    newRequestBody[dataKey] = {
        ...newRequestBody[dataKey], // 默认空对象
        ...body // 用户自定义数据
    };

    // 删除互斥字段（如RSA模式下删除requestData，避免后端解析错误）
    delete newRequestBody[deleteKey];

    // 需要添加基础header信息 → 合并getHeaderBasic返回的基础数据
    if (isBasic) {
        newRequestBody[dataKey] = {
            ...newRequestBody[dataKey],
            ...headerBasic // 基础数据（如设备信息、版本号等，由getHeaderBasic定义）解耦，应该由业务传入
        };
    }

    return newRequestBody;
}

/**
 * 加密相关常量配置（集中管理，避免硬编码，便于维护）
 */
const ENCRYPT_CONSTANTS = {
    S_ENCODE_V1: 's0523', // 加密版本标识（后端用于识别加密协议版本）
    CONTENT_TYPE_JSON: 'application/json', // JSON请求体的Content-Type
    S_ETAG_HASH: '' // ETag哈希标识（暂未使用，预留扩展）
} as const; // as const确保常量不可修改

/**
 * 加密请求体与请求头（支持RSA混合加密、gzip压缩，适配不同加密类型）
 * @param config 请求配置（含encryptionType、isToken、isGzip等）
 * @param body 已通过buildRequestBody构建的标准化请求体
 * @returns { body: 加密后请求体; headers: 补充加密相关头的请求头 }
 */
export function encryptRequestBody(config: any, body: any): { body: any; headers: any } {
    const {
        encryptionType = defaultConfig.encryptionType, // 加密类型（默认RSA）
        isToken = defaultConfig.isToken // 是否携带Token（默认true）
    } = config;
    const isGzip = (config as any).isGzip || false; // 是否启用gzip压缩（默认false）
    const TokenKey = 'Admin-Token'; // Token在本地存储的key

    // 初始化请求头：继承用户配置的headers
    const headers = { ...config.headers };

    // 需要携带Token → 从本地存储获取Token并添加到Authorization头
    if (isToken) {
        headers.Authorization = Storage.getStorage(TokenKey);
    }

    // -------------------------- RSA加密逻辑（混合AES+RSA，高安全性）--------------------------
    if (encryptionType === 'RSA') {
        const logTag = config.comTag || 'Http-Request'; // 日志标签（默认"Http-Request"）

        // 1. 生成当前时间戳（用于签名防重放攻击）
        const strStamp = toolbox.localTimeStampMill;
        body.timestamp = strStamp; // 时间戳（防重放）提前赋值

        // 打印加密前的请求信息（调试用，含URL和完整配置）
        logger.info(
            logTag,
            'Request Interceptor - Before Encryption:',
            config.url,
            toolbox.DeepClone(config), // 深拷贝避免日志打印时修改原对象
            toolbox.DeepClone(body),
        );

        // 2. 序列化请求体中的核心数据（request_data字段）
        const requestDataStr = JSON.stringify(body.request_data);

        // 3. 生成AES随机向量（16位，用于AES加密的初始化向量，增强安全性）
        const aesIV = AESHelper.GenerateIV(16);
        // 4. AES加密核心数据（用生成的IV，Web端专用加密方法）
        const encryptedAesData = AESHelper.EncryptWeb(requestDataStr, aesIV);
        // 5. RSA加密AES的IV（用默认RSA公钥，后端用私钥解密IV后，再解AES数据）
        const encryptedRsaIV = RSAHelper.Encrypt(aesIV);
        // 6. 生成MD5签名（防篡改：用SIGN_KEY、AES数据、时间戳拼接后哈希）
        const requestSign = MD5Helper.CreateMD5(
            `${Encrypt.SIGN_KEY}${encryptedAesData}${Encrypt.SIGN_KEY}${strStamp}${Encrypt.SIGN_KEY}`
        ).toLowerCase(); // 转小写（与后端签名校验格式统一）

        // 7. 更新请求体：替换为加密数据，添加签名
        body.sign = requestSign; // 签名（防篡改）
        body.request_data = encryptedAesData; // 核心数据替换为AES加密后的数据

        // 8. 可选gzip压缩（压缩失败时降级为未压缩，避免请求失败）
        const finalEncryptedBody = isGzip
            ? (() => {
                try {
                    // 先序列化body为JSON，再gzip压缩
                    return pako.gzip(JSON.stringify(body));
                } catch (compressionError) {
                    // 压缩失败：日志提示并返回未压缩的JSON字符串
                    logger.error('[httpUtils] Gzip compression failed, falling back to uncompressed:', compressionError);
                    return JSON.stringify(body);
                }
            })()
            : JSON.stringify(body); // 不压缩：直接序列化为JSON

        // 9. 构建RSA加密专用请求头（后端用于解密和校验）
        const rsaSpecificHeaders = {
            'Content-Type': ENCRYPT_CONSTANTS.CONTENT_TYPE_JSON, // JSON格式
            's-encode-v1': ENCRYPT_CONSTANTS.S_ENCODE_V1, // 加密版本
            's-encode-rsa': String(encryptedRsaIV), // RSA加密后的IV
            's-encode-sign': requestSign, // 签名（与body.sign一致，便于header快速校验）
            's-encode-timestamp': String(strStamp), // 时间戳（与body.timestamp一致）
            'sn-etag-hash': ENCRYPT_CONSTANTS.S_ETAG_HASH, // 预留ETAG字段
            ...(isGzip && { 'Content-Encoding': 'gzip' }) // 启用gzip时添加编码头
        };

        // 返回RSA加密后的body和合并后的headers
        return {
            body: finalEncryptedBody,
            headers: { ...headers, ...rsaSpecificHeaders }
        };
    }

    // -------------------------- 非RSA加密逻辑（Binary/不加密）--------------------------
    return encryptionType === 'Binary'
        ? { body, headers } // Binary类型（如文件流）：body原样返回，不序列化
        : { body: JSON.stringify(body), headers }; // 不加密：序列化为JSON字符串
}

/**
 * 解密响应数据（适配RSA加密场景，兼容多种后端返回格式，错误不中断流程）
 * 兼容两种后端返回格式：
 * 1. 标准格式：{ code: number, data: "加密字符串", ... }
 * 2. 简化格式：直接返回加密字符串（如Content-Type为text/plain时）
 * @param data 后端原始响应数据（可能是字符串或对象）
 * @returns 解密后的响应数据（若解密失败，返回原始数据交由上层处理）
 */
export function decryptResponseData(data: any): any {
    const myESHelper = new AESHelper();
    try {
        // 场景1：后端直接返回加密字符串（非对象格式）
        if (typeof data === 'string') {
            // AES解密字符串（用默认密钥）
            const decryptedStr = AESHelper.DecryptWeb(data);
            try {
                // 尝试解析解密后的字符串为JSON对象
                const parsedObj = JSON.parse(decryptedStr);
                // 若解析后的数据仍包含加密的data字段（兼容旧接口双层加密）
                if (parsedObj && typeof parsedObj.data === 'string') {
                    try {
                        // 二次解密data字段并解析为JSON
                        parsedObj.data = JSON.parse(AESHelper.DecryptWeb(parsedObj.data));
                    } catch (_secondaryDecryptErr) {
                        // 二次解密失败：不抛错，保留原始data（交由上层判定）
                    }
                }
                return parsedObj; // 返回解析后的对象
            } catch (_parseErr) {
                // 解密后非JSON格式（如纯文本）：返回原始数据
                return data;
            }
        }

        // 场景2：后端返回标准对象格式，且data字段为加密字符串
        if (data?.data && typeof data.data === 'string') {
            // AES解密data字段并解析为JSON
            const decryptedData = AESHelper.DecryptWeb(data.data);
            data.data = JSON.parse(decryptedData);
        }
    } catch (decryptErr) {
        // 解密失败（如密钥不匹配、数据损坏）：日志提示但不抛错，避免中断正常流程
        const logTag = (globalThis as any).comTag || 'Http-Request';
        toolbox.isLog && logger.error(logTag, 'Response decryption failed:', decryptErr);
    }
    // 返回处理后的数据（解密成功→解密后数据；失败→原始数据）
    return data;
}

/**
 * 获取默认请求头（深拷贝避免外部修改默认配置）
 * @returns 默认请求头对象（如{ "Content-Type": "application/json" }）
 */
export function getDefaultHeaders() {
    return { ...defaultConfig.headers };
}

/**
 * 获取默认基础URL（从defaultConfig读取，确保全局基础路径统一）
 * @returns 默认基础URL（如"/api"）
 */
export function getDefaultBaseUrl() {
    return defaultConfig.baseUrl!; // !断言：默认配置中baseUrl已定义
}

/**
 * 获取默认请求超时时间（从defaultConfig读取，单位毫秒）
 * @returns 默认超时时间（默认10000ms=10秒）
 */
export function getDefaultTimeout() {
    return defaultConfig.timeout!; // !断言：默认配置中超时时间已定义
}

/**
 * 合并请求配置（用户配置覆盖默认配置，确保字段不缺失）
 * 规则：用户配置中的字段优先级高于defaultConfig，未传字段用默认值
 * @param config 用户传入的请求配置
 * @returns 合并后的完整请求配置
 */
export function mergeConfig(config: HttpConfig): HttpConfig {
    return {
        ...defaultConfig, // 先展开默认配置
        ...config // 再展开用户配置（覆盖默认值）
    };
}

/**
 * 生成标准化错误响应（统一网络错误格式，与业务响应格式对齐）
 * 用于请求失败时（如网络异常、超时），返回结构一致的错误数据
 * @param message 错误提示信息（给用户看的文案，如"网络异常，请重试"）
 * @param description 错误详细描述（给开发看的信息，如"请求超时（10s）"，默认"网络请求失败"）
 * @returns 标准化错误响应（code=-1标识网络错误）
 */
export function createErrorResponse<T>(message: string, description: string = 'Network request failed'): HttpResponse<T> {
    return {
        code: -1, // 错误码：-1固定表示网络错误（区别于业务错误码）
        data: null as T, // 数据：网络错误时无有效数据，设为null
        message: message, // 用户可见错误提示
        timestamp: Date.now(), // 错误发生时间戳（毫秒级）
        description: description, // 错误详细描述（调试用）
        etag: '', // ETag：无值，设为空
        status: 'error' // 状态：固定"error"（便于上层判断）
    };
}

/**
 * 调试日志工具类（静态类，统一调试日志格式，含颜色标识便于区分）
 * 用途：打印请求加密前、响应解密后等关键节点的日志，辅助开发调试
 */
export class DebugLogger {
    /**
     * 打印加密前的请求参数日志
     * @param libraryName 库名称（如"Alova"，标识请求框架）
     * @param url 请求URL（便于定位接口）
     * @param params 待打印的参数（如请求方法、加密类型、原始body）
     */
    static logEncryptBefore(libraryName: string, url: string, params: any): void {
        logger.info(
            `%c🔍 [${libraryName} Request Interceptor] ${url} Parameters before encryption:`,
            'color: #FF9800; font-weight: bold', // 橙色加粗（区分加密前日志）
            params
        );
    }

    /**
     * 打印解密后的响应日志
     * @param libraryName 库名称（如"Alova"）
     * @param url 请求URL（便于定位接口）
     * @param data 解密后的响应数据（便于查看业务数据）
     */
    static logDecryptAfter(libraryName: string, url: string, data: any): void {
        logger.info(
            `%c🔍 [${libraryName} Request Interceptor] ${url} Decrypted response:`,
            'color: #4CAF50; font-weight: bold', // 绿色加粗（区分解密后日志）
            data
        );
    }

    /**
     * 打印跳过解密的日志（非RSA加密场景）
     * @param libraryName 库名称（如"Alova"）
     */
    static logSkipDecrypt(libraryName: string): void {
        logger.info(
            `%c🔍 [${libraryName} Request Interceptor] Non-RSA encryption, skip decryption`,
            'color: #9E9E9E; font-weight: bold', // 灰色加粗（区分跳过解密日志）
            'aaaa'
        );
    }
}

/**
 * 性能监控工具类（静态类，封装PerformanceMonitor，统一请求性能统计逻辑）
 * 用途：记录请求的开始/结束时间，统计成功/失败耗时，便于性能分析
 */
export class PerformanceTracker {
    /**
     * 开始性能监控（记录请求开始时间）
     * @param libraryName 库名称（如"Alova"，标识请求框架）
     * @returns 性能监控ID（用于结束监控时关联对应请求）
     */
    static start(libraryName: string): string {
        return performanceMonitor.start(libraryName);
    }

    /**
     * 结束性能监控（请求成功场景）
     * @param timerId 性能监控ID（start方法返回的ID）
     * @param url 请求URL（便于定位接口性能）
     */
    static endSuccess(timerId: string, url: string): void {
        performanceMonitor.end(timerId, `Success - ${url}`);
    }

    /**
     * 结束性能监控（请求失败场景）
     * @param timerId 性能监控ID
     * @param url 请求URL
     * @param reason 失败原因（可选，如"超时"、"解密失败"）
     */
    static endFailure(timerId: string, url: string, reason?: string): void {
        const failureMsg = reason ? `${reason} - ${url}` : `Failure - ${url}`;
        performanceMonitor.end(timerId, failureMsg);
    }
}

/**
 * 错误日志工具类（静态类，统一错误日志格式，便于问题定位）
 * 用途：分类打印网络错误、响应解析错误、HTTP状态码错误等日志
 */
export class ErrorLogger {
    /**
     * 打印网络错误日志（如断网、超时、节流）
     * @param comTag 日志标签（如"WEB请求-Alova"，标识请求来源）
     * @param error 错误对象（包含错误信息、堆栈等）
     * @param url 请求URL（便于定位接口）
     */
    static logNetworkError(comTag: string, error: any, url: string): void {
        logger.error(comTag, `Network request error:`, error, `URL=${url}`);
    }

    /**
     * 打印响应解析错误日志（如JSON.parse失败）
     * @param comTag 日志标签
     * @param error 错误对象
     * @param url 请求URL
     */
    static logParseError(comTag: string, error: any, url: string): void {
        logger.error(comTag, `Response parse error:`, error, `URL=${url}`);
    }

    /**
     * 打印HTTP状态码错误日志（如404、500）
     * @param comTag 日志标签
     * @param status HTTP状态码（如404、500）
     * @param data 响应数据（错误详情）
     * @param url 请求URL
     */
    static logHttpError(comTag: string, status: number, data: any, url: string): void {
        logger.error(comTag, `HTTP error (${status}):`, data, `URL=${url}`);
    }
}
