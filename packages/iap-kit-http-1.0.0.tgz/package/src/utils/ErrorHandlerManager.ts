/**
 * 错误处理管理器模块（单例模式）
 * 核心作用：统一管理HTTP请求的错误处理逻辑，支持动态注入自定义错误处理器，
 * 确保所有请求的错误处理行为一致，避免重复开发，同时支持初始化状态检查
 */

// 导入HTTP请求配置类型（错误处理需关联请求配置，如判断是否显示错误提示）
import { type HttpConfig } from './HttpConfig';
// 导入全局日志工具（用于输出初始化状态警告）
import { logger } from '@iap/kit-logger';

/**
 * 错误处理函数类型定义
 * 用于约束注入到管理器的错误处理逻辑，确保参数和返回值格式统一
 * @param data - 后端返回的原始响应数据（可能包含错误码、错误信息等）
 * @param config - 对应的HTTP请求配置（可用于根据请求配置差异化处理错误，如isSerErrTips控制是否显示提示）
 * @returns 处理后的响应数据（通常修正错误码、补充错误信息，或抛出标准化错误）
 */
export type ErrorHandler = (data: any, config: HttpConfig) => any;

/**
 * 错误处理管理器（单例实现）
 * 设计模式：单例模式 + 依赖注入
 * 核心能力：
 * 1. 全局唯一实例，确保错误处理逻辑统一
 * 2. 支持注入自定义ErrorHandler，适配不同业务的错误处理需求
 * 3. 提供初始化状态检查，避免未初始化时调用错误处理
 * 4. 支持重置（用于测试场景，清空已注入的处理器）
 */
export class ErrorHandlerManager {
    /** 单例实例（私有静态属性，确保全局唯一） */
    private static instance: ErrorHandlerManager;

    /** 注入的错误处理函数（私有属性，仅通过init方法设置） */
    private errorHandler: ErrorHandler | null = null;

    /** 初始化状态标记（私有属性，标记是否已成功注入错误处理函数） */
    private isInitialized = false;

    /**
     * 私有构造函数（单例模式核心，禁止外部通过new创建实例）
     */
    private constructor() {}

    /**
     * 获取错误处理管理器的单例实例
     * @returns ErrorHandlerManager - 全局唯一的实例
     * @description 外部需通过此方法获取实例，而非直接new，确保单例特性
     */
    public static getInstance(): ErrorHandlerManager {
        // 若实例未创建，则创建新实例；否则直接返回已有实例
        if (!ErrorHandlerManager.instance) {
            ErrorHandlerManager.instance = new ErrorHandlerManager();
        }
        return ErrorHandlerManager.instance;
    }

    /**
     * 初始化错误处理器（注入自定义错误处理逻辑）
     * @param errorHandler - 自定义错误处理函数（需符合ErrorHandler类型约束）
     * @description 必须在使用handleError前调用，否则错误处理会跳过；调用后会标记初始化完成
     */
    public init(errorHandler: ErrorHandler): void {
        // 存储注入的错误处理函数
        this.errorHandler = errorHandler;
        // 标记初始化完成（后续isReady会返回true）
        this.isInitialized = true;
    }

    /**
     * 检查错误处理器是否已初始化就绪
     * @returns boolean - true：已初始化（errorHandler存在且isInitialized为true）；false：未初始化
     * @description 用于在调用handleError前判断，避免未注入处理器时执行无效逻辑
     */
    public isReady(): boolean {
        return this.isInitialized && this.errorHandler !== null;
    }

    /**
     * 执行错误处理（核心方法，调用注入的错误处理函数）
     * @param data - 后端返回的原始响应数据（含错误信息）
     * @param config - 对应的HTTP请求配置（用于差异化处理，如根据isSerErrTips决定是否弹窗）
     * @returns any - 错误处理后的响应数据（由注入的errorHandler决定返回格式）
     * @description 若未初始化（isReady为false），会输出警告日志并直接返回原始数据，不中断流程
     */
    public handleError(data: any, config: HttpConfig): any {
        // 未初始化时，输出警告并返回原始数据（避免阻断正常请求流程）
        if (!this.isReady()) {
            logger.warn('ErrorHandler not initialized, skipping error handling');
            return data;
        }

        // 已初始化，调用注入的错误处理函数并返回结果
        return this.errorHandler!(data, config);
    }

    /**
     * 重置错误处理器（清空状态，用于测试或重新初始化场景）
     * @description 重置后isInitialized变为false，errorHandler变为null，需重新调用init注入处理器
     */
    public reset(): void {
        this.errorHandler = null;
        this.isInitialized = false;
    }
}

/**
 * 导出错误处理管理器的单例实例
 * @description 全局唯一，外部模块直接导入此实例即可使用，无需重复调用getInstance
 */
export const errorHandlerManager = ErrorHandlerManager.getInstance();
