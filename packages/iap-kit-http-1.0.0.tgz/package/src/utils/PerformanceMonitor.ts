import { logger } from '@iap/kit-logger';

/**
 * 性能监控工具
 * 用于检测不同请求库的性能差异
 */
class PerformanceMonitor {
    private timers: Map<string, number> = new Map(); // 计时器ID -> 开始时间
    private metrics: Map<string, number[]> = new Map(); // 标签 -> 耗时数组
    private isEnabled = process.env.NODE_ENV === 'development';

    /**
     * 开始计时
     * @param label 标签名称
     * @returns 计时器ID
     */
    start(label: string): string {
        if (!this.isEnabled) return '';

        const timerId = `${label}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const startTime = performance.now();

        this.timers.set(timerId, startTime);
        return timerId;
    }

    /**
     * 结束计时并记录结果
     * @param timerId 计时器ID
     * @param additionalInfo 额外信息
     */
    end(timerId: string, additionalInfo?: string): void {
        if (!this.isEnabled || !timerId) return;

        const startTime = this.timers.get(timerId);
        if (!startTime) return;

        const endTime = performance.now();
        const duration = endTime - startTime;

        // 记录性能数据
        const label = timerId.split('_')[0] || 'unknown';
        if (!this.metrics.has(label)) {
            this.metrics.set(label, []);
        }
        this.metrics.get(label)!.push(duration);

        // 输出性能信息
        const info = additionalInfo ? ` (${additionalInfo})` : '';
        logger.info(`🚀 [${label}] Duration: ${duration.toFixed(2)}ms${info}`);

        // 清理计时器
        this.timers.delete(timerId);
    }

    /**
     * 获取性能统计
     * @param label 标签名称
     * @returns 性能统计信息
     */
    getStats(label: string): {
        count: number;
        avg: number;
        min: number;
        max: number;
        total: number;
    } | null {
        const durations = this.metrics.get(label);
        if (!durations || durations.length === 0) return null;

        const total = durations.reduce((sum, duration) => sum + duration, 0);
        const avg = total / durations.length;
        const min = Math.min(...durations);
        const max = Math.max(...durations);

        return { count: durations.length, avg, min, max, total };
    }

    /**
     * 输出所有性能统计
     */
    printAllStats(): void {
        if (!this.isEnabled) return;

        console.group('📊 Performance Statistics Report');
        for (const [label] of this.metrics) {
            const stats = this.getStats(label);
            if (stats) {
                logger.info(`${label}:`);
                logger.info(`  Count: ${stats.count}`);
                logger.info(`  Average: ${stats.avg.toFixed(2)}ms`);
                logger.info(`  Min: ${stats.min.toFixed(2)}ms`);
                logger.info(`  Max: ${stats.max.toFixed(2)}ms`);
                logger.info(`  Total: ${stats.total.toFixed(2)}ms`);
                logger.info('---');
            }
        }
        console.groupEnd();
    }

    /**
     * 清理所有数据
     */
    clear(): void {
        this.timers.clear();
        this.metrics.clear();
    }

    /**
     * 启用/禁用性能监控
     */
    setEnabled(enabled: boolean): void {
        this.isEnabled = enabled;
    }
}

export default new PerformanceMonitor();
