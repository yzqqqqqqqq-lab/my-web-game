import { type HttpConfig } from './HttpConfig';
import { logger } from '@iap/kit-logger';

// 错误码处理配置类型
export type ErrorCodeHandler = {
    message: string;
    action?: 'toast' | 'dialog' | 'custom';
    customHandler?: (data: any, config: HttpConfig) => void;
};

// 错误码处理映射配置 - 基础版本，应用层可以扩展
export const errorCodeMappings: Record<number, ErrorCodeHandler> = {
    // === 服务端系统级错误 ===
    1001500: { message: 'Service error', action: 'toast' },
    [-1344]: { message: 'Data error', action: 'toast' },

    // === 用户认证授权相关错误 ===
    1001401: { message: 'Login again', action: 'toast' },
    1002203: { message: 'Account has been logged out', action: 'toast' },

    // === 账号安全限制错误 ===
    1002501: { message: 'Account is restricted', action: 'toast' },
    1002502: { message: 'Account is restricted', action: 'toast' },
    1002503: { message: 'Account is restricted', action: 'toast' },

    // === 基础错误处理 ===
    1022111: { message: 'Email format is incorrect.', action: 'toast' },
    1022202: { message: 'Incorrect passwords or phone number', action: 'toast' },
    1022811: { message: 'Incorrect verification code', action: 'toast' },
    1022806: { message: 'Verification code expired', action: 'toast' }
};

// 处理错误码 - 基础实现，应用层可以覆盖
export function handleErrorCode(data: any, config: HttpConfig): any {
    const { code, message } = data;
    const errorConfig = errorCodeMappings[code];

    // 成功响应直接返回
    if (code === 200) return data;

    // 处理预定义错误码
    if (errorConfig) {
        switch (errorConfig.action) {
            case 'toast':
                // 基础实现：只记录日志，应用层需要实现具体的 toast 显示
                logger.warn(`Error ${code}: ${errorConfig.message}`);
                break;
            case 'dialog':
            case 'custom':
                errorConfig.customHandler?.(data, config);
                break;
        }
        return data;
    }

    // 处理未映射的错误码
    if (message && config.isSerErrTips !== false) {
        logger.warn(`Unhandled error ${code}: ${message}`);
    }

    return data;
}
