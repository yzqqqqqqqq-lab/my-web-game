import axios, { type AxiosRequestConfig, AxiosError } from 'axios';
import { defaultConfig, type HttpConfig, type HttpResponse } from './utils/HttpConfig';
import { errorHandlerManager } from './utils/ErrorHandlerManager';
import {
    buildRequestBody,
    encryptRequestBody,
    decryptResponseData,
    checkThrottle,
    mergeConfig,
    createErrorResponse,
    DebugLogger,
    PerformanceTracker,
    ErrorLogger
} from './utils/httpUtils';
import PerformanceMonitor from './utils/PerformanceMonitor';

export const comTag = 'Http-Axios'; // Axios versions of log tags

// Axios 请求器 - 核心请求执行函数，通过拦截器处理业务逻辑
async function axiosFetcher<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    // 检查错误处理器是否已初始化
    if (!errorHandlerManager.isReady()) {
        throw new Error('ErrorHandler not initialized. Please call errorHandlerManager.init() before making requests.');
    }

    // 合并默认配置，确保 encryptionType 等配置正确传递
    const finalConfig = mergeConfig(config);
    const { url, baseUrl, method, headers = {}, timeout, signal, body } = finalConfig;

    interface AxiosRequestCfg extends AxiosRequestConfig {
        httpConfig: HttpConfig;
    }

    // 直接构建 axios 配置
    const axiosConfig: AxiosRequestCfg = {
        url: `${baseUrl || defaultConfig.baseUrl}${url}`,
        method: (method || defaultConfig.method) as any,
        headers: { ...defaultConfig.headers, ...headers },
        timeout: timeout || defaultConfig.timeout,
        signal,
        // 原始请求体将在请求拦截器中处理
        ...(body && method !== 'GET' && { data: body }),
        // 将原始 HttpConfig 存储在 axios config 中，供拦截器使用
        httpConfig: finalConfig
    };

    try {
        const response = await axios(axiosConfig);
        // 拦截器已经处理了响应数据，直接返回
        return response.data;
    } catch (error: unknown) {
        // 拦截器处理后的错误响应
        const axiosError = error as AxiosError;
        return (
            (axiosError.response?.data as HttpResponse<T>) ||
            createErrorResponse<T>(axiosError.message || 'Network Error')
        );
    }
}

// 初始化 axios 全局配置
function initAxiosConfig() {
    axios.defaults.timeout = defaultConfig.timeout!;
    axios.defaults.headers.common = {
        ...axios.defaults.headers.common,
        ...defaultConfig.headers
    };
    axios.defaults.headers.accept = '*/*';

    // 请求拦截器 - 处理节流检查、加密等业务逻辑
    axios.interceptors.request.use((config) => {
        // 从 axios config 中提取原始 HttpConfig
        const httpConfig = (config as any).httpConfig as HttpConfig;
        if (!httpConfig) return config;

        // 节流检查
        checkThrottle(httpConfig);

        // 构建请求体并加密
        const { body: encryptedBody, headers: encryptedHeaders } = encryptRequestBody(
            { ...httpConfig, comTag },
            buildRequestBody(httpConfig)
        );

        DebugLogger.logEncryptBefore('Axios', httpConfig.url, {
            method: httpConfig.method,
            encryptionType: httpConfig.encryptionType,
            body: config.data
        });

        // 更新请求配置
        if (encryptedBody && config.method !== 'GET') config.data = encryptedBody;
        config.headers = { ...config.headers, ...encryptedHeaders };

        // 记录性能监控开始
        (config as any).timerId = PerformanceTracker.start('Axios');

        return config;
    });

    // 响应拦截器 - 处理解密、错误处理等业务逻辑
    axios.interceptors.response.use(
        (response) => {
            const httpConfig = (response.config as any).httpConfig as HttpConfig;
            const timerId = (response.config as any).timerId;

            if (!httpConfig) return response;

            let responseData = response.data;

            // RSA解密
            if (httpConfig.encryptionType === 'RSA') {
                responseData = decryptResponseData(responseData);
            } else {
                DebugLogger.logSkipDecrypt('Axios');
            }
            DebugLogger.logDecryptAfter('Axios', httpConfig.url, responseData);

            // 根据错误码映射表处理业务错误
            response.data = errorHandlerManager.handleError(responseData, httpConfig);

            // 记录性能监控结束
            PerformanceTracker.endSuccess(timerId, httpConfig.url);

            return response;
        },
        (error: AxiosError) => {
            const httpConfig = (error.config as any).httpConfig as HttpConfig;
            const timerId = (error.config as any).timerId;

            if (!httpConfig) return Promise.reject(error);

            const url = error.response?.config?.url || httpConfig.url;
            ErrorLogger.logNetworkError(comTag, error, url);
            PerformanceTracker.endFailure(timerId, url);

            const errorResponse = createErrorResponse(
                error.message || 'Network Error',
                (error.response?.data as any)?.message || error.message || 'Network Error'
            );

            if (error.response) {
                error.response.data = errorResponse;
            } else {
                // 创建一个模拟的响应对象
                (error as any).response = { data: errorResponse };
            }

            return Promise.reject(error);
        }
    );
}

// 延迟初始化，避免模块加载时的依赖问题
if (typeof window !== 'undefined') {
    setTimeout(() => {
        initAxiosConfig();
    }, 0);
}

// 主导出函数 - Axios版本的核心请求方法，兼容原有API
export async function comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
    return axiosFetcher<T>(config);
}

// 导出性能监控工具，方便在控制台查看统计
export { PerformanceMonitor };
