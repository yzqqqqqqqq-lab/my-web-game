/**
 * HTTP请求统一管理类（适配多请求库，提供一致的请求接口）
 * 核心功能：整合alova/axios/ky/swr等主流请求库，支持动态切换请求库、统一错误处理、拦截器配置
 */

// 导入各请求库的具体实现（每个库封装了对应请求逻辑，对外暴露comRequest方法）
import { comRequest as comRequestAlova, comTag as comTagAlova, type IInterceptor } from './comRequest-alova';
import { comRequest as comRequestAxios, comTag as comTagAxios } from './comRequest-axios';
import { comRequest as comRequestKy, comTag as comTagKy } from './comRequest-ky';
import { comRequest as comRequestSWR, comTag as comTagSWR } from './comRequest-swr';

// 导入错误处理器管理器（统一管理错误处理逻辑）和HTTP配置类型
import { errorHandlerManager, type ErrorHandler } from './utils/ErrorHandlerManager';
import type { EncryptionType, HttpConfig, HttpResponse } from './utils/HttpConfig';

// 导出HTTP配置和响应类型（供外部使用，确保类型一致）
export type { HttpConfig, HttpResponse };

/**
 * 支持的请求库类型枚举
 * 限定可使用的请求库，确保类型安全，避免传入无效库名
 */
export type THttpLib = 'alova' | 'axios' | 'ky' | 'swr';

/**
 * Http类构造函数参数类型
 * 用于初始化Http实例的配置项
 */
interface HttpProps {
    baseUrl?: string;
    encryptionType?: EncryptionType;
    httpLib?: THttpLib; // 可选，指定默认使用的请求库（默认alova）
    headerBasic: Record<string, any>; // 基础头信息（会被整合到请求头中）
    setErrorHandler: (errorHandler: ErrorHandler, method: any) => Promise<void>; // 错误处理器设置函数（用于初始化全局错误处理）
}

/**
 * HTTP请求统一管理类
 * 作用：
 * 1. 屏蔽不同请求库的接口差异，提供统一的comRequest方法
 * 2. 支持动态切换请求库（alova/axios/ky/swr）
 * 3. 统一管理错误处理逻辑和请求拦截器
 */
class Http {
    /** 基础头信息存储（如设备信息、版本号等公共头数据） */
    private headerBasic: Record<string, any>;

    /** 当前使用的请求库（默认alova，可通过构造函数或后续逻辑修改） */
    private httpLib: THttpLib = 'alova';

    /** 拦截器配置（主要用于alova库，存储请求/响应拦截逻辑） */
    private interceptor: IInterceptor = {};

    private baseUrl?: string = '';

    private encryptionType?: EncryptionType = 'RSA';

    /**
     * 获取当前请求库对应的日志标签
     * 用途：打印日志时区分不同请求库，便于调试和问题定位
     */
    get comTag(): string {
        switch (this.httpLib) {
            case 'alova':
                return comTagAlova;
            case 'axios':
                return comTagAxios;
            case 'ky':
                return comTagKy;
            case 'swr':
                return comTagSWR;
            default:
                return '';
        }
    }

    /**
     * 构造函数（初始化Http实例）
     * @param props 初始化参数（包含请求库选择、基础头、错误处理器）
     */
    constructor(props: HttpProps) {
        // 若指定了请求库，则覆盖默认值（alova）
        if (props.httpLib) {
            this.httpLib = props.httpLib;
        }
        this.encryptionType = props.encryptionType;
        this.baseUrl = props.baseUrl;
        // 存储基础头信息（后续可被整合到请求配置中）
        this.headerBasic = props.headerBasic;
        // 初始化错误处理器（若提供了setErrorHandler函数）
        if (typeof props.setErrorHandler === 'function') {
            errorHandlerManager.init(props.setErrorHandler);
        }
    }

    /**
     * 统一请求方法（根据当前选择的请求库调用对应实现）
     * @param config 请求配置（符合HttpConfig类型，包含url、method、headers等）
     * @returns Promise<HttpResponse<T>> 标准化响应（与请求库无关，结构统一）
     */
    comRequest<T>(config: HttpConfig): Promise<HttpResponse<T>> {
        switch (this.httpLib) {
            case 'alova':
                // 调用alova的请求实现，传入配置和拦截器
                return comRequestAlova(
                    {
                        ...config,
                        ...(this.baseUrl && { baseUrl: this.baseUrl }),
                        ...(this.encryptionType && { encryptionType: this.encryptionType })
                    },
                    this.interceptor,
                    this.headerBasic
                );
            case 'axios':
                // 调用axios的请求实现
                return comRequestAxios(config);
            case 'ky':
                // 调用ky的请求实现
                return comRequestKy(config);
            case 'swr':
                // 调用swr的请求实现（swr通常用于React数据请求，此处统一接口）
                return comRequestSWR(config);
            default:
                // 兜底：若未匹配到任何库，使用原生fetch（类型断言适配，实际项目中建议避免）
                return fetch(config as any) as Promise<any>;
        }
    }

    /**
     * 设置拦截器配置（主要针对alova库，其他库可通过各自方式配置拦截器）
     * @param config 拦截器配置（包含请求前、响应后等拦截逻辑）
     */
    setInterceptor(config: IInterceptor) {
        this.interceptor = config;
    }

    /**
     * 设置基础header的接口方法 。
     * **/
    setHeaderBasic(basic: Record<string, any>) {
        this.headerBasic = basic;
    }
}

// 导出Http类（作为默认导出，供外部实例化使用）
export default Http;
