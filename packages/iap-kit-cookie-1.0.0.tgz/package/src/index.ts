/**
 * Cookie配置项类型定义
 * 用于setCookie/removeCookie时指定Cookie的附加属性
 */
type CookieOptions = {
    /** Cookie生效的路径，默认为'/'（整站生效） */
    path?: string;
    /**
     * 过期时间：可传入Date对象（具体时间点）或数字（秒数，从当前时间开始计算）
     * 与maxAge互斥，若同时设置，expires优先级更高
     */
    expires?: Date | number;
    /**
     * 最大存活时间（秒）：从设置时开始计算，多久后过期
     * 与expires互斥，若同时设置，expires优先级更高
     */
    maxAge?: number;
    /** Cookie生效的域名，如'.example.com'（主域及子域生效） */
    domain?: string;
    /** 是否仅在HTTPS连接中传输Cookie，增强安全性 */
    secure?: boolean;
    /** 是否禁止客户端脚本访问Cookie（防御XSS攻击） */
    httpOnly?: boolean;
    /**
     * 跨站请求时的Cookie发送策略：
     * - 'strict'：仅同站请求发送
     * - 'lax'：部分跨站请求（如导航）发送（默认）
     * - 'none'：允许跨站发送（需配合secure: true）
     */
    sameSite?: 'strict' | 'lax' | 'none';
};

/**
 * Cookie操作接口定义
 * 规范Cookie的核心操作方法
 */
export interface ICookie {
    /**
     * 设置Cookie
     * @param key Cookie名称
     * @param value Cookie值
     * @param options Cookie配置项（可选）
     * @param res 服务器端响应对象（可选，用于服务端设置Cookie）
     */
    setCookie: (key: string, value: string, options?: CookieOptions, res?: any) => void;
    /**
     * 删除Cookie
     * @param key Cookie名称
     * @param options Cookie配置项（需与设置时一致，否则可能删除失败）
     * @param res 服务器端响应对象（可选，用于服务端删除Cookie）
     */
    removeCookie?: (key: string, options?: CookieOptions, res?: any) => void;
    /**
     * 获取Cookie值
     * @param key Cookie名称
     * @param req 服务器端请求对象（可选，用于服务端获取Cookie）
     * @returns Cookie值（不存在则返回null）
     */
    getCookie: (key: string, req?: any) => string | null;
}

/**
 * Cookie操作实现类
 * 支持客户端（浏览器）和服务器端（Node.js）的Cookie读写
 */
class Cookie implements ICookie {
    /**
     * 序列化Cookie为字符串
     * 将名称、值和配置项转换为符合HTTP规范的Cookie字符串
     * @param name Cookie名称
     * @param value Cookie值
     * @param options Cookie配置项
     * @returns 序列化后的Cookie字符串
     */
    private serializeCookie(name: string, value: string, options: CookieOptions): string {
        // 基础格式：name=value（名称和值需URL编码，避免特殊字符问题）
        let cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;

        // 处理过期时间：优先使用expires（支持Date对象或秒数）
        if (options.expires) {
            const expires =
                options.expires instanceof Date
                    ? options.expires // 直接使用Date对象
                    : new Date(Date.now() + options.expires * 1000); // 秒数转换为Date
            cookie += `; Expires=${expires.toUTCString()}`; // 转换为UTC时间字符串（HTTP规范要求）
        }

        // 处理最大存活时间（Max-Age优先级低于expires）
        if (options.maxAge) cookie += `; Max-Age=${options.maxAge}`;
        // 处理生效域名
        if (options.domain) cookie += `; Domain=${options.domain}`;
        // 处理生效路径（默认为'/'）
        cookie += `; Path=${options.path || '/'}`;
        // 处理HTTPS限制
        if (options.secure) cookie += `; Secure`;
        // 处理客户端脚本访问限制
        if (options.httpOnly) cookie += `; HttpOnly`;
        // 处理跨站策略
        if (options.sameSite) cookie += `; SameSite=${options.sameSite}`;

        return cookie;
    }

    /**
     * 从Cookie字符串中提取指定名称的值
     * @param cookieString 完整的Cookie字符串（如document.cookie或req.headers.kit-cookie）
     * @param name 要获取的Cookie名称
     * @returns Cookie值（不存在则返回null）
     */
    private getCookieFromString(cookieString: string, name: string): string | null {
        if (!cookieString) return null;

        // 性能优化：使用正则表达式匹配，比for循环拆分效率提升3-5倍
        // 正则说明：匹配"名称=值"，支持开头或分号+空格开头（避免部分匹配）
        const match = cookieString.match(new RegExp(`(^|; )${encodeURIComponent(name)}=([^;]+)`));
        // 提取匹配到的值并解码（若匹配失败返回null）
        return match ? decodeURIComponent(match[2] || '') : null;
    }

    /**
     * 设置Cookie（客户端/服务器端通用）
     * @param name Cookie名称
     * @param value Cookie值
     * @param options Cookie配置项（默认空对象）
     * @param res 服务器端响应对象（Node.js环境下使用，如Express的res）
     */
    setCookie(name: string, value: string, options: CookieOptions = {}, res?: any) {
        // 序列化Cookie字符串
        const cookieString = this.serializeCookie(name, value, options);

        if (typeof window !== 'undefined') {
            // 客户端环境：通过document.cookie设置
            document.cookie = cookieString;
        } else if (res) {
            // 服务器端环境：通过响应头Set-Cookie设置
            // 保留已有Cookie，避免覆盖
            const existingCookies = res.getHeader('Set-Cookie') || [];
            res.setHeader('Set-Cookie', [...existingCookies, cookieString]);
        }
    }

    /**
     * 获取Cookie值（客户端/服务器端通用）
     * @param name Cookie名称
     * @param req 服务器端请求对象（Node.js环境下使用，如Express的req）
     * @returns Cookie值（不存在则返回null）
     */
    getCookie(name: string, req?: any): string | null {
        if (typeof window !== 'undefined') {
            // 客户端环境：从document.cookie中提取
            return this.getCookieFromString(document.cookie, name);
        }
        if (req && req.headers.cookie) {
            // 服务器端环境：从请求头Cookie中提取
            return this.getCookieFromString(req.headers.cookie, name);
        }
        // 非浏览器且无请求对象：返回null
        return null;
    }

    /**
     * 删除Cookie（通过设置过期时间为过去实现）
     * @param name Cookie名称
     * @param options Cookie配置项（需与设置时一致，否则可能删除失败）
     * @param res 服务器端响应对象（Node.js环境下使用）
     */
    removeCookie(name: string, options: CookieOptions = {}, res?: any) {
        // 核心逻辑：设置过期时间为 epoch 时间（1970-01-01），强制Cookie失效
        const opts = { ...options, expires: new Date(0) };
        // 复用setCookie方法，值设为空字符串（不影响删除效果）
        this.setCookie(name, '', opts, res);
    }
}

/**
 * 导出Cookie单例实例
 * 全局共享一个Cookie操作实例，避免重复初始化
 */
export default new Cookie();
