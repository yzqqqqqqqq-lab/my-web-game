import typescript from '@rollup/plugin-typescript';
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import terser from '@rollup/plugin-terser';
import json from '@rollup/plugin-json';
import nodePolyfills from 'rollup-plugin-polyfill-node';
import dts from 'rollup-plugin-dts';
import postcss from 'rollup-plugin-postcss';
import { nodeExternals } from 'rollup-plugin-node-externals';
import alias from '@rollup/plugin-alias';
import replace from '@rollup/plugin-replace';
import obfuscator from 'rollup-plugin-obfuscator';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';

// ----------------------
// ⚠️ Warnings 过滤函数
function handleWarnings(warning, warn) {
	if (
		warning.message?.includes('"use client"') ||
		warning.code === 'CIRCULAR_DEPENDENCY' ||
		warning.code === 'THIS_IS_UNDEFINED'
	) return;
	warn(warning);
}

// ----------------------
// ⚠️ 外部化 React
const externalDeps = ['react', 'react-dom', 'react/jsx-runtime'];
const umdGlobals = { react: 'React', 'react-dom': 'ReactDOM' };

// 判断是否为开发模式
const isDev = process.env.NODE_ENV === 'development';
// 判断是否开启混淆 (OBFUSCATE=true)
const isObfuscate = process.env.OBFUSCATE === 'true';
console.log(`\n🛠️  [Rollup Config] OBFUSCATE mode: ${isObfuscate}\n`);

// 开发模式使用独立 source map 文件（浏览器更容易识别）
// 生产模式也使用独立文件
// 生产环境或混淆模式下禁用 sourcemap 以减小体积
const sourcemapType = isDev && !isObfuscate;

// 混淆配置 (极致体积优化)
const obfuscatorConf = {
	compact: true,                     // 压缩代码，移除换行和空格 (减小体积)
	controlFlowFlattening: false,      // [重要] 关闭控制流扁平化，开启会导致体积膨胀 50%+ (体积优先)
	deadCodeInjection: false,          // [重要] 关闭死代码注入，避免体积无意义增加 (体积优先)
	debugProtection: false,            // 关闭调试保护 (开发者体验/体积)
	stringArray: true,                 // 开启字符串阵列 (基础保护)
	stringArrayEncoding: ['rc4'],      // 使用 RC4 编码字符串阵列 (通过消耗少量计算性能换取更高的逆向成本)
	stringArrayThreshold: 1,           // 100% 的字符串都放入阵列 (安全性)
	stringArrayRotate: true,           // 开启阵列旋转 (安全性)
	stringArrayShuffle: true,          // 开启阵列打乱 (安全性)
	identifierNamesGenerator: 'hexadecimal', // 使用十六进制变量名 (_0x...) (安全性/混淆感强)
	unicodeEscapeSequence: false,      // 关闭 Unicode 转义，避免体积膨胀 (体积优先)
	seed: 12345,                       // 固定种子，确保每次构建产物一致 (稳定性)
};

function loadLocalConfig() {
	const configPath = path.resolve('./rollup.config.js');
	if (fs.existsSync(configPath)) {
		const code = fs.readFileSync(configPath, 'utf-8');
		// 在沙箱里执行 CommonJS 风格
		const sandbox = { module: {}, exports: {} };
		sandbox.module.exports = sandbox.exports;
		vm.createContext(sandbox);
		vm.runInContext(code, sandbox);
		return sandbox.module.exports;
	}
	return {};
}

function getInputs() {
	return {
		index: 'src/index.ts',
		...loadLocalConfig()?.input ?? {}
	};
}

export default [
	// ======================
	// ESM + CJS
	{
		input: getInputs(),
		output: [
			{
				dir: 'dist',
				format: 'esm',
				sourcemap: sourcemapType,
				sourcemapPathTransform: (relativeSourcePath) => {
					// 将相对路径转换为绝对路径，便于浏览器正确加载
					const projectRoot = process.cwd();
					return path.resolve(projectRoot, relativeSourcePath.replace(/^\.\.\//, ''));
				},
				entryFileNames: '[name].esm.js'
			},
			{
				dir: 'dist',
				format: 'cjs',
				sourcemap: sourcemapType,
				sourcemapPathTransform: (relativeSourcePath) => {
					const projectRoot = process.cwd();
					return path.resolve(projectRoot, relativeSourcePath.replace(/^\.\.\//, ''));
				},
				entryFileNames: '[name].cjs.js',
				exports: 'named'
			},
		],
		external: externalDeps,
		plugins: [
			nodeExternals({
				// 当开启 BUNDLE_INTERNAL 时，不将 @iap/ 开头的包视为外部依赖，从而触发 Rollup 将其打包进产物
				exclude: process.env.BUNDLE_INTERNAL === 'true' ? [/^@iap\//] : []
			}),
			nodePolyfills(),
			json(),
			alias({
				entries: [
					{ find: 'axios/lib/adapters/http', replacement: 'axios/lib/adapters/xhr.js' },
				],
			}),
			replace({
				'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production'),
				preventAssignment: true,
			}),
			resolve({ browser: true, preferBuiltins: false }),
			commonjs(),
			postcss({
				extensions: ['.css'],
				extract: true,  // 输出单独 CSS 文件
				minimize: true,
			}),
			typescript({
				tsconfig: './tsconfig.json',
				declaration: true,
				declarationMap: true,
				sourceMap: true,
				inlineSources: false, // 不使用 inline sources
				target: 'ESNext',
				outputToFilesystem: true,
			}),
			isObfuscate && obfuscator({
				...obfuscatorConf,
				include: ['**/*.js', '**/*.ts'],
			}),
		],
		onwarn: handleWarnings,
	},

	// ======================
	// UMD
	{
		input: 'src/index.ts',
		output: {
			file: 'dist/index.umd.js',
			format: 'umd',
			name: (() => {
				const pkgPath = path.resolve(process.cwd(), 'package.json');
				let baseName = '';
				try {
					const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
					baseName = typeof pkg.name === 'string' ? pkg.name : '';
				} catch { }
				if (!baseName) baseName = path.basename(process.cwd());
				baseName = baseName.replace(/^@[^/]+\//, '');
				return baseName.replace(/(^|[^a-zA-Z0-9]+)([a-zA-Z0-9])/g, (_, __, c) => c.toUpperCase())
					.replace(/[^a-zA-Z0-9]/g, '') || 'Library';
			})(),
			globals: umdGlobals,
			sourcemap: sourcemapType,
		},
		external: externalDeps,
		plugins: [
			nodePolyfills(),
			json(),
			alias({
				entries: [
					{ find: 'axios/lib/adapters/http', replacement: 'axios/lib/adapters/xhr.js' },
				],
			}),
			replace({
				'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production'),
				preventAssignment: true,
			}),
			resolve({ browser: true, preferBuiltins: false }),
			commonjs(),
			postcss({
				extensions: ['.css'],
				extract: true,
				minimize: true,
			}),
			typescript({
				tsconfig: './tsconfig.json',
				declaration: true,
				declarationMap: true,
				sourceMap: true,
				target: 'ES2015',
				outputToFilesystem: true,
			}),
			terser({
				format: { comments: false },
				compress: {
					drop_console: false, // 保持 SDK 核心日志 (info, warn, error)
					pure_funcs: isObfuscate ? ['console.debug'] : [], // 混淆(生产)模式下剔除 console.debug 以精简体积
				},
			}),
		].filter(Boolean),
		onwarn: handleWarnings,
	},

	// ======================
	// DTS 类型输出
	{
		input: getInputs(),
		output: { dir: 'dist', format: 'es' },
		plugins: [dts()],
		onwarn: handleWarnings,
	},
];
