'use client';
import { logger } from '@iap/kit-logger';
import Encrypt, { AESHelper } from '@iap/kit-encryptor';

/** 存储类型 */
export type StorageType = 'storage' | 'session';

/** 存储接口 */
export interface IStorage {
    /** 是否支持localStorage（浏览器环境+API存在） */
    supportLocalStorage: boolean;
    /** 是否支持sessionStorage（浏览器环境+API存在） */
    supportSessionStorage: boolean;
    /** 存储到 localStorage */
    setStorage: (key: string, value: any) => void;
    /** 从 localStorage 获取 */
    getStorage: (key: string, def?: any) => any;
    /** 删除 localStorage 数据（不传 key 则清空全部） */
    removeStorage: (key?: string) => void;
    /** 清空指定键或全部 */
    clear(key?: string): void;
    /** 清空全部 */
    clearAll(): void;
    /** 检查 localStorage 是否存在键 */
    hasStorage: (key: string) => boolean;
    /** 存储到 sessionStorage */
    setSession: (key: string, value: any) => void;
    /** 删除 sessionStorage 数据（不传 key 则清空全部） */
    removeSession: (key?: string) => void;
    /** 从 sessionStorage 获取（自动转换 boolean/number） */
    getSession: (key: string, def?: any) => any;
}

/** 存储工具：支持加密、序列化、向后兼容 */
class Storage implements IStorage {
    static tag: string = '[Storage]';

    get supportLocalStorage(): boolean {
        return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
    }

    get supportSessionStorage(): boolean {
        return typeof window !== 'undefined' && typeof window.sessionStorage !== 'undefined';
    }

    /** 加密数据 */
    private encryptData(data: string): string {
        return AESHelper.EncryptWeb(data, Encrypt.DATA_KEY);
    }

    /** 解密数据 */
    private decryptData(data: string): string {
        return AESHelper.DecryptWeb(data, Encrypt.DATA_KEY);
    }

    /** 序列化：对象加 'obj-' 前缀，基础类型加 'str-' 前缀 */
    private serializedValue(value: any): string | undefined {
        let serializedValue: string | undefined;
        if (typeof value === 'object') {
            serializedValue = 'obj-' + JSON.stringify(value);
        } else if (['string', 'number', 'boolean'].includes(typeof value)) {
            serializedValue = 'str-' + value.toString();
        } else {
            serializedValue = undefined;
        }
        return serializedValue;
    }

    /** 判断开关：值为 '1' 返回 true */
    hasKeySwitch(key: string): boolean {
        return this.getStorage(key) === '1';
    }

    /** 保存数据：根据加密开关决定是否加密 */
    private saveData(key: string, data: string, type: StorageType = 'storage'): void {
        if (Encrypt.isEncrypted) {
            const encryptedKey = this.encryptData(key);
            const encryptedData = this.encryptData(data);
            if (type === 'session') {
                sessionStorage.setItem(encryptedKey, encryptedData);
            } else {
                localStorage.setItem(encryptedKey, encryptedData);
            }
        } else {
            if (type === 'session') {
                sessionStorage.setItem(key, data);
            } else {
                localStorage.setItem(key, data);
            }
        }
    }

    /** 获取数据：支持向后兼容（自动迁移旧数据） */
    private getData(key: string, type: StorageType = 'storage'): string {
        if (Encrypt.isEncrypted) {
            try {
                // 1. 尝试获取加密后的键和数据
                const cipherKey = this.encryptData(key);
                const cipherText =
                    type === 'session' ? sessionStorage.getItem(cipherKey) : localStorage.getItem(cipherKey);

                if (!cipherText) {
                    // 2. 向后兼容：加密键无数据，尝试读原始键（旧数据）
                    const plainText = type === 'session' ? sessionStorage.getItem(key) : localStorage.getItem(key);

                    if (plainText) {
                        // 3. 自动迁移：将旧的非加密数据重新存储为加密数据
                        this.saveData(key, plainText, type);
                        // 4. 删除旧的非加密数据，避免冗余
                        if (type === 'session') {
                            sessionStorage.removeItem(key);
                        } else {
                            localStorage.removeItem(key);
                        }
                        return plainText; // 返回旧数据（后续会用加密数据）
                    }
                    return ''; // 无任何数据
                }

                // 5. 解密数据并返回
                const decrypted = this.decryptData(cipherText);
                return decrypted || '';
            } catch (e) {
                // 加密/解密异常：记录日志并返回空字符串
                logger.error(`${Storage.tag} key=${key} (Encryption) Data processing error:`, e);
                return '';
            }
        } else {
            // 不加密：直接获取原始数据
            try {
                return (type === 'session' ? sessionStorage.getItem(key) : localStorage.getItem(key)) || '';
            } catch (e) {
                logger.error(`${Storage.tag} key=${key} (Non-encryption) Data processing error:`, e);
                return '';
            }
        }
    }

    /** 存储到 localStorage */
    setStorage(key: string, value: any): void {
        // 1. 检查localStorage支持性，不支持则直接返回
        if (!this.supportLocalStorage) {
            return;
        }

        // 2. 验证键名和值的有效性，无效则抛错
        if (!key || value === undefined || value === null) {
            logger.error(`${Storage.tag} setStorage key ${key} Invalid (key must not be empty, value cannot be undefined/null)`);
            return;
        }

        // 3. 序列化数据，不支持的类型记录日志并返回
        const serializedValue = this.serializedValue(value);
        if (typeof serializedValue === 'undefined') {
            return logger.error(
                `${Storage.tag} setStorage key=${key} type=${typeof value} => Unsupported data type (only object/string/number/boolean supported)`
            );
        }

        // 4. 执行存储，异常时记录日志
        try {
            this.saveData(key, serializedValue);
        } catch (e) {
            logger.error(`${Storage.tag} setStorage key=${key} => Error setting localStorage:`, e);
        }
    }

    /** 从 localStorage 获取 */
    getStorage(key: string, def: any = ''): any {
        // 1. 检查localStorage支持性，不支持则返回默认值
        if (!this.supportLocalStorage) {
            return def;
        }

        // 2. 验证键名有效性，无效则抛错
        if (!key) {
            logger.error(`${Storage.tag} getStorage key=${key} Invalid (key must not be empty)`);
            return def;
        }

        try {
            // 3. 获取数据（自动处理加密/兼容逻辑）
            const data = this.getData(key);
            if (!data) {
                return def; // 无数据返回默认值
            }

            // 4. 反序列化：根据前缀识别类型
            if (data.startsWith('obj-')) {
                // 对象类型：去掉前缀后JSON解析
                return JSON.parse(data.slice(4));
            }
            if (data.startsWith('str-')) {
                // 基础类型：去掉前缀后直接返回
                return data.slice(4);
            }

            // 5. 未知数据类型：记录日志并返回默认值
            logger.error(`${Storage.tag} getStorage key=${key} Unknown data type (no valid prefix)`);
            return def;
        } catch (e) {
            // 6. 异常处理：记录日志并返回默认值
            logger.error(`${Storage.tag} getStorage key=${key} Error getting data:`, e);
            return def;
        }
    }

    /** 删除 localStorage 数据 */
    removeStorage(key?: string): void {
        // 1. 检查localStorage支持性，不支持则直接返回
        if (!this.supportLocalStorage) {
            return;
        }

        try {
            if (key) {
                // 2. 有键名：删除指定键（根据加密开关决定删除加密键还是原始键）
                const targetKey = Encrypt.isEncrypted ? this.encryptData(key) : key;
                localStorage.removeItem(targetKey);
            } else {
                // 3. 无键名：清空所有localStorage数据
                localStorage.clear();
            }
        } catch (e) {
            // 4. 异常处理：记录日志
            logger.error(`${Storage.tag} removeStorage key=${key} => Error removing localStorage:`, e);
        }
    }

    /** 清空指定键或全部 */
    clear(key?: string): void {
        this.removeStorage(key);
    }

    /** 清空全部 */
    clearAll() {
        this.removeStorage();
    }

    /** 检查 localStorage 是否存在键 */
    hasStorage(key: string): boolean {
        // 1. 检查localStorage支持性，不支持则返回false
        if (!this.supportLocalStorage) {
            return false;
        }

        // 2. 验证键名有效性，无效则抛错
        if (!key) {
            logger.error(`${Storage.tag} hasStorage key=${key} Invalid (key must not be empty)`);
            return false;
        }

        try {
            // 3. 检查键是否存在（注意：未处理加密键，需根据实际场景调整）
            return localStorage.getItem(key) !== null;
        } catch (e) {
            // 4. 异常处理：记录日志并返回false
            logger.error(`${Storage.tag} hasStorage key=${key} => Error checking localStorage:`, e);
            return false;
        }
    }

    /** 存储到 sessionStorage */
    setSession(key: string, value: any): void {
        // 1. 检查sessionStorage支持性，不支持则直接返回
        if (!this.supportSessionStorage) {
            return;
        }

        // 2. 验证键名和值的有效性，无效则抛错
        if (!key || value === undefined || value === null) {
            logger.error(`${Storage.tag} setSession key=${key} value=${value} Invalid (key must not be empty, value cannot be undefined/null)`);
            return;
        }

        // 3. 序列化数据，不支持的类型记录日志并返回
        const serializedValue = this.serializedValue(value);
        if (typeof serializedValue === 'undefined') {
            return logger.error(
                `${Storage.tag} setSession key=${key} type=${typeof value} => Unsupported data type (only object/string/number/boolean supported)`
            );
        }

        // 4. 执行存储，异常时记录日志
        try {
            this.saveData(key, serializedValue, 'session');
        } catch (e) {
            logger.error(`${Storage.tag} setSession key=${key} => Error setting sessionStorage:`, e);
        }
    }

    /** 从 sessionStorage 获取（自动转换 boolean/number） */
    getSession(key: string, def: any = ''): any {
        // 1. 检查sessionStorage支持性或键名为空，返回默认值
        if (!this.supportSessionStorage || !key) {
            return def;
        }

        try {
            if (typeof window !== 'undefined') {
                // 2. 获取数据（自动处理加密/兼容逻辑）
                const data = this.getData(key, 'session');
                if (!data) {
                    return def; // 无数据返回默认值
                }

                // 3. 反序列化：根据前缀识别类型并处理基础类型转换
                if (data.startsWith('obj-')) {
                    // 对象类型：去掉前缀后JSON解析
                    return JSON.parse(data.substring(4));
                } else if (data.startsWith('str-')) {
                    // 基础类型：去掉前缀后转换boolean/number
                    const strValue = data.slice(4);
                    if (strValue === 'true') return true; // 转换boolean
                    if (strValue === 'false') return false;
                    if (!isNaN(Number(strValue)) && strValue !== '') {
                        return Number(strValue); // 转换number
                    }
                    return strValue; // 剩余情况返回string
                } else {
                    // 无前缀数据：直接返回（兼容旧数据）
                    return data;
                }
            }
            return def;
        } catch (e) {
            // 4. 异常处理：记录日志并返回默认值
            logger.error(`${Storage.tag} key=${key} => Error getting sessionStorage:`, e);
            return def;
        }
    }

    /** 删除 sessionStorage 数据 */
    removeSession(key?: string): void {
        // 1. 检查sessionStorage支持性，不支持则直接返回
        if (!this.supportSessionStorage) {
            return;
        }

        try {
            if (key) {
                const targetKey = Encrypt.isEncrypted ? this.encryptData(key) : key;
                sessionStorage.removeItem(targetKey);
            } else {
                sessionStorage.clear();
            }
        } catch (e) {
            logger.error(`${Storage.tag} key=${key} => Error removing sessionStorage:`, e);
        }
    }
}

/** 存储工具单例 */
export default new Storage();
