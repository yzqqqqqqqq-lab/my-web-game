/**
 * 日志工具方法类型定义
 * 包含不同级别日志的输出方法
 */
export type Logger = {
    /** 信息级日志（常规运行信息） */
    info: (...args: any[]) => void;
    /** 错误级日志（一般错误，不中断程序） */
    error: (...args: any[]) => void;
    /** 警告级日志（潜在问题，需关注） */
    warn: (...args: any[]) => void;
    /** 致命级日志（严重错误，可能导致程序中断） */
    fatal: (...args: any[]) => void;
    /** 系统级别（常驻打印） */
    system: (...args: any[]) => void;
};

/** 日志级别 */
type Level = 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal' | 'system';

/** 结构化样式（也可以直接传 CSS 字符串） */
type StructuredStyle = {
    color?: string; // 文本颜色，如 '#2196F3'、'red'、'var(--brand)'
    bg?: string; // 背景色
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
};

/** 单级别的样式配置（label 是 [INFO] 标签，content 是正文第一个字符串） */
type LevelStyle = {
    label?: string | StructuredStyle;
    content?: string | StructuredStyle;
};

/** 每个级别的样式集合 */
type LevelStyles = Partial<Record<Level, LevelStyle>>;

/** 仅当前调用生效的样式标记 */
const LOG_STYLE_TOKEN: unique symbol = Symbol('LOG_STYLE_TOKEN');
type CallOnceStyle = { [LOG_STYLE_TOKEN]: true; style: LevelStyle };

export const LogStyle = {
    /** 在一次调用里临时覆盖样式：logger.info('msg', LogStyle.style({ label:{color:'#0f0'} })) */
    style(style: LevelStyle): CallOnceStyle {
        return { [LOG_STYLE_TOKEN]: true, style };
    }
};

/**
 * 日志工具配置项类型（扩展：levelStyles）
 */
export type LoggerOptions = {
    level?: Level;
    serviceName?: string;
    open?: boolean;
    /** 新增：各级别默认样式 */
    levelStyles?: LevelStyles;
};

/** 默认样式（可被全局与单次调用覆盖） */
const DEFAULT_LEVEL_STYLES: LevelStyles = {
    info: { label: { color: 'green', bold: true }, content: {} },
    warn: { label: { color: 'orange', bold: true }, content: {} },
    error: { label: { color: 'red', bold: true }, content: {} },
    fatal: { label: { color: 'magenta', bold: true, bg: '#fff' }, content: {} },
    system: { label: { color: '#ea5459', bold: true }, content: {} }
};

/** 默认配置（保持你的默认） */
export let loggerOptions: LoggerOptions = {
    level: 'info',
    serviceName: '',
    open: true,
    levelStyles: { ...DEFAULT_LEVEL_STYLES }
};

/** 允许对 options 做浅合并（levelStyles 也浅合并） */
export const setLoggerConfig = (options: LoggerOptions) => {
    loggerOptions = {
        ...loggerOptions,
        ...options,
        levelStyles: { ...(loggerOptions.levelStyles || {}), ...(options.levelStyles || {}) }
    };
    //todo 模块
    //logger.info(LOG_STYLE_TOKEN,loggerOptions);
};

/** 单独为某个级别设置样式 */
export const setLevelStyle = (level: Level, style: LevelStyle) => {
    loggerOptions.levelStyles = {
        ...(loggerOptions.levelStyles || {}),
        [level]: { ...(loggerOptions.levelStyles?.[level] || {}), ...style }
    };
};

/** 级别优先级 */
const levelPriority: Record<Level, number> = {
    trace: 0,
    debug: 1,
    info: 2,
    warn: 3,
    error: 4,
    fatal: 5,
    system: 6
};

function checkOpen(type: Level): boolean {
    if (loggerOptions.open === false) return false;
    const configLevel = loggerOptions.level || 'info';
    const currentLevel = type || 'info';
    return levelPriority[currentLevel] >= levelPriority[configLevel];
}

/** 简单的环境判断 */
const isServer = typeof window === 'undefined' || typeof document === 'undefined';

// ===================================
// Server Implementation (ANSI styling)
// ===================================

/** 简单的颜色映射，根据 CSS 颜色名映射到 ANSI Code */
const ANSI_COLORS: Record<string, string> = {
    reset: '\x1b[0m',
    bold: '\x1b[1m',
    dim: '\x1b[2m',
    italic: '\x1b[3m',
    underline: '\x1b[4m',

    // Foreground colors
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    gray: '\x1b[90m',
    orange: '\x1b[33m', // map orange to yellow
};

// ===================================
// Browser Implementation (CSS styling)
// ===================================

/** 将结构化样式转为 CSS 字符串（或直接透传字符串） */
function toCss(style?: string | StructuredStyle): string {
    if (!style) return 'color: inherit;';
    if (typeof style === 'string') return style;

    const parts: string[] = [];
    if (style.color) parts.push(`color: ${style.color}`);
    if (style.bg) parts.push(`background: ${style.bg}`);
    if (style.bold) parts.push('font-weight: bold');
    if (style.italic) parts.push('font-style: italic');
    if (style.underline) parts.push('text-decoration: underline');
    return parts.length ? parts.join('; ') + ';' : 'color: inherit;';
}

/** 辅助：从 StructuredStyle 解析出 ANSI code 前缀 */
function toAnsi(style?: string | StructuredStyle): string {
    if (!style) return '';
    // 如果直接传 CSS 字符串，服务端很难解析，直接忽略
    if (typeof style === 'string') return '';

    let ansi = '';
    if (style.bold) ansi += ANSI_COLORS.bold;
    if (style.italic) ansi += ANSI_COLORS.italic;
    if (style.underline) ansi += ANSI_COLORS.underline;

    if (style.color && typeof style.color === 'string') {
        // 简单支持几种颜色名，不支持 hex
        const colorName = style.color.toLowerCase();
        // 处理形如 "#fff" 或 "var(--x)" 的情况 -> 暂时忽略或 fallback
        // 这里做一个简单的 known colors 映射
        if (ANSI_COLORS[colorName]) {
            ansi += ANSI_COLORS[colorName];
        } else if (colorName.startsWith('#')) {
            // Hex color mapping is complex, fallback to standard or ignore
            // For now, mapping some specific defaults you used
            if (colorName === '#ea5459') ansi += ANSI_COLORS.red; // system red
        }
    }
    return ansi;
}

/** 获取样式：默认 -> 全局级别覆盖 -> （可选）单次调用覆盖 */
function resolveStyles(level: Level, once?: LevelStyle): { labelCss: string; contentCss: string } {
    const base = DEFAULT_LEVEL_STYLES[level] || {};
    const global = (loggerOptions.levelStyles || {})[level] || {};
    const merged: LevelStyle = {
        label: once?.label ?? global.label ?? base.label,
        content: once?.content ?? global.content ?? base.content
    };
    return {
        labelCss: toCss(merged.label),
        contentCss: toCss(merged.content)
    };
}

function resolveStylesServer(level: Level, once?: LevelStyle): { labelAnsi: string; contentAnsi: string } {
    const base = DEFAULT_LEVEL_STYLES[level] || {};
    const global = (loggerOptions.levelStyles || {})[level] || {};
    const merged: LevelStyle = {
        label: once?.label ?? global.label ?? base.label,
        content: once?.content ?? global.content ?? base.content
    };
    return {
        labelAnsi: toAnsi(merged.label),
        contentAnsi: toAnsi(merged.content)
    };
}

function printBrowser(level: Level, consoleFn: (...a: any[]) => void, args: any[], onceStyle?: LevelStyle) {
    const { labelCss, contentCss } = resolveStyles(level, onceStyle);
    const time = `[${new Date().toLocaleTimeString()}]`;
    const svc = loggerOptions.serviceName ? `[${loggerOptions.serviceName}]` : '';
    const label = level.toUpperCase();

    // 目标：把“前缀 + 标签 + 正文（如果是字符串）”合成一个格式字符串
    let fmt = `${time}${svc} %c${label}%c`;
    const fmtArgs: any[] = [labelCss, 'color: inherit;'];

    if (args.length && typeof args[0] === 'string') {
        // 给正文的第一个字符串套一层样式（你的字符串中若含有 %c 也会被继续解析）
        fmt += ` %c${args[0]}`;
        fmtArgs.push(contentCss);
        // 其余参数直接跟上（对象/数组不强转字符串，避免丢信息）
        consoleFn(fmt, ...fmtArgs, ...args.slice(1));
    } else {
        // 没有字符串正文就不做正文着色
        consoleFn(fmt, ...fmtArgs, ...args);
    }
}

function printServer(level: Level, consoleFn: (...a: any[]) => void, args: any[], onceStyle?: LevelStyle) {
    const { labelAnsi, contentAnsi } = resolveStylesServer(level, onceStyle);
    const reset = ANSI_COLORS.reset;
    const time = `[${new Date().toLocaleTimeString()}]`;
    const svc = loggerOptions.serviceName ? `[${loggerOptions.serviceName}]` : '';
    const labelStr = level.toUpperCase();

    // 构建带颜色的 label
    const labelPart = labelAnsi ? `${labelAnsi}${labelStr}${reset}` : labelStr;

    // 前缀部分
    const prefix = `${time}${svc} ${labelPart}`;

    if (args.length && typeof args[0] === 'string') {
        // 给正文第一个字符串加颜色
        const contentStr = args[0];
        const contentPart = contentAnsi ? `${contentAnsi}${contentStr}${reset}` : contentStr;
        consoleFn(prefix, contentPart, ...args.slice(1));
    } else {
        consoleFn(prefix, ...args);
    }
}

/** 共用打印器 */
function print(level: Level, consoleFn: (...a: any[]) => void, rawArgs: any[]) {
    if (!checkOpen(level)) return;

    // 单次样式
    let args = rawArgs;
    let onceStyle: LevelStyle | undefined;
    const last = args[args.length - 1];
    if (last && typeof last === 'object' && last[LOG_STYLE_TOKEN]) {
        onceStyle = (last as CallOnceStyle).style;
        args = args.slice(0, -1);
    }

    if (isServer) {
        printServer(level, consoleFn, args, onceStyle);
    } else {
        printBrowser(level, consoleFn, args, onceStyle);
    }
}

/** 导出的 logger（保持原方法名不变） */
export const logger: Logger = {
    info: (...args: any[]) => print('info', console.info.bind(console), args),
    warn: (...args: any[]) => print('warn', console.warn.bind(console), args),
    error: (...args: any[]) => print('error', console.error.bind(console), args),
    fatal: (...args: any[]) => print('fatal', console.error.bind(console), args),
    system: (...args: any[]) => print('system', console.log.bind(console), args)
};
