import { logger, LogStyle } from './index';

console.log('--- Testing Server Side Logging ---');

logger.info('Info message');
logger.warn('Warn message');
logger.error('Error message');
logger.fatal('Fatal message');
logger.system('System message');

logger.info('Info with object', { foo: 'bar' });
logger.info('Info with multiple args', 'arg1', 123, { a: 1 });

logger.info('Info with custom style', LogStyle.style({ label: { color: 'cyan' }, content: { color: 'blue', bold: true } }));

console.log('--- Test Finished ---');
