import CryptoJS from 'crypto-js';
import Encrypt from './index';

/**
 * AES 加密/解密工具类
 * 使用 AES-CBC 模式，PKCS7 填充
 */
export default class AESHelper {
    /**
     * AES 加密（Web 版本）
     * @param str 待加密的字符串
     * @param iv 初始化向量，默认使用全局配置的 AES_IV_WEB
     * @returns 加密后的 Base64 字符串
     */
    static EncryptWeb(str: string, iv: string = Encrypt.AES_IV_WEB): string {
        return AESHelper.encrypt(str, Encrypt.AES_KEY_WEB, iv);
    }

    /**
     * AES 解密（Web 版本）
     * @param str 待解密的 Base64 字符串
     * @param iv 初始化向量，默认使用全局配置的 AES_IV_WEB
     * @returns 解密后的原始字符串
     */
    static DecryptWeb(str: string, iv: string = Encrypt.AES_IV_WEB): string {
        return AESHelper.decrypt(str, Encrypt.AES_KEY_WEB, iv);
    }

    /**
     * AES 加密核心方法
     * @param plaintext 明文
     * @param keyStr 密钥字符串
     * @param ivStr 初始化向量字符串
     * @returns 加密后的 Base64 字符串
     */
    static encrypt(plaintext: string, keyStr: string, ivStr: string): string {
        const key = CryptoJS.enc.Utf8.parse(keyStr);
        const iv = CryptoJS.enc.Utf8.parse(ivStr);
        return CryptoJS.AES.encrypt(plaintext, key, {
            iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }).toString();
    }

    /**
     * AES 解密核心方法
     * @param ciphertext 密文（Base64 字符串）
     * @param keyStr 密钥字符串
     * @param ivStr 初始化向量字符串
     * @returns 解密后的原始字符串
     */
    static decrypt(ciphertext: string, keyStr: string, ivStr: string): string {
        const key = CryptoJS.enc.Utf8.parse(keyStr);
        const iv = CryptoJS.enc.Utf8.parse(ivStr);
        return CryptoJS.enc.Utf8.stringify(
            CryptoJS.AES.decrypt(ciphertext, key, {
                iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            })
        );
    }

    /**
     * 生成随机初始化向量（IV）
     * @param keyLength IV 长度（通常为 16）
     * @returns 随机生成的 IV 字符串
     */
    public static GenerateIV(keyLength: number): string {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({ length: keyLength }, () =>
            chars[Math.floor(Math.random() * chars.length)]
        ).join('');
    }
}
