import JSEncrypt from 'jsencrypt';
import Encrypt from './index';

/**
 * RSA 加密/解密工具类
 */
export default class RSAHelper {
    private static encryptor = new JSEncrypt();

    /**
     * 设置 RSA 公钥
     * @param publicKey RSA 公钥（PEM 格式）
     */
    static setPublicKey(publicKey: string): void {
        RSAHelper.encryptor.setPublicKey(publicKey);
    }

    /**
     * RSA 加密（使用公钥）
     * @param data 待加密的数据
     * @param publicKeyPem RSA 公钥（PEM 格式），默认使用全局配置的 RSA_KEY
     * @returns 加密后的字符串，失败时抛出错误
     */
    static Encrypt(data: string, publicKeyPem: string = Encrypt.RSA_KEY): string {
        RSAHelper.setPublicKey(publicKeyPem);
        const encrypted = RSAHelper.encryptor.encrypt(data);
        if (!encrypted) {
            throw new Error('RSA encryption failed');
        }
        return encrypted;
    }

    /**
     * RSA 解密（使用私钥）
     * @param ciphertext 待解密的密文
     * @param privateKeyPem RSA 私钥（PEM 格式），默认使用全局配置的 RSA_KEY
     * @returns 解密后的字符串，失败时抛出错误
     */
    static Decrypt(ciphertext: string, privateKeyPem: string = Encrypt.RSA_KEY): string {
        RSAHelper.encryptor.setPrivateKey(privateKeyPem);
        const decrypted = RSAHelper.encryptor.decrypt(ciphertext);
        if (!decrypted) {
            throw new Error('RSA decryption failed');
        }
        return decrypted;
    }
}
