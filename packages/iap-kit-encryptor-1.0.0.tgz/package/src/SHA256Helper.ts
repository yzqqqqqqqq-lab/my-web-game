import CryptoJS from 'crypto-js';

export default class SHA256Helper {
    /**
     * 计算字符串的 SHA256 哈希值
     * @param data 输入字符串
     * @returns SHA256 哈希值 (Hex 编码)
     */
    public static Encrypt(data: string): string {
        if (!data) return '';
        return CryptoJS.SHA256(data).toString(CryptoJS.enc.Hex);
    }
}
