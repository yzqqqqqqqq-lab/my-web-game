'use client';

import { logger } from '@iap/kit-logger';

/**
 * 加密配置接口
 */
export interface IEncryptConfig {
    /** 是否启用加密 */
    isEncrypted?: boolean;
    /** 签名密钥，用于生成签名 */
    SIGN_KEY?: string;
    /** 数据加密密钥，用于 AES 加密 */
    DATA_KEY?: string;
    /** RSA 公钥（PEM 格式），用于 RSA 加密 */
    RSA_KEY?: string;
    /** AES Web 版本专用密钥 */
    AES_KEY_WEB?: string;
    /** AES Web 版本专用初始化向量 */
    AES_IV_WEB?: string;
}

/**
 * 完整的加密配置类型（所有字段必填）
 */
export type IEncrypt = Required<IEncryptConfig>;

/**
 * 默认配置
 */
// const DEFAULT_CONFIG: Required<IEncryptConfig> = {
//     isEncrypted: true,
//     SIGN_KEY: 'L9gh=p%Eozfn2#@',
//     DATA_KEY: '48ef8b4810e9260625c',
//     RSA_KEY: 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDvuF8W2ghFIJ8xj/kpXQMAh04PNrLJP9UxFigM7MROvct7MIsn4PKvqF0uOrgIMS15mvONp6JghCkDOg4TKyc/SXtz9C4E/jDHoMy6e/w24WqvvL1T8mk+EftBL2ATjQ4UtW8vQeiyuAGOqfpr7m/tzfRIEoCZq21O8LyryslhywIDAQAB',
//     AES_KEY_WEB: 'VIX5XN2539vQ4SQI',
//     AES_IV_WEB: 'MM1B4I6w23QhzHhG',
// };

// betby sport - 项目接口配置
const DEFAULT_CONFIG: Required<IEncryptConfig> = {
    isEncrypted: true,
    SIGN_KEY: 'L9gh=p%Eozfn2#@',
    DATA_KEY: '48ef8b4810e9260625c',
    RSA_KEY: 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAIPj89u+6QajeXBckJ7ELzlKq6gU3QiBgRId+MqNTWl3QDjy9MOZLBuBNaGk+FGLs/RUpcAiakSh3UdJ0sZqxRUCAwEAAQ==',
    AES_KEY_WEB: 'Q8kkn5mEmoze1KaM',
    AES_IV_WEB: 'EzwHiu64Qh989496',
};

// 全局配置存储
let globalConfig: Partial<IEncryptConfig> = {};

/**
 * 合并配置：局部 > 全局 > 默认
 * @param local 局部配置
 * @returns 合并后的完整配置
 */
export const allConfig = (local?: Partial<IEncryptConfig>): Required<IEncryptConfig> => ({
    ...DEFAULT_CONFIG,
    ...globalConfig,
    ...local
});

/**
 * 配置加密器全局设置
 * @param config 配置项，支持部分配置
 * @example
 * ```typescript
 * encryptConfigure({
 *   isEncrypted: true,
 *   SIGN_KEY: 'your-sign-key',
 *   DATA_KEY: 'your-data-key'
 * });
 * ```
 */
export function encryptConfigure(config: IEncryptConfig): void {
    Object.assign(globalConfig, config);
    const mergedConfig = allConfig();
    logger.info('Encrypt configured:', config, mergedConfig);
}

/**
 * 获取当前配置（合并全局配置和局部配置）
 * @param localConfig 局部配置，优先级高于全局配置
 * @returns 合并后的完整配置
 * @example
 * ```typescript
 * const config = encryptGetConfig({ SIGN_KEY: 'custom-key' });
 * ```
 */
export function encryptGetConfig(localConfig?: Partial<IEncryptConfig>): Required<IEncryptConfig> {
    return allConfig(localConfig);
}

/**
 * 重置配置为默认值
 */
export function encryptResetConfig(): void {
    globalConfig = {};
}

/**
 * 获取当前全局配置（不包含局部覆盖）
 * @returns 当前全局配置的副本
 */
export function encryptGetGlobalConfig(): Partial<IEncryptConfig> {
    return { ...globalConfig };
}

/**
 * 默认导出对象（保持向后兼容）
 * 所有属性都是 getter，自动使用全局配置
 */
const Encrypt: IEncrypt = {
    get isEncrypted() {
        return allConfig().isEncrypted;
    },
    get SIGN_KEY() {
        return allConfig().SIGN_KEY;
    },
    get DATA_KEY() {
        return allConfig().DATA_KEY;
    },
    get RSA_KEY() {
        return allConfig().RSA_KEY;
    },
    get AES_KEY_WEB() {
        return allConfig().AES_KEY_WEB;
    },
    get AES_IV_WEB() {
        return allConfig().AES_IV_WEB;
    },
};

export { default as AESHelper } from './AESHelper';
export { default as RSAHelper } from './RSAHelper';
export { default as MD5Helper } from './MD5Helper';
export { default as SHA256Helper } from './SHA256Helper';
export default Encrypt;
