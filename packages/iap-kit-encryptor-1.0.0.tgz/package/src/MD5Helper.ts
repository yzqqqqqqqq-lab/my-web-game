import CryptoJS from 'crypto-js';

/**
 * MD5 哈希工具类
 */
export default class MD5Helper {
    /**
     * 生成 MD5 哈希值（大写）
     * @param input 待哈希的字符串
     * @returns MD5 哈希值（32 位大写字符串）
     */
    static CreateMD5(input: string): string {
        return CryptoJS.MD5(input).toString().toUpperCase();
    }
}
