# @iap/kit-encryptor

加密工具库，提供 AES、RSA、MD5 加密算法，支持灵活的配置系统。

## 功能特性

- 🔐 **AES 加密/解密** - 支持 Web 版本，使用 AES-CBC 模式，PKCS7 填充
- 🔑 **RSA 加密/解密** - 支持公钥加密和私钥解密
- 🔒 **MD5 哈希** - 生成 MD5 哈希值（大写）
- ⚙️ **灵活配置** - 支持全局配置和局部配置，配置优先级清晰
- 🔄 **向后兼容** - 完全兼容旧版本 API

## 安装

```bash
npm install @iap/kit-encryptor
# 或
pnpm add @iap/kit-encryptor
```

## 快速开始

### 基础使用

```typescript
import Encrypt, { AESHelper, RSAHelper, MD5Helper } from '@iap/kit-encryptor';

// AES 加密/解密
const encrypted = AESHelper.EncryptWeb('Hello World');
const decrypted = AESHelper.DecryptWeb(encrypted);

// RSA 加密（使用公钥）
const rsaEncrypted = RSAHelper.Encrypt('Hello World');

// MD5 哈希
const hash = MD5Helper.CreateMD5('Hello World');
```

### 配置系统

#### 全局配置

使用 `encryptConfigure()` 设置全局配置，所有使用 `Encrypt` 对象的地方都会生效：

```typescript
import Encrypt, { encryptConfigure } from '@iap/kit-encryptor';

// 应用启动时配置全局加密参数
encryptConfigure({
  isEncrypted: true,
  SIGN_KEY: 'your-sign-key',        // 签名密钥
  DATA_KEY: 'your-data-key',        // 数据加密密钥
  RSA_KEY: 'your-rsa-public-key',   // RSA 公钥（PEM 格式）
  AES_KEY_WEB: 'your-aes-key',      // AES Web 版本密钥
  AES_IV_WEB: 'your-aes-iv',        // AES Web 版本初始化向量
});

// 之后所有地方使用 Encrypt 对象都会使用全局配置
if (Encrypt.isEncrypted) {
  console.log(Encrypt.SIGN_KEY);     // 'your-sign-key'
  console.log(Encrypt.DATA_KEY);     // 'your-data-key'
  console.log(Encrypt.RSA_KEY);      // 'your-rsa-public-key'
  console.log(Encrypt.AES_KEY_WEB);  // 'your-aes-key'
  console.log(Encrypt.AES_IV_WEB);   // 'your-aes-iv'
}
```

#### 局部配置

在特定函数中使用局部配置，局部配置会覆盖全局配置：

```typescript
import Encrypt, { encryptGetConfig, AESHelper } from '@iap/kit-encryptor';

// 使用 encryptGetConfig() 获取配置（支持局部覆盖）
function encryptWithLocalKey(data: string, customKey?: string) {
  const config = encryptGetConfig({
    SIGN_KEY: customKey || 'local-sign-key'  // 局部配置优先级最高
  });
  
  // 使用局部配置
  console.log(config.SIGN_KEY);      // 'local-sign-key'（覆盖全局配置）
  console.log(config.DATA_KEY);      // 使用全局配置或默认值
  console.log(config.AES_KEY_WEB);  // 使用全局配置或默认值
  console.log(config.isEncrypted);   // 使用全局配置或默认值
  
  // 使用配置进行加密
  return AESHelper.EncryptWeb(data, config.AES_IV_WEB);
}

// 直接使用 Encrypt 对象属性（使用全局配置）
function encryptWithGlobalKey(data: string) {
  // Encrypt 对象属性始终使用全局配置（或默认配置）
  if (Encrypt.isEncrypted) {
    return AESHelper.EncryptWeb(data, Encrypt.AES_IV_WEB);
  }
  return data;
}
```

**配置优先级：** 局部配置（`encryptGetConfig()` 参数） > 全局配置（`encryptConfigure()` 设置） > 默认配置

## API 文档

### 配置 API

#### 独立函数（带前缀，推荐）

- **`encryptConfigure(config: IEncryptConfig): void`** - 设置全局配置
  ```typescript
  encryptConfigure({
    isEncrypted: true,
    SIGN_KEY: 'your-key'
  });
  ```

- **`encryptGetConfig(localConfig?: Partial<IEncryptConfig>): Required<IEncryptConfig>`** - 获取配置（支持局部覆盖）
  ```typescript
  const config = encryptGetConfig({ SIGN_KEY: 'local-key' });
  ```

- **`encryptResetConfig(): void`** - 重置为默认配置
  ```typescript
  encryptResetConfig(); // 清除所有全局配置
  ```

- **`encryptGetGlobalConfig(): Partial<IEncryptConfig>`** - 获取当前全局配置
  ```typescript
  const globalConfig = encryptGetGlobalConfig();
  ```

### 加密 API

#### AESHelper

- **`EncryptWeb(str: string, iv?: string): string`** - AES 加密（Web 版本）
  - `str`: 待加密的字符串
  - `iv`: 初始化向量，默认使用全局配置的 `AES_IV_WEB`
  - 返回：加密后的 Base64 字符串

- **`DecryptWeb(str: string, iv?: string): string`** - AES 解密（Web 版本）
  - `str`: 待解密的 Base64 字符串
  - `iv`: 初始化向量，默认使用全局配置的 `AES_IV_WEB`
  - 返回：解密后的原始字符串

- **`GenerateIV(keyLength: number): string`** - 生成随机初始化向量
  - `keyLength`: IV 长度（通常为 16）
  - 返回：随机生成的 IV 字符串

#### RSAHelper

- **`Encrypt(data: string, publicKeyPem?: string): string`** - RSA 加密（使用公钥）
  - `data`: 待加密的数据
  - `publicKeyPem`: RSA 公钥（PEM 格式），默认使用全局配置的 `RSA_KEY`
  - 返回：加密后的字符串，失败时抛出错误

- **`Decrypt(ciphertext: string, privateKeyPem?: string): string`** - RSA 解密（使用私钥）
  - `ciphertext`: 待解密的密文
  - `privateKeyPem`: RSA 私钥（PEM 格式），默认使用全局配置的 `RSA_KEY`
  - 返回：解密后的字符串，失败时抛出错误

- **`setPublicKey(publicKey: string): void`** - 设置 RSA 公钥
  - `publicKey`: RSA 公钥（PEM 格式）

#### MD5Helper

- **`CreateMD5(input: string): string`** - 生成 MD5 哈希值（大写）
  - `input`: 待哈希的字符串
  - 返回：MD5 哈希值（32 位大写字符串）

### 默认导出

```typescript
import Encrypt from '@iap/kit-encryptor';

// 配置对象（属性自动使用全局配置）
Encrypt.isEncrypted  // boolean - 是否启用加密
Encrypt.SIGN_KEY     // string - 签名密钥
Encrypt.DATA_KEY     // string - 数据加密密钥
Encrypt.RSA_KEY      // string - RSA 公钥（PEM 格式）
Encrypt.AES_KEY_WEB  // string - AES Web 版本密钥
Encrypt.AES_IV_WEB   // string - AES Web 版本初始化向量
```

## 使用示例

### 示例 1: 全局配置 + Encrypt 对象

```typescript
import Encrypt, { encryptConfigure, AESHelper } from '@iap/kit-encryptor';

// 应用启动时配置
encryptConfigure({
  isEncrypted: process.env.NODE_ENV === 'production',
  SIGN_KEY: process.env.SIGN_KEY || 'default-sign-key',
  DATA_KEY: process.env.DATA_KEY || 'default-data-key',
  RSA_KEY: process.env.RSA_KEY || Encrypt.RSA_KEY,
  AES_KEY_WEB: process.env.AES_KEY_WEB || Encrypt.AES_KEY_WEB,
  AES_IV_WEB: process.env.AES_IV_WEB || Encrypt.AES_IV_WEB,
});

// 在业务代码中使用 Encrypt 对象（自动使用全局配置）
function saveEncryptedData(key: string, value: string) {
  if (Encrypt.isEncrypted) {
    const encryptedKey = AESHelper.EncryptWeb(key, Encrypt.AES_IV_WEB);
    const encryptedValue = AESHelper.EncryptWeb(value, Encrypt.AES_IV_WEB);
    localStorage.setItem(encryptedKey, encryptedValue);
  } else {
    localStorage.setItem(key, value);
  }
}
```

### 示例 2: 局部配置覆盖

```typescript
import Encrypt, { encryptGetConfig, AESHelper, MD5Helper } from '@iap/kit-encryptor';

function encryptRequest(data: any, customSignKey?: string) {
  // 使用局部配置覆盖全局配置
  const config = encryptGetConfig({
    SIGN_KEY: customSignKey  // 仅覆盖 SIGN_KEY，其他使用全局配置
  });
  
  const encrypted = AESHelper.EncryptWeb(JSON.stringify(data));
  const timestamp = Date.now();
  const sign = MD5Helper.CreateMD5(
    `${config.SIGN_KEY}${encrypted}${config.SIGN_KEY}${timestamp}${config.SIGN_KEY}`
  );
  
  return { data: encrypted, timestamp, sign };
}
```

### 示例 3: 混合加密（AES + RSA）

```typescript
import Encrypt, { encryptGetConfig, AESHelper, RSAHelper, MD5Helper } from '@iap/kit-encryptor';

function hybridEncrypt(data: any) {
  const config = encryptGetConfig();
  
  // 生成随机 IV
  const aesIV = AESHelper.GenerateIV(16);
  
  // AES 加密数据
  const encryptedData = AESHelper.EncryptWeb(JSON.stringify(data), aesIV);
  
  // RSA 加密 IV（使用配置中的 RSA_KEY）
  const encryptedIV = RSAHelper.Encrypt(aesIV, config.RSA_KEY);
  
  // 生成签名
  const sign = MD5Helper.CreateMD5(
    `${config.SIGN_KEY}${encryptedData}${config.SIGN_KEY}${Date.now()}${config.SIGN_KEY}`
  );
  
  return { 
    data: encryptedData, 
    iv: encryptedIV, 
    sign 
  };
}
```

### 示例 4: 自定义 IV 加密

```typescript
import { AESHelper } from '@iap/kit-encryptor';

// 生成随机 IV
const customIV = AESHelper.GenerateIV(16);

// 使用自定义 IV 加密
const encrypted = AESHelper.EncryptWeb('sensitive data', customIV);

// 解密时必须使用相同的 IV
const decrypted = AESHelper.DecryptWeb(encrypted, customIV);
```

### 示例 5: RSA 密钥管理

```typescript
import { RSAHelper } from '@iap/kit-encryptor';

// 方式1: 使用全局配置的 RSA_KEY
const encrypted1 = RSAHelper.Encrypt('data');

// 方式2: 使用自定义公钥
const customPublicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC...';
const encrypted2 = RSAHelper.Encrypt('data', customPublicKey);

// 方式3: 先设置公钥，再加密
RSAHelper.setPublicKey(customPublicKey);
const encrypted3 = RSAHelper.Encrypt('data');
```

## 类型定义

```typescript
export interface IEncryptConfig {
  /** 是否启用加密 */
  isEncrypted?: boolean;
  /** 签名密钥，用于生成签名 */
  SIGN_KEY?: string;
  /** 数据加密密钥，用于 AES 加密 */
  DATA_KEY?: string;
  /** RSA 公钥（PEM 格式），用于 RSA 加密 */
  RSA_KEY?: string;
  /** AES Web 版本专用密钥 */
  AES_KEY_WEB?: string;
  /** AES Web 版本专用初始化向量 */
  AES_IV_WEB?: string;
}

export type IEncrypt = Required<IEncryptConfig>;
```

## 配置说明

### 配置项详解

| 配置项 | 类型 | 说明 | 默认值 |
|--------|------|------|--------|
| `isEncrypted` | `boolean` | 是否启用加密 | `true` |
| `SIGN_KEY` | `string` | 签名密钥，用于生成 MD5 签名 | `'L9gh=p%Eozfn2#@'` |
| `DATA_KEY` | `string` | 数据加密密钥，用于 AES 加密 | `'48ef8b4810e9260625c'` |
| `RSA_KEY` | `string` | RSA 公钥（PEM 格式），用于 RSA 加密 | 默认 RSA 公钥 |
| `AES_KEY_WEB` | `string` | AES Web 版本专用密钥 | `'VIX5XN2539vQ4SQI'` |
| `AES_IV_WEB` | `string` | AES Web 版本专用初始化向量 | `'MM1B4I6w23QhzHhG'` |

### 配置最佳实践

1. **生产环境配置**
   ```typescript
   // 在应用启动时配置，使用环境变量
   encryptConfigure({
     isEncrypted: process.env.NODE_ENV === 'production',
     SIGN_KEY: process.env.SIGN_KEY!,
     DATA_KEY: process.env.DATA_KEY!,
     RSA_KEY: process.env.RSA_PUBLIC_KEY!,
     AES_KEY_WEB: process.env.AES_KEY_WEB!,
     AES_IV_WEB: process.env.AES_IV_WEB!,
   });
   ```

2. **密钥安全**
   - 不要在代码中硬编码密钥
   - 使用环境变量或密钥管理服务
   - 定期轮换密钥

3. **IV 使用**
   - 对于相同的数据，使用不同的 IV 会产生不同的密文
   - 建议为每次加密生成新的 IV
   - 解密时必须使用相同的 IV

## 注意事项

1. **RSA 加密限制**
   - RSA 加密有长度限制（通常为 245 字节）
   - 对于长数据，建议使用 AES 加密，然后用 RSA 加密 AES 密钥

2. **AES IV 管理**
   - IV 不需要保密，但必须唯一
   - 每次加密使用不同的 IV 可以提高安全性
   - 解密时必须使用加密时相同的 IV

3. **MD5 安全性**
   - MD5 已不再安全，仅用于签名验证，不应用于密码存储
   - 对于安全要求高的场景，建议使用 SHA-256 或更安全的算法

4. **错误处理**
   - RSA 加密/解密失败时会抛出错误，请使用 try-catch 处理
   - AES 解密失败时可能返回空字符串，请验证解密结果

## 依赖

- `crypto-js` - AES 和 MD5 加密
- `jsencrypt` - RSA 加密
- `@iap/kit-logger` - 日志记录

## 许可证

MIT
