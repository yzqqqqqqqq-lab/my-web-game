import { logger } from '@iap/kit-logger';

/**
 * 性能监控统计结果类型
 * 包含指定标签的性能指标：请求次数、平均耗时、最小耗时、最大耗时、总耗时
 */
type PerformanceMonitorOptions = {
    count: number; // 总请求次数
    avg: number; // 平均耗时（ms）
    min: number; // 最小耗时（ms）
    max: number; // 最大耗时（ms）
    total: number; // 总耗时（ms）
};

/**
 * 性能监控工具接口（定义核心能力规范）
 * 用于统一性能监控工具的方法签名，便于扩展和替换实现
 */
export interface IPerformanceMonitor {
    // 接口仅作类型约束，具体实现由PerformanceMonitor类提供
}

/**
 * 性能监控工具实现类（通用版本）
 * 核心功能：记录不同操作的耗时，统计性能指标（平均/最大/最小耗时等），支持多标签分类
 * 适用场景：对比不同请求库（如Alova、Axios）的性能差异，或监控关键业务操作的耗时
 */
export class PerformanceMonitor implements IPerformanceMonitor {
    /**
     * 计时器存储Map（记录正在进行的计时任务）
     * Key：计时器唯一ID（格式：`${label}_${时间戳}_${随机字符串}`）
     * Value：计时开始时间（performance.now()返回的高精度时间戳）
     */
    private timers: Map<string, number> = new Map();

    /**
     * 性能指标存储Map（记录完成的计时结果）
     * Key：标签名称（如"Alova请求"、"本地存储操作"）
     * Value：耗时数组（每个元素为对应操作的耗时，单位ms）
     */
    private metrics: Map<string, number[]> = new Map();

    /**
     * 监控开关状态（默认仅开发环境启用，避免生产环境性能开销）
     * 私有变量，通过isEnabled getter/setter控制访问
     */
    private _isEnabled = process.env.NODE_ENV === 'development';

    /**
     * 获取当前监控开关状态
     * @returns boolean - 启用返回true，禁用返回false
     */
    get isEnabled(): boolean {
        return this._isEnabled;
    }

    /**
     * 设置监控开关状态
     * @param value - 新的开关状态（true启用，false禁用）
     */
    set isEnabled(value: boolean) {
        this._isEnabled = value;
    }

    /**
     * 检查监控是否启用（兼容旧接口，与isEnabled保持一致）
     * @returns boolean - 启用状态
     */
    get enabled(): boolean {
        return this.isEnabled;
    }

    /**
     * 开始计时（创建一个新的计时任务）
     * @param label 标签名称（用于分类统计，如"API请求"、"组件渲染"）
     * @returns 计时器唯一ID（用于后续调用end方法结束计时）
     * @description 仅在监控启用时生效，生成的ID包含标签、时间戳和随机字符串，确保唯一性
     */
    start(label: string): string {
        // 监控未启用时，返回空字符串（不执行计时）
        if (!this.isEnabled) return '';

        // 生成唯一计时器ID：标签 + 时间戳 + 随机字符串（避免并发冲突）
        const timerId = `${label}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        // 获取高精度开始时间（performance.now()比Date.now()更精确，单位ms）
        const startTime = performance.now();

        // 存储计时任务（待后续end方法处理）
        this.timers.set(timerId, startTime);
        return timerId;
    }

    /**
     * 结束计时并记录结果（计算耗时并存储到性能指标中）
     * @param timerId 计时器ID（start方法返回的唯一ID）
     * @param additionalInfo 额外信息（可选，如请求URL、操作详情，用于日志展示）
     * @description 仅在监控启用且timerId有效时生效，会计算耗时、更新统计，并输出日志
     */
    end(timerId: string, additionalInfo?: string): void {
        // 监控未启用或timerId为空时，直接返回
        if (!this.isEnabled || !timerId) return;

        // 获取开始时间（若不存在，说明计时已结束或ID无效，直接返回）
        const startTime = this.timers.get(timerId);
        if (!startTime) return;

        // 计算耗时（当前高精度时间 - 开始时间，单位ms）
        const endTime = performance.now();
        const duration = endTime - startTime;

        // 从timerId中解析标签（ID格式为`label_xxx_xxx`，取第一个下划线前的部分）
        const label = timerId.split('_')[0];
        if (!label) return; // 标签无效时不记录

        // 初始化标签对应的耗时数组（若不存在）
        if (!this.metrics.has(label)) {
            this.metrics.set(label, []);
        }
        // 将当前耗时添加到数组中
        this.metrics.get(label)!.push(duration);

        // 输出耗时日志（包含标签、耗时和额外信息）
        const info = additionalInfo ? ` (${additionalInfo})` : '';
        logger.info(`🚀 ${label}: ${duration.toFixed(2)}ms${info}`);

        // 清理已完成的计时任务（避免内存泄漏）
        this.timers.delete(timerId);
    }

    /**
     * 获取指定标签的性能统计结果
     * @param label 标签名称
     * @returns 性能统计对象（包含count/avg/min/max/total），无数据时返回null
     */
    getStats(label: string): PerformanceMonitorOptions | null {
        // 获取标签对应的耗时数组（无数据时返回null）
        const durations = this.metrics.get(label);
        if (!durations || durations.length === 0) return null;

        // 计算统计指标
        const total = durations.reduce((sum, duration) => sum + duration, 0); // 总耗时
        const avg = total / durations.length; // 平均耗时
        const min = Math.min(...durations); // 最小耗时
        const max = Math.max(...durations); // 最大耗时

        return {
            count: durations.length, // 总次数
            avg,
            min,
            max,
            total
        };
    }

    /**
     * 输出所有标签的性能统计报告（控制台分组展示）
     * @description 仅在监控启用时生效，按标签分组显示各项统计指标
     */
    printAllStats(): void {
        if (!this.isEnabled) return;

        // 控制台分组展示，便于查看
        console.group('📊 Performance Monitor');
        // 遍历所有标签，输出统计信息
        for (const [label] of this.metrics) {
            const stats = this.getStats(label);
            if (stats) {
                logger.info(`${label}:`);
                logger.info(`  Count: ${stats.count}`);
                logger.info(`  Average: ${stats.avg.toFixed(2)}ms`);
                logger.info(`  Min: ${stats.min.toFixed(2)}ms`);
                logger.info(`  Max: ${stats.max.toFixed(2)}ms`);
                logger.info(`  Total: ${stats.total.toFixed(2)}ms`);
                logger.info('---'); // 分隔线
            }
        }
        console.groupEnd();
    }

    /**
     * 清理所有计时任务和性能指标数据（重置监控状态）
     */
    clear(): void {
        this.timers.clear(); // 清空正在进行的计时
        this.metrics.clear(); // 清空已记录的性能指标
    }

    /**
     * 设置监控启用状态（与isEnabled setter功能一致，提供方法式调用）
     * @param enabled 是否启用（true启用，false禁用）
     */
    setEnabled(enabled: boolean): void {
        this.isEnabled = enabled;
    }

    /**
     * 获取所有已记录的标签名称
     * @returns 标签名称数组
     */
    getLabels(): string[] {
        return Array.from(this.metrics.keys());
    }

    /**
     * 获取指定标签的所有耗时记录
     * @param label 标签名称
     * @returns 耗时数组（单位ms），无数据时返回空数组
     */
    getDurations(label: string): number[] {
        return this.metrics.get(label) || [];
    }

    /**
     * 重置指定标签的统计数据（清除该标签的所有耗时记录）
     * @param label 标签名称
     */
    resetLabel(label: string): void {
        this.metrics.delete(label);
    }

    /**
     * 获取当前活跃的计时任务数量（正在进行的计时）
     * @returns 活跃计时器数量
     */
    getActiveTimerCount(): number {
        return this.timers.size;
    }

    /**
     * 获取已记录的标签总数
     * @returns 标签数量
     */
    getLabelCount(): number {
        return this.metrics.size;
    }
}

export default new PerformanceMonitor();
