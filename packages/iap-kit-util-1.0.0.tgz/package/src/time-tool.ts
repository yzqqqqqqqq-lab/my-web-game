import logTool from './log-tool';

/**
 * 时间工具接口
 * 定义时间处理的核心能力，涵盖时间戳转换、日期格式化、时长计算、多风格时长展示等功能，
 * 统一时间相关操作的输入输出规范，适配业务中常见的时间处理场景。
 */
export interface ITimeTool {
    /**
     * 初始化开始时间（毫秒级）
     * 每次访问时返回当前时间的毫秒戳（通过`new Date().getTime()`获取），用于计算活动时长的起始点。
     */
    startTimeMill: number;

    /**
     * 初始化开始时间（秒级）
     * 由当前时间毫秒戳除以1000取整得到，与`startTimeMill`对应，适配秒级时间戳场景。
     */
    startTime: number;

    /**
     * 从初始化到当前的活动时长（毫秒级）
     * 计算逻辑：当前时间毫秒戳（`localTimeStampMill`） - 初始化开始时间毫秒戳（`startTimeMill`），
     * 反映从“初始化时间”到“当前时间”的时间间隔。
     */
    activityTimeMill: number;

    /**
     * 从初始化到当前的活动时长（秒级）
     * 计算逻辑：当前秒级时间戳（`localTimeStamp`） - 初始化秒级时间戳（`startTime`），
     * 为秒级精度的活动时长，避免浮点数误差。
     */
    activityTime: number;

    /**
     * 当前时间戳（秒级）
     * 由`Date.now()`（毫秒级）除以1000取整得到，适配需要秒级时间戳的业务场景（如接口请求参数）。
     */
    localTimeStamp: number;

    /**
     * 当前时间戳（毫秒级）
     * 直接返回`Date.now()`，提供最高精度的时间戳，用于需要毫秒级区分的场景（如性能计时）。
     */
    localTimeStampMill: number;

    /**
     * 秒级时间戳转换为Date对象
     * @param secondTick 秒级时间戳（如1717248000，对应2024-06-01 00:00:00）
     * @returns 对应的Date对象（需将秒级时间戳×1000转为毫秒级，符合Date构造函数要求）
     */
    timeStampToDate(secondTick: number): Date;

    /**
     * Date对象转换为秒级时间戳
     * @param date 目标Date对象
     * @returns 秒级时间戳（通过`date.getTime()`获取毫秒级后÷1000取整，去除小数部分）
     */
    dateToTimeStamp(date: Date): number;

    /**
     * Date对象转换为毫秒级时间戳
     * @param date 目标Date对象
     * @returns 毫秒级时间戳（直接调用`date.getTime()`，保留最高精度）
     */
    dateToTimeStampMill(date: Date): number;

    /**
     * 秒级时间戳转换为本地时间字符串
     * @param timeStamp 秒级时间戳
     * @returns 本地化时间字符串（如“2024/6/1 12:00:00”，格式随系统 locale 变化）
     */
    timeStampFormat(timeStamp: number): string;

    /**
     * 秒级时间戳转换为本地日期字符串（仅含日期，不含时间）
     * @param timeStamp 秒级时间戳
     * @returns 本地化日期字符串（如“2024/6/1”，格式随系统 locale 变化）
     */
    timeStampFormatDate(timeStamp: number): string;

    /**
     * 时间戳转换为本地日期时间字符串（冗余方法）
     * 功能与`timeStampFormat`完全一致，用于兼容旧代码调用。
     * @param timeStamp 秒级时间戳
     * @returns 本地化时间字符串（同`timeStampFormat`的返回格式）
     */
    timeStampToLocale(timeStamp: number): string;

    /**
     * 毫秒级时间戳转换为本地日期时间字符串
     * 与`timeStampFormat`的区别：参数需传入毫秒级时间戳，无需×1000转换。
     * @param timeStamp 毫秒级时间戳
     * @returns 本地化时间字符串（如“2024/6/1 12:00:00”）
     */
    timeStampToLocaleDate(timeStamp: number): string;

    /**
     * 时间戳转换为“月/日/年”固定格式字符串
     * 不受系统 locale 影响，统一格式为“MM/DD/YYYY”（月份和日期补零为2位）。
     * @param timeStamp 毫秒级时间戳
     * @returns 固定格式日期字符串（如“06/01/2024”）
     */
    timeStampToDateFormat(timeStamp: number): string;

    /**
     * 计算两个毫秒级时间戳之间的天数差（向上取整）
     * 适用于计算日期跨度，如“从2024-06-01到2024-06-02”返回1天。
     * @param startTimestamp 起始时间戳（毫秒级）
     * @param endTimestamp 结束时间戳（毫秒级）
     * @returns 天数差（非负，结束时间≤起始时间时返回0，否则向上取整）
     */
    getDaysBetweenTimestamps(startTimestamp: number, endTimestamp: number): number;

    /**
     * 秒数转换为“天/时/分/秒”可读格式（最多显示指定数量的时间部分）
     * 仅显示非零部分，按“天→时→分→秒”优先级，最多显示`maxCount`个部分（默认3个）。
     * @param seconds 总秒数（如12345秒）
     * @param maxCount 最多显示的时间部分数量（默认3，如12345秒→“3h 25m 45s”）
     * @returns 可读时长字符串（无任何非零部分时返回“0s”）
     */
    formatSeconds(seconds: number, maxCount?: number): string;

    /**
     * 秒数转换为“天+时:分:秒”固定格式字符串
     * 天数部分显示为“xD ”，时分秒部分固定为2位补零格式（如“1D 02:03:04”）。
     * @param seconds 总秒数
     * @returns 固定格式时长字符串（无天数时不显示天数部分，如“02:03:04”）
     */
    formatSecondsWithDay(seconds: number): string;

    /**
     * 秒数转换为带单位/不带单位的时间字符串（可自定义是否显示天数）
     * 支持两种模式：显示单位（如“1D:02H:03M:04S”）或不显示单位（如“1D:02:03:04”）。
     * @param seconds 总秒数
     * @param showDays 是否显示天数部分（默认true，false时仅显示“时:分:秒”）
     * @param showUnits 是否显示单位（D/H/M/S，默认false）
     * @returns 自定义格式的时长字符串
     */
    formatShowTimeWithUnits(seconds: number, showDays?: boolean, showUnits?: boolean): string;

    /**
     * 计算两个毫秒级时间戳的秒数差（非负）
     * 用于计算时间间隔，如接口请求耗时（结束时间-开始时间）。
     * @param endTime 结束时间戳（毫秒级）
     * @param startTime 开始时间戳（毫秒级）
     * @returns 秒数差（四舍五入取整，且非负，结束时间<开始时间时返回0）
     */
    calculateDurationInSeconds(endTime: number, startTime: number): number;

    /**
     * 秒数转换为详细自然语言格式（如“1 day 1 hour 1 min 1 sec”）
     * 仅显示非零部分，单位为完整单词（day/hour/min/sec），适合用户可见的时长展示。
     * @param seconds 总秒数
     * @returns 详细格式时长字符串（无任何非零部分时返回空字符串）
     */
    formatSecondsWithDayDetailed(seconds: number): string;

    /**
     * 秒级时间戳转换为ISO标准格式字符串（去除T分隔符和毫秒部分）
     * 统一格式为“YYYY-MM-DD HH:mm:ss”，符合日志或接口时间格式要求。
     * @param timeSecond 秒级时间戳
     * @returns ISO标准格式时间字符串（如“2024-06-01 12:00:00”）
     */
    timeLogStr(timeSecond: number): string;
}

/**
 * 时间处理工具类（单例实现）
 * 核心能力：
 * 1. 时间戳转换：秒级/毫秒级时间戳与Date对象互转，适配不同精度场景；
 * 2. 日期格式化：支持本地化格式、固定格式、ISO格式，满足日志、UI展示等需求；
 * 3. 时长计算：计算毫秒/秒级时间差，转换为多种可读格式（带单位/不带单位、精简/详细）；
 * 4. 活动时长追踪：记录初始化时间，实时计算从初始化到当前的时间间隔。
 * 设计特点：依赖logTool实现日志打印，所有方法无副作用，可安全复用；时间格式统一，避免业务中格式混乱。
 */
export class TimeTool implements ITimeTool {
    /**
     * 获取初始化开始时间（毫秒级）
     * 每次访问时返回当前时间的毫秒戳（通过`new Date().getTime()`），作为活动时长计算的起始基准。
     * @returns 当前时间的毫秒级时间戳
     */
    get startTimeMill(): number {
        return new Date().getTime();
    }

    /**
     * 获取初始化开始时间（秒级）
     * 由当前时间毫秒戳除以1000取整得到，与`startTimeMill`精度对应，用于秒级时间间隔计算。
     * @returns 当前时间的秒级时间戳（Math.floor(Date.now() / 1000)）
     */
    get startTime(): number {
        return Math.floor(Date.now() / 1000);
    }

    /**
     * 获取从初始化到当前的活动时长（毫秒级）
     * 计算逻辑：当前时间毫秒戳（`localTimeStampMill`） - 初始化开始时间毫秒戳（`startTimeMill`），
     * 实时反映从“工具初始化”到“当前时刻”的时间间隔。
     * @returns 活动时长（毫秒级，非负）
     */
    get activityTimeMill(): number {
        return this.localTimeStampMill - this.startTimeMill;
    }

    /**
     * 获取从初始化到当前的活动时长（秒级）
     * 计算逻辑：当前秒级时间戳（`localTimeStamp`） - 初始化秒级时间戳（`startTime`），
     * 为秒级精度的活动时长，避免浮点数误差，适合接口上报等场景。
     * @returns 活动时长（秒级，非负）
     */
    get activityTime(): number {
        return this.localTimeStamp - this.startTime;
    }

    /**
     * 获取当前时间戳（秒级）
     * 每次访问时返回实时秒级时间戳，通过`Math.floor(Date.now() / 1000)`去除毫秒部分，确保整数精度。
     * @returns 当前秒级时间戳
     */
    get localTimeStamp(): number {
        return Math.floor(Date.now() / 1000);
    }

    /**
     * 获取当前时间戳（毫秒级）
     * 每次访问时返回实时毫秒级时间戳（通过`Date.now()`），保留最高时间精度，适合性能计时等场景。
     * @returns 当前毫秒级时间戳
     */
    get localTimeStampMill(): number {
        return Date.now();
    }

    /**
     * 秒级时间戳转换为Date对象
     * Date构造函数仅接受毫秒级时间戳，因此需将输入的秒级时间戳×1000转换后传入。
     * @param secondTick 秒级时间戳（如1717248000，对应2024-06-01 00:00:00）
     * @returns 对应的Date对象（包含时间戳对应的日期和时间信息）
     */
    timeStampToDate(secondTick: number): Date {
        return new Date(secondTick * 1000);
    }

    /**
     * Date对象转换为秒级时间戳
     * 通过`date.getTime()`获取毫秒级时间戳后，÷1000并取整，去除小数部分，确保秒级精度。
     * @param date 目标Date对象（如new Date('2024-06-01')）
     * @returns 秒级时间戳（整数，如1717248000）
     */
    dateToTimeStamp(date: Date): number {
        return Math.floor(date.getTime() / 1000);
    }

    /**
     * Date对象转换为毫秒级时间戳
     * 直接调用`date.getTime()`获取毫秒级时间戳，保留最高精度，适合需要精细时间差计算的场景。
     * @param date 目标Date对象
     * @returns 毫秒级时间戳（如1717248000000）
     */
    dateToTimeStampMill(date: Date): number {
        return date.getTime();
    }

    /**
     * 秒级时间戳转换为本地时间字符串
     * 先将秒级时间戳转为Date对象，再调用`toLocaleString()`生成本地化格式，格式随系统语言/地区变化。
     * @param timeStamp 秒级时间戳
     * @returns 本地化时间字符串（如“2024/6/1 12:00:00”（中文系统）、“6/1/2024, 12:00:00 PM”（英文系统））
     */
    timeStampFormat(timeStamp: number): string {
        return this.timeStampToDate(timeStamp).toLocaleString();
    }

    /**
     * 秒级时间戳转换为本地日期字符串（仅含日期）
     * 先将秒级时间戳转为Date对象，再调用`toLocaleDateString()`生成仅含日期的本地化字符串，不含时间部分。
     * @param timeStamp 秒级时间戳
     * @returns 本地化日期字符串（如“2024/6/1”（中文系统）、“6/1/2024”（英文系统））
     */
    timeStampFormatDate(timeStamp: number): string {
        return this.timeStampToDate(timeStamp).toLocaleDateString();
    }

    /**
     * 时间戳转换为本地日期时间字符串（冗余方法）
     * 功能与`timeStampFormat`完全一致，仅为兼容旧代码中对该方法的调用，无额外逻辑。
     * @param timeStamp 秒级时间戳
     * @returns 本地化时间字符串（同`timeStampFormat`的返回格式）
     */
    timeStampToLocale(timeStamp: number): string {
        return this.timeStampToLocaleDate(timeStamp).toLocaleString();
    }

    /**
     * 毫秒级时间戳转换为本地日期时间字符串
     * 与`timeStampFormat`的区别：参数直接接受毫秒级时间戳，无需×1000转换，适合已持有毫秒级时间戳的场景。
     * @param timeStamp 毫秒级时间戳
     * @returns 本地化时间字符串（如“2024/6/1 12:00:00”）
     */
    timeStampToLocaleDate(timeStamp: number): string {
        return new Date(timeStamp).toLocaleString();
    }

    /**
     * 时间戳转换为“月/日/年”固定格式字符串
     * 不受系统 locale 影响，统一格式为“MM/DD/YYYY”：月份（getMonth()+1，因月份从0开始）和日期补零为2位，
     * 适合需要固定格式的日志、报表等场景。
     * @param timeStamp 毫秒级时间戳
     * @returns 固定格式日期字符串（如“06/01/2024”）
     */
    timeStampToDateFormat(timeStamp: number): string {
        const date = new Date(timeStamp);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // 月份0-11，+1后补零
        const day = String(date.getDate()).padStart(2, '0'); // 日期1-31，补零为2位
        return `${month}/${day}/${year}`;
    }

    /**
     * 计算两个毫秒级时间戳之间的天数差（向上取整）
     * 当logTool日志开关开启（logTool.isLog为true）时，会打印起始和结束时间的固定格式日期（“MM/DD/YYYY”），
     * 便于调试时确认时间范围；计算逻辑：时间差（毫秒）÷ 一天的毫秒数（86400×1000），向上取整，
     * 结束时间≤起始时间时返回0，确保结果非负。
     * @param startTimestamp 起始时间戳（毫秒级）
     * @param endTimestamp 结束时间戳（毫秒级）
     * @returns 天数差（非负整数，如1、2）
     */
    getDaysBetweenTimestamps(startTimestamp: number, endTimestamp: number): number {
        if (logTool.isLog) {
            console.log(
                'getDaysBetweenTimestamps',
                this.timeStampToDateFormat(startTimestamp),
                this.timeStampToDateFormat(endTimestamp)
            );
        }
        const timeDiff = endTimestamp - startTimestamp; // 时间差（毫秒，可能为负）
        return timeDiff <= 0 ? 0 : Math.ceil(timeDiff / (86400 * 1000)); // 86400秒=1天
    }

    /**
     * 秒数转换为“天/时/分/秒”可读格式（最多显示指定数量的时间部分）
     * 按“天→时→分→秒”的优先级筛选非零部分，最多显示`maxCount`个部分（默认3个），
     * 每个部分格式为“数值+单位”（单位：d=天、h=时、m=分、s=秒），无任何非零部分时返回“0s”。
     * @param seconds 总秒数（如123456秒=1天10小时17分36秒）
     * @param maxCount 最多显示的时间部分数量（默认3，如123456秒→“1d 10h 17m”）
     * @returns 精简可读的时长字符串
     */
    formatSeconds(seconds: number, maxCount: number = 3): string {
        const day = Math.floor(seconds / 86400); // 1天=86400秒
        const hour = Math.floor((seconds % 86400) / 3600); // 1小时=3600秒
        const min = Math.floor((seconds % 3600) / 60); // 1分钟=60秒
        const sec = seconds % 60; // 剩余秒数
        const units = ['d', 'h', 'm', 's']; // 时间单位缩写
        let result = '';
        let partCount = 0; // 已添加的时间部分数量

        // 按优先级添加非零部分，直到达到maxCount
        if (day > 0 && partCount < maxCount) {
            result += `${day}${units[0]} `;
            partCount++;
        }
        if ((hour > 0 || day > 0) && partCount < maxCount) {
            // 有天数时，即使小时为0也显示（如1d 0h）
            result += `${hour}${units[1]} `;
            partCount++;
        }
        if ((min > 0 || hour > 0) && partCount < maxCount) {
            // 有小时时，即使分钟为0也显示
            result += `${min}${units[2]} `;
            partCount++;
        }
        if ((sec > 0 || min > 0) && partCount < maxCount) {
            // 有分钟时，即使秒为0也显示
            result += `${sec}${units[3]} `;
            partCount++;
        }

        // 无任何非零部分时，返回“0s”
        if (partCount === 0) {
            result = `0${units[3]}`;
        }

        return result.trim(); // 去除末尾空格
    }

    /**
     * 秒数转换为“天+时:分:秒”固定格式字符串
     * 天数部分（非零时）显示为“xD ”，时分秒部分固定为2位补零格式（如“02:03:04”），
     * 格式统一，适合需要标准化展示的场景（如倒计时、任务时长）。
     * @param seconds 总秒数（如3744秒=1小时2分24秒）
     * @returns 固定格式时长字符串（如“1h 02:24”→实际代码中是“1D 01:02:24”，按代码逻辑）
     */
    formatSecondsWithDay(seconds: number): string {
        const day = Math.floor(seconds / 86400);
        const hour = Math.floor((seconds - day * 86400) / 3600);
        const min = Math.floor((seconds - day * 86400 - hour * 3600) / 60);
        const sec = seconds % 60;
        const parts: string[] = [];

        // 有天数时添加天数部分（格式：“xD ”）
        if (day > 0) {
            parts.push(`${day}D `);
        }
        // 时分秒部分补零为2位，用冒号连接
        parts.push(hour.toString().padStart(2, '0'));
        parts.push(':', min.toString().padStart(2, '0'), ':', sec.toString().padStart(2, '0'));

        return parts.join('');
    }

    /**
     * 秒数转换为带单位/不带单位的时间字符串（可自定义是否显示天数）
     * 支持两种配置：
     * 1. showDays：是否显示天数部分（true→显示“xD”，false→仅显示“时:分:秒”）；
     * 2. showUnits：是否显示单位（D/H/M/S，true→“1D:02H:03M:04S”，false→“1D:02:03:04”）。
     * 时分秒部分固定补零为2位，格式统一，适合灵活适配不同UI需求。
     * @param seconds 总秒数
     * @param showDays 是否显示天数部分（默认true）
     * @param showUnits 是否显示单位（默认false）
     * @returns 自定义格式的时长字符串
     */
    formatShowTimeWithUnits(seconds: number, showDays: boolean = true, showUnits: boolean = false): string {
        const days = Math.floor(seconds / (24 * 3600));
        const hours = Math.floor((seconds % (24 * 3600)) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const sec = seconds % 60;

        if (showDays) {
            return showUnits
                ? `${days}D:${hours}H:${minutes}M:${sec}S` // 带天数+单位
                : `${days}D:${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`; // 带天数+无单位
        } else {
            return showUnits
                ? `${hours}H:${minutes}M:${sec}S` // 无天数+带单位
                : `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`; // 无天数+无单位
        }
    }

    /**
     * 计算两个毫秒级时间戳的秒数差（非负）
     * 先计算毫秒级时间差，÷1000后四舍五入取整，再通过`Math.max`确保结果非负（避免结束时间<开始时间的情况），
     * 适合计算接口耗时、任务执行时长等场景。
     * @param endTime 结束时间戳（毫秒级）
     * @param startTime 开始时间戳（毫秒级）
     * @returns 秒数差（非负整数，如5、10）
     */
    calculateDurationInSeconds(endTime: number, startTime: number): number {
        const timeDiffInSeconds = Math.round((endTime - startTime) / 1000);
        return Math.max(timeDiffInSeconds, 0); // 确保结果非负
    }

    /**
     * 秒数转换为详细自然语言格式（如“1 day 1 hour 1 min 1 sec”）
     * 仅显示非零部分，单位为完整单词（day/hour/min/sec，暂不处理复数形式，如“2 day”），
     * 适合用户可见的详细时长展示（如任务完成耗时、会员有效期）。
     * @param seconds 总秒数
     * @returns 详细格式时长字符串（无任何非零部分时返回空字符串）
     */
    formatSecondsWithDayDetailed(seconds: number): string {
        const day = Math.floor(seconds / 86400);
        const hour = Math.floor((seconds - day * 86400) / 3600);
        const min = Math.floor((seconds - day * 86400 - hour * 3600) / 60);
        const sec = seconds % 60;
        const parts: string[] = [];

        // 仅添加非零部分
        if (day > 0) parts.push(`${day} day`);
        if (hour > 0) parts.push(`${hour} hour`);
        if (min > 0) parts.push(`${min} min`);
        if (sec > 0) parts.push(`${sec} sec`);

        return parts.join(' '); // 用空格连接各部分
    }

    /**
     * 秒级时间戳转换为ISO标准格式字符串（去除T分隔符和毫秒部分）
     * ISO标准格式为“YYYY-MM-DDTHH:mm:ss.sssZ”，此方法通过`replace('T', ' ')`去除日期和时间的T分隔符，
     * 并通过`split('.')[0]`去除毫秒部分，最终格式为“YYYY-MM-DD HH:mm:ss”，适合日志记录、接口时间参数等场景。
     * @param timeSecond 秒级时间戳
     * @returns ISO标准格式时间字符串（如“2024-06-01 12:00:00”）
     */
    timeLogStr(timeSecond: number): string {
        return new Date(timeSecond * 1000)
            .toISOString()
            ?.replace('T', ' ') // 替换T为空格
            .split('.')[0]; // 去除毫秒部分
    }
}

/**
 * 导出时间工具单例实例
 * 全局共享一个实例，确保时间处理逻辑（如格式、精度）统一，避免多实例导致的计算误差或格式混乱，
 * 所有业务模块可直接导入使用，无需重复初始化。
 */
export default new TimeTool();
