/**
 * 奖励类型枚举
 * - NONE: 无奖励
 * - GC: 游戏币（Gold Coin）
 * - SC: 虚拟币（Silver Coin）
 */
export enum RewardType {
    NONE = 0,
    GC = 1,
    SC = 2
}

/**
 * 内部工具类（基础数值处理）
 * 提供通用的数字格式化、单位转换等基础能力，供DriveTool继承使用
 */
class Base {
    /** KMBT单位数组（千、百万、十亿、万亿等） */
    private units = ['K', 'M', 'B', 'T', 'Q', 'Qi', 'S'];

    /**
     * 数字转字符串（支持小数位数控制和末尾零去除）
     * @param value - 待转换的数字
     * @param keepCount - 保留的小数位数（默认2位）
     * @param isTrimZero - 是否去除末尾多余的零（默认true）
     * @returns 格式化后的字符串
     */
    NumberToString(value: number, keepCount: number = 2, isTrimZero: boolean = true): string {
        // 处理非数字/无穷大情况
        if (isNaN(value) || !isFinite(value)) return '0';

        const str = value.toString();
        const dotIndex = str.indexOf('.');

        // 无小数部分，直接返回整数字符串
        if (dotIndex === -1) {
            return str;
        }

        const integerPart = str.substring(0, dotIndex); // 整数部分
        const decimalPart = str.substring(dotIndex + 1); // 小数部分

        // 不需要保留小数，返回整数部分
        if (keepCount === 0) {
            return integerPart;
        }

        // 截取指定位数的小数并拼接
        let result = integerPart + '.' + decimalPart.substring(0, keepCount);

        // 去除末尾多余的零（包括可能的小数点）
        if (isTrimZero) {
            result = result.replace(/\.?0+$/, '');
        }

        return result;
    }

    /**
     * 数字转KMBT单位字符串（带小数）
     * 示例：1234 → 1.2K，1234567 → 1.2M
     * @param value - 待转换的数字
     * @param decimals - 保留的小数位数（默认1位）
     * @returns 带KMBT单位的字符串
     */
    ToKMBTUnitString(value: number, decimals: number = 1): string {
        const absValue = Math.abs(value);
        // 小于1000，直接返回原数字字符串
        if (absValue < 1000) {
            return value.toString();
        }

        // 计算量级（1000^exponent）
        const exponent = Math.floor(Math.log10(absValue) / 3);
        // 获取对应单位（超出units范围默认用"Q"）
        const unit = this.units[exponent - 1] || 'Q';
        // 按量级缩放数字
        const scaled = value / Math.pow(1000, exponent);

        return `${scaled?.toFixed(decimals)}${unit}`;
    }

    /**
     * 数字转KMBT单位字符串（整数版，无小数）
     * 示例：1234 → 1K，1234567 → 1M
     * @param value - 待转换的数字
     * @returns 带KMBT单位的整数字符串
     */
    ToKMBTUnitStringInt(value: number): string {
        const absValue = Math.abs(value);
        // 小于1000，直接返回原数字字符串
        if (absValue < 1000) {
            return value.toString();
        }

        // 计算量级（1000^exponent）
        const exponent = Math.floor(Math.log10(absValue) / 3);
        // 获取对应单位（超出units范围默认用"Q"）
        const unit = this.units[exponent - 1] || 'Q';
        // 按量级缩放并取整
        const scaled = Math.floor(value / Math.pow(1000, exponent));

        return `${scaled}${unit}`;
    }

    /**
     * 数字转千分位字符串
     * 示例：1234567 → 1,234,567
     * @param value - 待转换的数字
     * @returns 千分位格式化字符串
     */
    ToThousandsString(value: number): string {
        return value.toLocaleString();
    }
}

/**
 * 驱动工具接口（业务相关数值处理、校验、脱敏能力）
 * 定义游戏相关的货币格式化、账号脱敏、数据校验等核心方法
 */
export interface IDriveTool {
    /** 金币字符串显示模式（0-千分位，1-KMBT单位） */
    GoldStringMode: number;

    /**
     * 普通单位转原子单位（乘以10000，用于精确计算）
     * @param count - 普通单位数值
     * @returns 原子单位数值
     */
    ToAtomUnit(count: number): number;

    /**
     * 数字千分位格式化（支持小数）
     * @param num - 待格式化数字
     * @returns 千分位格式化字符串
     */
    formatNumberWithCommas(num: number): string;

    /**
     * 原子单位转普通单位（除以10000）
     * @param count - 原子单位数值
     * @returns 普通单位数值
     */
    ToNormalUnit(count: number): number;

    /**
     * SC转美元（当前直接返回原值，可扩展汇率配置）
     * @param sc - SC数值
     * @returns 美元数值
     */
    ScToDollar(sc: number): number;

    /**
     * 浮点数转整数（四舍五入）
     * @param count - 浮点数
     * @returns 四舍五入后的整数
     */
    DoubleToLong(count: number): number;

    /**
     * 根据奖励类型获取对应货币字符串
     * @param type - 奖励类型（RewardType）
     * @param val - 数值（GC为普通单位，SC为原子单位）
     * @returns 格式化后的货币字符串
     */
    GetCoinString(type: RewardType, val: number): string;

    /**
     * 获取SC字符串（原子单位转普通单位后格式化）
     * @param val - SC原子单位数值
     * @returns 格式化后的SC字符串
     */
    GetSCString(val: number): string;

    /**
     * 获取GC字符串（直接格式化普通单位）
     * @param val - GC普通单位数值
     * @returns 格式化后的GC字符串
     */
    GetGCString(val: number): string;

    /**
     * GC数值转KMBT单位字符串（带小数）
     * @param value - GC普通单位数值
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 带KMBT单位的GC字符串
     */
    ToGcKMBTUnitString(value: number, withGc: boolean): string;

    /**
     * GC数值转KMBT单位字符串（整数版）
     * @param value - GC普通单位数值
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 带KMBT单位的GC整数字符串
     */
    ToGcKUnitString(value: number, withGc: boolean): string;

    /**
     * GC数值格式化（根据GoldStringMode自动选择千分位/KMBT单位）
     * @param value - GC数值（数字或字符串类型）
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 格式化后的GC字符串
     */
    ToGcString(value: number | string, withGc: boolean): string;

    /**
     * 美元数值格式化
     * @param value - 美元数值
     * @param needSymbol - 是否显示"$"符号（默认true）
     * @param isTrimZero - 是否去除末尾零（默认true）
     * @param keepCount - 保留小数位数（默认2位）
     * @returns 格式化后的美元字符串
     */
    ToDollarString(value: number, needSymbol: boolean, isTrimZero: boolean, keepCount: number): string;

    /**
     * 邮箱脱敏处理
     * @param email - 原始邮箱
     * @param hideCom - 是否隐藏@及后面的域名（true-隐藏，false-显示）
     * @returns 脱敏后的邮箱字符串
     */
    HideAccountName(email: string, hideCom: boolean): string;

    /**
     * 玩家昵称脱敏处理（仅当长度>6时生效）
     * @param name - 原始昵称
     * @returns 脱敏后的昵称字符串
     */
    HidePlayerName(name: string): string;

    /**
     * 邮箱格式校验
     * @param email - 待校验邮箱
     * @param message - 校验失败时的错误信息（输出参数）
     * @returns true-校验通过，false-校验失败
     */
    VerifyEmail(email: string, message: string): boolean;

    /**
     * 判断字符是否为数字（0-9）
     * @param str - 待判断字符
     * @returns true-是数字，false-不是
     */
    isDigit(str: string): boolean;

    /**
     * 判断字符是否为字母（a-z/A-Z）
     * @param str - 待判断字符
     * @returns true-是字母，false-不是
     */
    isLetter(str: string): boolean;

    /**
     * 邮编格式校验（支持多国规则）
     * @param zipCode - 待校验邮编
     * @param countryCode - 国家代码（如US、GB、JP等）
     * @returns true-校验通过，false-校验失败
     */
    VerifyZipCode(zipCode: string, countryCode: string): boolean;
}

/**
 * 驱动工具类（业务核心工具）
 * 继承基础Util类，实现IDriveTool接口，提供游戏相关的数值处理、校验、脱敏能力
 */
export class DriveTool extends Base implements IDriveTool {
    /** 邮箱格式正则（基础校验：包含@和.） */
    private readonly _regexMail = new RegExp('^\\w+.*@.*\\..*$');
    /** 金币显示模式（0-千分位格式，1-KMBT单位格式） */
    GoldStringMode = 0;

    /**
     * 普通单位转原子单位（用于精确计算，避免浮点数误差）
     * 转换规则：普通单位 × 10000
     * @param count - 普通单位数值
     * @returns 原子单位数值（整数）
     */
    ToAtomUnit(count: number): number {
        return this.DoubleToLong(count * 10000.0);
    }

    /**
     * 数字千分位格式化（支持带小数的数字）
     * 示例：1234.56 → 1,234.56，1234567 → 1,234,567
     * @param num - 待格式化数字
     * @returns 千分位格式化字符串
     */
    formatNumberWithCommas(num: number): string {
        const parts = num.toString().split('.');
        // 整数部分添加千分位分隔符
        parts[0] = parts[0]!.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        // 拼接小数部分（如有）
        return parts.join('.');
    }

    /**
     * 原子单位转普通单位
     * 转换规则：原子单位 × 0.0001（即除以10000）
     * @param count - 原子单位数值
     * @returns 普通单位数值（浮点数）
     */
    ToNormalUnit(count: number): number {
        return count * 0.0001;
    }

    /**
     * SC转美元（当前无汇率转换，直接返回原值，可根据业务扩展）
     * @param sc - SC普通单位数值
     * @returns 美元数值
     */
    ScToDollar(sc: number): number {
        return sc;
    }

    /**
     * 浮点数转整数（四舍五入处理）
     * 正数：+0.00001后向下取整；负数：-0.00001后向下取整
     * @param count - 待转换的浮点数
     * @returns 四舍五入后的整数
     */
    DoubleToLong(count: number): number {
        return count >= 0 ? Math.floor(count + 0.00001) : Math.floor(count - 0.00001);
    }

    /**
     * 根据奖励类型获取格式化的货币字符串
     * - GC：直接返回普通单位数值字符串
     * - SC：原子单位转普通单位后，保留2位小数格式化
     * @param type - 奖励类型（RewardType）
     * @param val - 数值（GC为普通单位，SC为原子单位）
     * @returns 格式化后的货币字符串（未知类型返回空字符串）
     */
    GetCoinString(type: RewardType, val: number): string {
        if (type === RewardType.GC) return val.toString();
        if (type === RewardType.SC) return this.NumberToString(this.ToNormalUnit(val), 2);
        return '';
    }

    /**
     * 获取SC格式化字符串（原子单位转普通单位后处理）
     * 本质调用GetCoinString方法，指定RewardType.SC
     * @param val - SC原子单位数值
     * @returns 格式化后的SC字符串
     */
    GetSCString(val: number): string {
        return this.GetCoinString(RewardType.SC, val);
    }

    /**
     * 获取GC格式化字符串（普通单位直接处理）
     * 本质调用GetCoinString方法，指定RewardType.GC
     * @param val - GC普通单位数值
     * @returns 格式化后的GC字符串
     */
    GetGCString(val: number): string {
        return this.GetCoinString(RewardType.GC, val);
    }

    /**
     * GC数值转KMBT单位字符串（带小数）
     * 示例：20000 → "20.0K"（withGc=true时为"GC 20.0K"）
     * @param value - GC普通单位数值
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 带KMBT单位的GC字符串
     */
    ToGcKMBTUnitString(value: number, withGc: boolean = false): string {
        return withGc ? `GC ${this.ToKMBTUnitString(value)}` : this.ToKMBTUnitString(value);
    }

    /**
     * GC数值转KMBT单位字符串（整数版，无小数）
     * 示例：20000 → "20K"（withGc=true时为"GC 20K"）
     * @param value - GC普通单位数值
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 带KMBT单位的GC整数字符串
     */
    ToGcKUnitString(value: number, withGc: boolean = false): string {
        const str = this.ToKMBTUnitStringInt(value);
        return withGc ? `GC ${str}` : str;
    }

    /**
     * GC数值格式化（根据GoldStringMode自动适配显示格式）
     * - GoldStringMode=1：使用KMBT单位格式
     * - GoldStringMode≠1：使用千分位格式
     * @param value - GC数值（支持数字或字符串类型输入）
     * @param withGc - 是否拼接"GC"前缀（默认false）
     * @returns 格式化后的GC字符串
     */
    ToGcString(value: number | string, withGc: boolean = false): string {
        // 统一转换为数字类型（字符串类型自动解析）
        const val = typeof value === 'number' ? value : parseFloat(value);
        if (this.GoldStringMode === 1) {
            return withGc ? 'GC ' + this.ToKMBTUnitString(val) : this.ToKMBTUnitString(val);
        } else {
            return withGc ? 'GC ' + this.ToThousandsString(val) : this.ToThousandsString(val);
        }
    }

    /**
     * SC数值格式化（支持自定义小数位数和前缀）
     * @param sc - SC普通单位数值
     * @param withSc - 是否拼接"SC"前缀（默认false）
     * @param kc - 保留小数位数（默认2位）
     * @param isTrimZero - 是否去除末尾零（默认true）
     * @returns 格式化后的SC字符串
     */
    ToScString(sc: number, withSc: boolean = false, kc: number = 2, isTrimZero: boolean = true): string {
        return (withSc ? 'SC ' : '') + this.NumberToString(sc, kc, isTrimZero);
    }

    /**
     * 美元数值格式化（支持符号显示、小数位数控制）
     * 示例：123.45 → "$123.45"，123.00 → "$123"（isTrimZero=true）
     * @param value - 美元数值
     * @param needSymbol - 是否显示"$"符号（默认true）
     * @param isTrimZero - 是否去除末尾零（默认true）
     * @param keepCount - 保留小数位数（默认2位）
     * @returns 格式化后的美元字符串
     */
    ToDollarString(
        value: number,
        needSymbol: boolean = true,
        isTrimZero: boolean = true,
        keepCount: number = 2
    ): string {
        return (needSymbol ? '$' : '') + this.NumberToString(value, keepCount, isTrimZero);
    }

    /**
     * 邮箱脱敏处理（保护隐私，隐藏中间部分）
     * 脱敏规则：
     * 1. 邮箱格式校验失败：
     *    - 长度≥4：保留第1、2位和最后2位，中间加"***"
     *    - 长度>2且<4：保留前2位，中间加"***"
     *    - 长度≤2：原值后加"***"
     * 2. 邮箱格式校验通过：
     *    - 用户名部分（@前）：长度≥4保留1、2位和最后2位；长度=3保留前2位和最后1位；长度≤2保留原值，中间加"***"
     *    - 域名部分（@后）：根据hideCom参数决定是否显示
     * @param email - 原始邮箱
     * @param hideCom - 是否隐藏@及后面的域名（true-隐藏，false-显示）
     * @returns 脱敏后的邮箱字符串
     */
    HideAccountName(email: string, hideCom: boolean): string {
        if (!email) return '';
        let message = '';
        // 邮箱格式校验
        if (!this.VerifyEmail(email, message)) {
            const str: string[] = [];
            if (email.length >= 4) {
                str.push(email.charAt(0));
                str.push(email.charAt(1));
                str.push('***');
                str.push(email.charAt(email.length - 2));
                str.push(email.charAt(email.length - 1));
            } else if (email.length > 2) {
                str.push(email.charAt(0));
                str.push(email.charAt(1));
                str.push('***');
            } else {
                str.push(email + '***');
            }
            return str.join('');
        }

        // 邮箱格式正确，拆分用户名和域名
        const atIndex = email.indexOf('@');
        const name = email.substring(0, atIndex);
        const str: string[] = [];

        // 处理用户名脱敏
        if (name.length >= 4) {
            str.push(name.charAt(0));
            str.push(name.charAt(1));
            str.push('***');
            str.push(name.charAt(name.length - 2));
            str.push(name.charAt(name.length - 1));
        } else if (name.length === 3) {
            str.push(name.charAt(0));
            str.push(name.charAt(1));
            str.push('***');
            str.push(name.charAt(2));
        } else if (name.length === 2 || name.length === 1) {
            str.push(name);
            str.push('***');
        }

        // 处理域名显示（hideCom=false时显示@及后面的域名）
        if (!hideCom) {
            const atCom = email.substring(atIndex);
            str.push(atCom);
        }

        return str.join('');
    }

    /**
     * 玩家昵称脱敏处理（仅当昵称长度>6时生效）
     * 脱敏规则：保留前3位和后3位，中间加"*****"
     * 示例：123456789 → 123*****789；123456 → 123456（长度≤6不脱敏）
     * @param playerName - 原始昵称
     * @returns 脱敏后的昵称字符串
     */
    HidePlayerName(playerName: string): string {
        if (!playerName || playerName.length <= 6) return playerName;
        const str: string[] = [];
        str.push(playerName.charAt(0));
        str.push(playerName.charAt(1));
        str.push(playerName.charAt(2));
        str.push('*****');
        str.push(playerName.charAt(playerName.length - 3));
        str.push(playerName.charAt(playerName.length - 2));
        str.push(playerName.charAt(playerName.length - 1));
        return str.join('');
    }

    /**
     * 邮箱格式校验（基础校验规则）
     * 校验逻辑：
     * 1. 邮箱不能为空
     * 2. 邮箱中不能包含空格
     * 3. 符合基础邮箱正则（包含@和.）
     * @param email - 待校验邮箱
     * @param message - 校验失败时的错误信息（输出参数）
     * @returns true-校验通过，false-校验失败
     */
    VerifyEmail(email: string, message: string): boolean {
        message = 'Invalid email address.';
        if (!email) return false;
        // 校验是否包含空格
        if (email.indexOf(' ') >= 0) {
            message = 'Invalid email format. No spaces allowed.';
            return false;
        }
        // 校验正则格式
        if (!this._regexMail.test(email)) return false;
        return true;
    }

    /**
     * 判断单个字符是否为数字（0-9）
     * @param char - 待判断的字符（长度必须为1）
     * @returns true-是数字，false-不是数字
     */
    isDigit(char: string): boolean {
        return /^[0-9]$/.test(char);
    }

    /**
     * 判断单个字符是否为字母（a-z/A-Z，不区分大小写）
     * @param char - 待判断的字符（长度必须为1）
     * @returns true-是字母，false-不是字母
     */
    isLetter(char: string): boolean {
        return /^[a-zA-Z]$/.test(char);
    }

    /**
     * 邮编格式校验（支持多国规则，根据国家代码适配）
     * 支持国家及规则：
     * - US/DE/FR：5位数字
     * - AU：4位数字
     * - GB：分两部分，第二部分3位（数字+字母+字母），第一部分2-4位（字母+数字组合）
     * - JP：8位字符，格式为"XXX-XXXX"（X为数字）
     * - CA：格式为"A1A 1A1"（字母+数字+字母+空格+数字+字母+数字）
     * - 其他国家：长度2-20位即可
     * @param zipCode - 待校验邮编
     * @param countryCode - 国家代码（如US、GB、JP等）
     * @returns true-校验通过，false-校验失败
     */
    VerifyZipCode(zipCode: string, countryCode: string): boolean {
        if (!zipCode) return false;
        if (!countryCode) return false;

        let limitLength: number;
        switch (countryCode) {
            // 美国、德国、法国：5位数字
            case 'US':
            case 'DE':
            case 'FR':
                limitLength = 5;
                if (zipCode.length !== limitLength) return false;
                for (let i = 0; i < limitLength; i++) {
                    if (!this.isDigit(zipCode[i]!)) return false;
                }
                return true;

            // 澳大利亚：4位数字
            case 'AU':
                limitLength = 4;
                if (zipCode.length !== limitLength) return false;
                for (let i = 0; i < limitLength; i++) {
                    if (!this.isDigit(zipCode[i]!)) return false;
                }
                return true;

            // 英国：分两部分，格式如"SW1A 1AA"
            case 'GB':
                const codeSplitList = zipCode.split(' ');
                if (codeSplitList.length !== 2) return false;

                const secondPart = codeSplitList[1]!;
                // 第二部分必须3位，格式：数字+字母+字母
                if (
                    secondPart.length !== 3 ||
                    !this.isDigit(secondPart[0]!) ||
                    !this.isLetter(secondPart[1]!) ||
                    !this.isLetter(secondPart[2]!)
                ) {
                    return false;
                }

                const firstPart = codeSplitList[0]!;
                // 第一部分长度2-4位，字母+数字组合
                switch (firstPart.length) {
                    case 2:
                        return this.isLetter(firstPart[0]!) && this.isDigit(firstPart[1]!);
                    case 3:
                        return (
                            this.isLetter(firstPart[0]!) &&
                            ((this.isDigit(firstPart[1]!) && this.isDigit(firstPart[2]!)) ||
                                (this.isLetter(firstPart[1]!) && this.isDigit(firstPart[2]!)) ||
                                (this.isDigit(firstPart[1]!) && this.isLetter(firstPart[2]!)))
                        );
                    case 4:
                        return (
                            this.isLetter(firstPart[0]!) &&
                            this.isLetter(firstPart[1]!) &&
                            this.isDigit(firstPart[2]!) &&
                            (this.isLetter(firstPart[3]!) || this.isDigit(firstPart[3]!))
                        );
                    default:
                        return false;
                }

            // 日本：格式"XXX-XXXX"（8位字符，含横杠）
            case 'JP':
                limitLength = 8;
                if (zipCode.length !== limitLength) return false;

                const codeSplitList2 = zipCode.split('-');
                if (codeSplitList2.length !== 2 || codeSplitList2[0]!.length !== 3) {
                    return false;
                }

                // 两部分都必须是数字
                for (const part of codeSplitList2) {
                    for (const char of part) {
                        if (!this.isDigit(char)) return false;
                    }
                }
                return true;

            // 加拿大：格式"A1A 1A1"
            case 'CA':
                return /^[A-Z]\d[A-Z] \d[A-Z]\d$/.test(zipCode);

            // 其他国家：长度2-20位
            default:
                return zipCode.length >= 2 && zipCode.length <= 20;
        }
    }
}

/**
 * DriveTool单例实例
 * 全局唯一，可直接导入使用，无需重复创建实例
 */
export default new DriveTool();
