import envTool from './env-tool';

/**
 * 跨页通信工具接口
 * 定义跨页面交互的核心能力，包含页面地址信息获取和父页面消息发送
 */
export interface ICommunicationTool {
    /**
     * 当前页面的「主机地址+路径」组合字符串
     * 格式示例："www.example.com/path/to/page"（主机含域名/IP+端口，路径含/开头的资源路径）
     */
    locationHost: string;

    /**
     * 向当前页面的父页面（如iframe的父窗口）发送消息
     * @param data 待发送的消息数据（支持可结构化克隆的类型，如对象、数组、基础类型等）
     */
    sendMessageToParent(data: any): void;
}

/**
 * 跨页通信工具类（单例实现）
 * 核心能力：
 * 1. 安全获取当前页面的主机+路径信息（兼容非浏览器环境）
 * 2. 基于window.postMessage实现向父页面的消息传递
 * 设计特点：依赖envTool判断浏览器环境，避免非窗口环境执行报错
 */
export class CommunicationTool implements ICommunicationTool {
    /**
     * 获取当前页面的「主机地址+资源路径」组合
     * 主机地址（location.host）：包含域名/IP和端口（如"localhost:8080"、"www.example.com"）
     * 资源路径（location.pathname）：包含从/开始的页面路径（如"/home"、"/user/profile"）
     * @returns 组合字符串（如"localhost:8080/home"），非浏览器环境返回空字符串
     */
    get locationHost(): string {
        // 非浏览器环境（如Node.js）无window对象，直接返回空字符串避免报错
        if (!envTool.isWindow) {
            return '';
        }
        // 拼接主机地址和资源路径，确保返回完整的「域名+路径」标识
        return `${location.host}${location.pathname}`;
    }

    /**
     * 向父页面发送跨域/跨页面消息（基于HTML5 window.postMessage API）
     * 适用场景：iframe子页面向父窗口传递数据、多窗口间通信等
     * @param data 待发送的消息数据（需支持结构化克隆算法，不支持函数、Symbol等类型）
     * @安全提示 生产环境需将目标源（第二个参数）从"*"改为具体域名（如"https://example.com"），
     * 避免向任意网站发送消息导致数据泄露或恶意利用
     */
    sendMessageToParent(data: any): void {
        // 非浏览器环境无window.parent对象，直接返回避免报错
        if (!envTool.isWindow) {
            return;
        }
        // 调用父窗口的postMessage方法发送消息，目标源"*"表示允许向任意父页面发送（仅开发环境临时使用）
        window.parent.postMessage(data, '*');
    }
}

/**
 * 导出跨页通信工具单例实例
 * 全局共享一个实例，确保环境判断逻辑一致，避免重复创建实例导致的冗余
 */
export default new CommunicationTool();
