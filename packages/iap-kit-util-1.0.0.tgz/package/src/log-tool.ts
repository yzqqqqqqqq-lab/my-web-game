import envTool from './env-tool';
import CookieMgr from '@iap/kit-cookie';

/**
 * 日志工具接口
 * 定义日志系统的核心能力，包括日志开关控制、日志格式化、日志输出等功能
 */
export interface ILogTool {
    /**
     * 是否启用普通日志输出（全局日志总开关）
     * 规则：开发环境默认开启，生产环境通过"isLog" Cookie控制（值为"1"时开启）
     */
    isLog: boolean;

    /**
     * 是否启用SDK专属日志输出（SDK模块日志开关）
     * 规则：仅通过"isSdkLog" Cookie控制（值为"1"时开启，不受环境影响）
     */
    isSdkLog: boolean;

    /**
     * 将日志内容格式化为带标签的字符串（用于结构化日志）
     * @param tag 日志标签（用于分类，如"API"、"UI"）
     * @param value 可变参数，待格式化的日志内容（支持任意类型）
     * @returns 格式化后的日志字符串（格式："tag->内容1, 内容2, ..."）
     */
    toLogMessage(tag: string, ...value: any[]): string;

    /**
     * 将日志内容格式化为无标签的字符串（用于简单日志）
     * @param value 可变参数，待格式化的日志内容（支持任意类型）
     * @returns 格式化后的日志字符串（格式："内容1, 内容2, ..."）
     */
    toLogMessage1(...value: any[]): string;

    /**
     * 打印调试日志（带样式，仅isLog为true时输出）
     * @param tag 日志标签（用于分类）
     * @param value 可变参数，待输出的日志内容（支持任意类型）
     */
    logDebug(tag: string, ...value: any[]): void;

    /**
     * 打印错误日志（带样式，不受isLog控制，强制输出）
     * @param value 可变参数，待输出的错误内容（支持任意类型）
     */
    logError(...value: any[]): void;

    /** 当前时间戳（毫秒级，基于Date.now()） */
    localTimeStampMill: number;

    /** 日志工具初始化时的时间戳（毫秒级，用于计算相对时间） */
    startTimeMill: number;
}

/**
 * 日志打印工具类（单例实现）
 * 核心能力：
 * 1. 日志开关控制（区分开发/生产环境，支持Cookie动态配置）
 * 2. 日志内容格式化（带标签/无标签两种格式）
 * 3. 带样式的日志输出（调试日志绿色样式，错误日志红色样式）
 * 4. 时间戳管理（当前时间、初始化时间，用于日志时间追踪）
 * 设计特点：通过环境判断和Cookie灵活控制日志输出，避免生产环境冗余日志
 */
export class LogTool implements ILogTool {
    /**
     * 普通日志总开关（控制logDebug等调试日志的输出）
     * 逻辑分层：
     * - 开发环境（envTool.isDev为true）：默认开启（无需Cookie）
     * - 生产环境：读取名为"isLog"的Cookie，值为"1"时开启，其他值关闭
     * @returns true：启用日志；false：禁用日志
     */
    get isLog(): boolean {
        if (envTool.isDev) {
            return true;
        }
        const logCookie = CookieMgr.getCookie('isLog');
        return logCookie === '1';
    }

    /**
     * SDK专属日志开关（独立于普通日志，用于SDK模块的精细化日志控制）
     * 控制逻辑：不区分环境，仅读取名为"isSdkLog"的Cookie，值为"1"时开启
     * @returns true：启用SDK日志；false：禁用SDK日志
     */
    get isSdkLog(): boolean {
        const sdkLogCookie = CookieMgr.getCookie('isSdkLog');
        return sdkLogCookie === '1';
    }

    /**
     * 获取当前时间戳（毫秒级，用于日志的时间标记）
     * 基于Date.now()实现，返回自1970-01-01 UTC以来的毫秒数
     * @returns 当前时间戳（数字类型）
     */
    get localTimeStampMill(): number {
        return Date.now();
    }

    /**
     * 获取日志工具初始化时的时间戳（毫秒级，用于计算日志相对时间）
     * 每次访问时返回工具类实例化时的时间（固定值，非实时更新）
     * @returns 初始化时间戳（数字类型）
     */
    get startTimeMill(): number {
        return new Date().getTime();
    }

    /**
     * 将日志内容格式化为带标签的字符串（便于日志分类检索）
     * 空值处理：null值会被格式化为"null"，避免输出"undefined"
     * @param tag 日志标签（如"API_REQUEST"、"STATE_CHANGE"）
     * @param value 可变参数列表，支持任意类型（会调用toString()转换）
     * @returns 格式化字符串（示例："API->url: /api/data, status: 200"）
     */
    toLogMessage(tag: string, ...value: any[]): string {
        let logStr = `${tag}->`; // 起始标签
        value.forEach((val, index) => {
            // 多个参数间用逗号分隔，第一个参数前不加逗号
            logStr += index > 0 ? ', ' : '';
            // 处理null值，其他值调用toString()
            logStr += val !== null ? val.toString() : 'null';
        });
        return logStr;
    }

    /**
     * 将日志内容格式化为无标签的字符串（适用于简单日志场景）
     * 与toLogMessage的区别：无起始标签，直接拼接内容
     * @param value 可变参数列表，支持任意类型（会调用toString()转换）
     * @returns 格式化字符串（示例："user login, id: 123"）
     */
    toLogMessage1(...value: any[]): string {
        let logStr = '';
        value.forEach((val, index) => {
            logStr += index > 0 ? ', ' : '';
            // 处理 falsy 值（0、''、false等会被正常转换，null/undefined显示为"null"）
            logStr += val ? val.toString() : 'null';
        });
        return logStr;
    }

    /**
     * 打印调试日志（带视觉样式，仅在isLog为true时输出）
     * 样式说明：
     * - 标签部分：绿色背景（\x1b[42m）+ 黑色文字（\x1b[30m）
     * - 内容部分：绿色文字（\x1b[32m）
     * - 重置样式：\x1b[0m（避免影响后续日志）
     * 附加信息：包含相对时间（当前时间 - 初始化时间，单位ms），用于性能分析
     * @param tag 日志标签（用于分类）
     * @param value 可变参数，待输出的调试内容
     */
    logDebug(tag: string, ...value: any[]): void {
        if (this.isLog) {
            // 计算相对时间（日志输出时已过的毫秒数）
            const relativeTime = `${this.localTimeStampMill - this.startTimeMill}ms`;
            // 使用ANSI转义码控制控制台样式，拼接日志内容
            console.log(
                `\x1b[42m\x1b[30m ${tag} \x1b[0m\x1b[32m ${this.toLogMessage1(...value)} \x1b[0m`,
                relativeTime
            );
        }
    }

    /**
     * 打印错误日志（带视觉样式，不受isLog控制，强制输出）
     * 样式说明：
     * - 错误标记：红色背景（\x1b[41m）+ 白色文字（\x1b[37m）
     * - 内容部分：红色文字（\x1b[31m）
     * - 重置样式：\x1b[0m
     * 设计目的：错误日志需优先展示，不被日志开关屏蔽
     * @param value 可变参数，待输出的错误内容（通常为错误对象、错误信息）
     */
    logError(...value: any[]): void {
        // @ts-ignore 忽略类型检查，确保任意类型参数都能正常输出
        console.error('\x1b[41m\x1b[37m Err ERROR \x1b[0m\x1b[31m ' + this.toLogMessage('', ...value) + '\x1b[0m');
    }
}

/**
 * 导出日志工具单例实例
 * 全局共享一个实例，确保日志开关状态、初始化时间戳等全局一致，避免多实例导致的日志混乱
 */
export default new LogTool();
