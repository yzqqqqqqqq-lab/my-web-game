'use client';
// 导入所需的模块和类型
import { UAParser, type IResult } from 'ua-parser-js';
import { logger } from '@iap/kit-logger';
import DataMgr from '@iap/kit-storage';

/**
 * 浏览器工具类接口定义
 * 封装浏览器、设备、系统、网络等相关信息的获取和判断方法
 */
export interface IBrowserTool {
    /** UAParser解析后的原始结果 */
    res: IResult | null;
    uap: UAParser | null;
    /** 获取操作系统名称（兼容性处理） */
    getOsName: string;
    /** 获取操作系统版本（兼容性处理） */
    getOsVersion: string;
    /** 获取设备类型（兼容性处理） */
    getDeviceType: string;
    /** 获取浏览器名称（兼容性处理） */
    getBrowserName: string;
    /** 获取浏览器版本（兼容性处理） */
    getBrowserVersion: string;
    /** 是否在Facebook旗下应用中打开（含Instagram/WhatsApp等） */
    isFacebookApp: boolean;
    /** 是否为Google Chrome浏览器（含Chromium/Chrome移动版等变体） */
    isGoogleChrome: boolean;
    /** H5 UUID（持久化存储，可通过setH5UUID修改） */
    h5UUID: string;
    /** H5浏览器唯一标识（持久化存储在localStorage，浏览器生命周期内不变） */
    h5BrowserUUID: string;
    /** 是否为macOS系统 */
    isMacOS: boolean;
    /** 获取系统所在国家/地区代码（从语言设置中解析） */
    getSystemCountry: string;
    /** 是否为Safari浏览器（严格判断，排除Chrome等伪装Safari的UA） */
    isSafari: boolean;
    /** 获取UA解析结果的JSON字符串 */
    getUaJson: string;
    /** 获取网络类型（如4g、wifi等） */
    getNetworkType: string;
    /** 设备内存大小 */
    deviceMemory: string;
    /** 是否为桌面端环境（结合UA和视口宽度判断） */
    isDesktop: boolean;
    /** 获取当前页面的域名 */
    getHostName: string;
    /**
     * 设置H5 UUID
     * @param uuid - 要设置的UUID字符串
     */
    setH5UUID(uuid: string): void;
    /**
     * 获取H5 UUID（优先从localStorage读取，无则生成新值并存储）
     * @returns H5 UUID字符串
     */
    getH5UUID(): string;
    /**
     * 生成标准UUID（v4格式）
     * @returns UUID字符串
     */
    generateUUID(): string;
    /**
     * 获取浏览器完整信息（UAParser原始解析结果）
     * @returns IResult解析结果或null
     */
    getBrowserInfo(): IResult | null;
    /**
     * 获取操作系统详细信息
     * @returns 操作系统信息对象或undefined
     */
    getOSInfo(): UAParser.IOS | undefined;
}

/**
 * 浏览器工具类 - 通用版本
 * 封装浏览器、设备、系统、网络、存储等相关信息的获取与判断逻辑
 * 特性：
 * 1. 兼容浏览器环境，非浏览器环境返回默认值
 * 2. 关键标识（h5UUID/h5BrowserUUID）持久化存储
 * 3. 基于ua-parser-js解析UA信息，保证兼容性
 * 4. 提供丰富的设备/浏览器/系统判断方法
 */
export class BrowserTool implements IBrowserTool {
    /** 日志打印标签 */
    tag: string = `[BrowserTool]`;
    /** UAParser实例（延迟初始化） */
    private _uap: any = null;
    /** UAParser解析结果缓存 */
    private _res: IResult | null = null;
    /** H5 UUID缓存（对应localStorage中的H5_UUID） */
    private newUUID: string = '';
    /** 浏览器唯一标识缓存（对应localStorage中的H5_BROWSER_UUID） */
    private _h5_browser_uuid: string = '';

    /**
     * 获取UAParser解析结果（延迟初始化，首次访问时解析UA）
     * @returns IResult解析结果或null
     */
    get res() {
        if (this._res) return this._res;
        // 初始化UAParser实例
        this._uap = this.uap;
        // 解析UA并缓存结果
        this._res = this._uap.getResult();
        return this._res;
    }

    // 获取原始UAParser
    get uap() {
        if (this._uap) return this._uap;
        this._uap = new UAParser();
        return this._uap;
    }

    /**
     * 获取操作系统名称（兼容性处理）
     * @returns 操作系统名称（如Windows、macOS、iOS、Android），获取失败返回空字符串
     */
    get getOsName(): string {
        return this.getOSInfo()?.name || '';
    }

    /**
     * 获取操作系统版本（兼容性处理）
     * @returns 操作系统版本号（如10、12.6.1、14.0），获取失败返回空字符串
     */
    get getOsVersion(): string {
        return this.getOSInfo()?.version || '';
    }

    /**
     * 获取设备类型（兼容性处理）
     * @returns 设备类型（mobile/tablet/desktop等），获取失败返回空字符串
     */
    get getDeviceType(): string {
        const device = this.getDeviceInfo();
        return device?.type || '';
    }

    /**
     * 获取浏览器名称（兼容性处理）
     * @returns 浏览器名称（如Chrome、Safari、Firefox），获取失败返回空字符串
     */
    get getBrowserName(): string {
        return this.res?.browser?.name || '';
    }

    /**
     * 获取浏览器版本（兼容性处理）
     * @returns 浏览器版本号（如114.0.5735.198），获取失败返回空字符串
     */
    get getBrowserVersion(): string {
        return this.res?.browser?.version || '';
    }

    /**
     * 判断是否在Facebook旗下的应用中打开
     * 匹配应用：Facebook、Instagram、WhatsApp、OculusBrowser、Messenger、Workplace
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    get isFacebookApp(): boolean {
        if (typeof window !== 'undefined') {
            const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
            // 匹配Facebook生态相关应用的UA特征
            return /FBAN|FBAV|Instagram|WhatsApp|OculusBrowser|Messenger|Workplace/.test(userAgent);
        }
        return false;
    }

    /**
     * 判断是否为Google Chrome浏览器（含变体）
     * 排除规则：Microsoft Edge、Opera浏览器
     * 包含变体：Chromium、Chrome Mobile、Chrome Canary、Chrome Beta、Chrome Dev、Chrome WebView
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    get isGoogleChrome(): boolean {
        if (typeof window !== 'undefined') {
            const userAgent = navigator.userAgent.toLowerCase();

            if (userAgent.includes('chrome')) {
                if (userAgent.includes('edg')) return false; // 排除Microsoft Edge（UA含edg标识）
                if (userAgent.includes('opr') || userAgent.includes('opera')) return false; // 排除Opera浏览器（UA含opr/opera标识）
                if (userAgent.includes('chromium')) return true; // 匹配Chromium内核浏览器
                if (userAgent.includes('mobile safari') && userAgent.includes('crios')) return true; // 匹配Chrome Mobile（iOS端）
                if (userAgent.includes('canary')) return true; // 匹配Chrome Canary（金丝雀版）
                if (userAgent.includes('chrome') && userAgent.includes('beta')) return true; // 匹配Chrome Beta（测试版）
                if (userAgent.includes('chrome') && userAgent.includes('dev')) return true; // 匹配Chrome Dev（开发版）
                if (userAgent.includes('wv')) return true; // 匹配Chrome WebView（嵌入式WebView）
                return true; // 匹配标准Google Chrome（含Chrome OS）
            }
        }
        return false;
    }

    /**
     * H5 UUID属性（兼容性封装）
     * 本质是getH5UUID()的快捷访问方式
     * @returns H5 UUID字符串
     */
    get h5UUID(): string {
        return this.getH5UUID();
    }

    /**
     * H5浏览器唯一标识（兼容性处理）
     * 特性：
     * 1. 持久化存储在localStorage，浏览器生命周期内保持不变
     * 2. 首次访问时生成，后续直接读取缓存
     * 3. 键名：H5_BROWSER_UUID
     * @returns 浏览器唯一标识UUID
     */
    get h5BrowserUUID(): string {
        // 优先返回缓存值
        if (this._h5_browser_uuid) return this._h5_browser_uuid;

        // 浏览器环境下尝试从localStorage读取
        if (typeof window !== 'undefined') {
            const stored = DataMgr.getStorage('H5_BROWSER_UUID');
            if (stored) {
                this._h5_browser_uuid = stored;
                return stored;
            }
        }

        // 生成新的浏览器唯一标识并存储
        const newBrowserUUID = this.generateUUID();
        this._h5_browser_uuid = newBrowserUUID;
        if (typeof window !== 'undefined') {
            DataMgr.setStorage('H5_BROWSER_UUID', newBrowserUUID);
        }
        return newBrowserUUID;
    }

    /**
     * 判断是否为macOS系统（基于navigator.platform判断，比UA更准确）
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    get isMacOS(): boolean {
        if (typeof window !== 'undefined') {
            // navigator.platform以Mac开头的均为macOS（含Intel和Apple Silicon架构）
            return /^Mac/.test(navigator.platform);
        }
        return false;
    }

    /**
     * 获取系统所在的国家/地区代码
     * 解析逻辑：从浏览器语言设置中提取（如zh-CN→CN，en-US→US，ja→ja）
     * 错误处理：静默处理异常并记录日志
     * @returns 国家/地区代码（大写），获取失败返回空字符串
     */
    get getSystemCountry(): string {
        try {
            const language = this.getLanguage();
            // 分割语言标识（支持"-"和"_"分隔符，如zh-CN、zh_CN）
            const parts = language.split(/[-_]/);
            if (parts[1]) {
                return parts[1].toUpperCase();
            } else if (parts[0]) {
                return parts[0];
            }
        } catch (e) {
            // 静默处理错误，避免影响主流程
            logger.error(`${this.tag} getSystemCountry error: ${e}`);
        }
        return '';
    }

    /**
     * 判断当前是否为Safari浏览器（双重验证，避免误判）
     * 判断逻辑：
     * 1. UA不含chrome/android关键字且包含safari
     * 2. 全局对象存在safari属性
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    // get isSafari(): boolean {
    //     if (typeof window !== 'undefined') {
    //         const ua = navigator.userAgent;
    //         // 排除Chrome等伪装Safari的浏览器
    //         const isSafariBrowser = /^((?!chrome|android).)*safari/i.test(ua);
    //         // 验证Safari特有全局对象
    //         const isSafariGlobal = !!(window as any).safari;
    //         return isSafariBrowser && isSafariGlobal;
    //     }
    //     return false;
    // }
    // TODO: 对比isSafari，考虑是否保留@郭翰敏 @李智业
    /**
     * 判断当前是否为Safari浏览器
     * 判断逻辑：UA不含chrome/android关键字且包含safari
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    get isSafari(): boolean {
        if (typeof window === 'undefined') {
            return false;
        }
        const ua = navigator.userAgent;
        return /^((?!chrome|android).)*safari/i.test(ua);
    }

    /**
     * 获取浏览器的UA解析结果JSON字符串
     * 错误处理：解析失败返回"JSON err"并记录日志
     * @returns UA解析结果的JSON字符串
     */
    get getUaJson(): string {
        try {
            return JSON.stringify(this.res);
        } catch (e) {
            // 静默处理JSON序列化错误
            logger.error(`${this.tag} getUaJson error: ${e}`);
            return 'JSON err';
        }
    }

    /**
     * 获取网络类型（基于navigator.connection API）
     * 支持属性：type（网络类型）、effectiveType（有效网络类型）
     * @returns 网络类型字符串，不支持该API返回"0"
     */
    get getNetworkType(): string {
        if (typeof window !== 'undefined' && 'connection' in navigator) {
            const connection = (navigator as any).connection;
            // 优先返回type，无则返回effectiveType
            return `${connection.type || connection.effectiveType}`;
        }
        return '0';
    }

    /**
     * 获取设备内存信息（基于navigator.deviceMemory API）
     * 单位：GB（返回字符串格式，如"8 GB"）
     * @returns 设备内存字符串，不支持该API返回"0GB"
     */
    get deviceMemory(): string {
        if (typeof window !== 'undefined' && 'deviceMemory' in navigator) {
            const deviceMemory = (navigator as any).deviceMemory as number;
            return `${deviceMemory} GB`;
        }
        return '0GB';
    }

    /**
     * 判断当前是否为桌面环境（双重判断，提高准确性）
     * 判断逻辑：
     * 1. UA包含win/mac/linux关键字
     * 2. 视口宽度≥1024px
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    get isDesktop(): boolean {
        if (typeof window !== 'undefined') {
            const userAgent = navigator.userAgent.toLowerCase();
            // 桌面端常见平台标识
            const desktopPlatforms = ['win', 'mac', 'linux'];
            const isDesktopUA = desktopPlatforms.some((platform) => userAgent.includes(platform));
            // 视口宽度判断（桌面端最小宽度阈值）
            const isWideViewport = window.innerWidth >= 1024;
            return isDesktopUA && isWideViewport;
        }
        return false;
    }

    /**
     * 获取当前页面的域名（基于location.hostname）
     * @returns 域名字符串（如example.com）
     */
    get getHostName(): string {
        return location.hostname;
    }

    /**
     * 构造函数：初始化工具类
     * 调用Init方法完成初始化操作
     */
    constructor() {
        this.Init();
    }

    /**
     * 初始化方法
     * 功能：触发UA解析并打印解析结果日志
     */
    Init(): void {
        // 触发res的getter，初始化UAParser并解析UA
        const res1 = this.res;
        // 打印UA解析结果日志（便于调试）
        logger.info(this.tag, `UAParser => ${JSON.stringify(res1)}`);
    }

    /**
     * 设置H5 UUID并持久化到localStorage
     * @param value - 要设置的UUID字符串（非空才会生效）
     * @sideEffect 修改localStorage中的H5_UUID字段
     */
    setH5UUID(value: string): void {
        if (value) {
            this.newUUID = value;
            DataMgr.setStorage('H5_UUID', value);
        }
    }

    /**
     * 获取H5 UUID（持久化存储，跨会话保持）
     * 获取优先级：
     * 1. 已缓存的newUUID
     * 2. localStorage中的H5_UUID
     * 3. 新生成的UUID（并自动存储）
     * @returns H5 UUID字符串
     * @sideEffect 首次调用会生成UUID并存储到localStorage
     */
    getH5UUID(): string {
        // 优先返回缓存值
        if (this.newUUID) return this.newUUID;

        const stored = DataMgr.getStorage('H5_UUID');
        if (stored) {
            this.newUUID = stored;
            return stored;
        }

        // 生成新UUID并存储
        const newUUID = this.generateUUID();
        this.setH5UUID(newUUID);
        return newUUID;
    }

    /**
     * 生成标准UUID v4格式字符串
     * 格式：xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
     * 其中y位固定为8、9、A、B中的一个
     * @returns UUID v4字符串
     */
    generateUUID(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            // 生成随机数（0-15）
            const r = (Math.random() * 16) | 0;
            // x位取随机数，y位取(0-3)|8（确保符合UUID v4规范）
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }

    /**
     * 获取浏览器完整信息
     * 本质是res属性的封装方法，便于外部显式调用
     * @returns UAParser解析结果或null
     */
    getBrowserInfo() {
        return this.res;
    }

    /**
     * 获取操作系统详细信息
     * @returns 操作系统信息对象（包含name、version等字段）或undefined
     */
    getOSInfo() {
        return this.res?.os;
    }

    /**
     * 获取设备详细信息
     * @returns 设备信息对象（包含type、vendor、model等字段）或undefined
     */
    getDeviceInfo() {
        return this.res?.device;
    }

    /**
     * 获取CPU详细信息
     * @returns CPU信息对象（包含architecture等字段）或undefined
     */
    getCPUInfo() {
        return this.res?.cpu;
    }

    /**
     * 获取浏览器引擎详细信息
     * @returns 引擎信息对象（包含name、version等字段）或undefined
     */
    getEngineInfo() {
        return this.res?.engine;
    }

    /**
     * 判断是否为移动设备（基于UAParser解析的设备类型）
     * @returns true-是，false-否
     */
    isMobile(): boolean {
        const device = this.getDeviceInfo();
        return device?.type === 'mobile';
    }

    /**
     * 判断是否为平板设备（基于UAParser解析的设备类型）
     * @returns true-是，false-否
     */
    isTablet(): boolean {
        const device = this.getDeviceInfo();
        return device?.type === 'tablet';
    }

    /**
     * 获取浏览器用户代理字符串（UA）
     * @returns UA字符串，非浏览器环境返回空字符串
     */
    getUserAgent(): string {
        if (typeof window !== 'undefined') {
            return navigator.userAgent;
        }
        return '';
    }

    /**
     * 判断设备是否支持触摸操作
     * 判断依据：
     * 1. 存在ontouchstart事件
     * 2. 最大触摸点数>0
     * @returns true-支持，false-不支持（非浏览器环境返回false）
     */
    isTouchDevice(): boolean {
        if (typeof window !== 'undefined') {
            return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        }
        return false;
    }

    /**
     * 获取屏幕详细信息
     * @returns 屏幕信息对象（包含宽高、可用宽高、颜色深度等），非浏览器环境返回null
     */
    getScreenInfo() {
        if (typeof window !== 'undefined') {
            return {
                width: window.screen.width, // 屏幕总宽度
                height: window.screen.height, // 屏幕总高度
                availWidth: window.screen.availWidth, // 屏幕可用宽度（不含任务栏）
                availHeight: window.screen.availHeight, // 屏幕可用高度（不含任务栏）
                colorDepth: window.screen.colorDepth, // 颜色深度
                pixelDepth: window.screen.pixelDepth // 像素深度
            };
        }
        return null;
    }

    /**
     * 获取视口详细信息（当前可见区域）
     * @returns 视口信息对象（包含宽高），非浏览器环境返回null
     */
    getViewportInfo() {
        if (typeof window !== 'undefined') {
            return {
                width: window.innerWidth, // 视口宽度（含滚动条）
                height: window.innerHeight // 视口高度（含滚动条）
            };
        }
        return null;
    }

    /**
     * 判断是否为iOS设备（含iPhone、iPad、iPod）
     * 排除规则：排除Windows Phone等伪装iOS的设备（通过MSStream对象判断）
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    isIOS(): boolean {
        if (typeof window !== 'undefined') {
            return (
                /iPhone|iPad|iPod/i.test(navigator.userAgent) && !(window as any).MSStream // 排除Windows Phone
            );
        }
        return false;
    }

    /**
     * 判断是否为Android设备
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    isAndroid(): boolean {
        if (typeof window !== 'undefined') {
            return /Android/i.test(navigator.userAgent);
        }
        return false;
    }

    /**
     * 判断是否为iPadOS设备（iPad运行的iPadOS，区别于传统iOS）
     * 判断依据：
     * 1. 平台为MacIntel（iPadOS 13+的特性）
     * 2. 最大触摸点数>1（支持触摸操作）
     * @returns true-是，false-否（非浏览器环境返回false）
     */
    isIPadOS(): boolean {
        if (typeof window !== 'undefined') {
            return navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
        }
        return false;
    }

    /**
     * 获取网络连接详细信息（基于navigator.connection API）
     * @returns 网络连接信息对象（含有效类型、下行速度、往返时间等），不支持该API返回null
     */
    getConnectionInfo() {
        if (typeof window !== 'undefined' && 'connection' in navigator) {
            const connection = (navigator as any).connection;
            return {
                effectiveType: connection.effectiveType, // 有效网络类型（如4g、3g）
                downlink: connection.downlink, // 下行速度（Mbps）
                rtt: connection.rtt, // 往返时间（ms）
                saveData: connection.saveData // 是否开启省流量模式
            };
        }
        return null;
    }

    /**
     * 判断设备是否处于在线状态
     * @returns true-在线，false-离线（非浏览器环境默认返回true）
     */
    isOnline(): boolean {
        if (typeof window !== 'undefined') {
            return navigator.onLine;
        }
        return true;
    }

    /**
     * 获取浏览器语言设置
     * 优先级：
     * 1. navigator.language（首选语言）
     * 2. navigator.languages[0]（语言列表第一个）
     * 3. 默认返回"en"
     * @returns 语言标识字符串（如zh-CN、en-US）
     */
    getLanguage(): string {
        if (typeof navigator === 'undefined') return 'en';
        let lang = navigator.language || (navigator as Navigator & { userLanguage: string }).userLanguage;

        if (lang) {
            // 处理可能存在的 q 值参数
            lang = lang.split(';')[0]; // 移除 ";q=0.9" 部分
            return lang.toLowerCase();
        }

        return 'en'; // 默认返回英语
    }

    /**
     * 获取设备时区信息
     * 基于Intl.DateTimeFormat API，兼容性良好
     * 错误处理：获取失败返回"UTC"
     * @returns 时区字符串（如Asia/Shanghai、UTC）
     */
    getTimezone(): string {
        try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone;
        } catch {
            return 'UTC';
        }
    }

    /**
     * 在Android设备的Google Chrome浏览器中打开指定URL
     * 通过Android Intent协议唤起Chrome，支持添加额外参数
     * @param url - 要打开的目标URL
     * @param addParam - 是否添加is_open_chrome=1参数（默认false）
     * @sideEffect 跳转至Intent协议URL，唤起Chrome浏览器
     */
    openInChrome(url: string, addParam: boolean = false): void {
        try {
            const targetUrl = new URL(url);
            // 可选添加额外参数（用于标识通过Chrome打开）
            if (addParam) {
                targetUrl.searchParams.set('is_open_chrome', '1');
            }
            // 构造Android Intent协议URL，指定Chrome包名
            const intentUrl = `intent://${targetUrl.href.replace(/(https|http):\/\//, '')}#Intent;scheme=https;action=android.intent.action.VIEW;component=com.android.chrome;package=com.android.chrome;end`;
            // 跳转至Intent URL
            location.href = intentUrl;
        } catch (e) {
            logger.error(`${this.tag} Error opening Chrome:`, e);
        }
    }
}

/**
 * BrowserTool单例实例
 * 全局唯一，可直接导入使用，无需重复创建实例
 */
export default new BrowserTool();
