'use client';
import CookieMgr from '@iap/kit-cookie';

/**
 * 环境判断工具接口
 * 定义环境相关的核心判断能力，涵盖环境类型、设备系统、浏览器上下文、时区等信息
 */
export interface IEnvTool {
    /** 是否为开发环境（用于区分开发/生产环境的功能开关） */
    isDev: boolean;
    /** 是否启用测试模式（开发环境默认开启，生产环境通过Cookie控制） */
    isTestMode: boolean;
    /** 是否处于浏览器窗口环境（判断是否可访问window对象） */
    isWindow: boolean;
    /** 当前页面的路径（浏览器环境取location.pathname，非浏览器环境默认返回'/'） */
    pathname: string;
    /** 是否存在浏览器导航对象（判断是否可访问navigator，需同时满足window存在） */
    isNavigator: boolean;
    /** 是否为iPadOS设备（针对iPadOS 13+的特殊UA识别逻辑） */
    isIPadOS: boolean;
    /** 是否为iOS设备（含iPhone/iPad/iPod，兼容iPadOS的特殊判断） */
    isIOS: boolean;
    /** 是否为Android设备（通过UserAgent匹配Android关键字） */
    isAndroid: boolean;
    /** 是否为移动端或WebView环境（通过UA识别移动设备或WebView标识） */
    isMobileOrWebView: boolean;
    /** 当前时区偏移（相对于UTC，格式如"+8"表示东8区，"-5"表示西5区） */
    GetTimeZone: string;
}

/**
 * 环境判断工具类（单例实现）
 * 核心能力：
 * 1. 区分开发/生产环境、测试模式开关
 * 2. 识别浏览器上下文（window/navigator是否存在）
 * 3. 判断设备系统（iOS/iPadOS/Android）及移动端/WebView
 * 4. 获取页面路径、时区等环境信息
 * 设计特点：所有属性均为getter，确保每次获取都是实时环境状态，无缓存过期问题
 */
export class EnvTool implements IEnvTool {
    /**
     * 判断是否为开发环境
     * 依赖Node.js的环境变量NODE_ENV，通常由构建工具（如Webpack/Vite）注入
     * @returns true：开发环境（NODE_ENV === 'development'）；false：生产环境（NODE_ENV === 'production'等）
     */
    get isDev(): boolean {
        return process.env.NODE_ENV === 'development';
    }

    /**
     * 判断是否启用测试模式（用于生产环境临时开启调试功能）
     * 逻辑分层：
     * - 开发环境：默认开启（无需Cookie）
     * - 生产环境：读取名为"isTestMode"的Cookie，值为"1"时开启
     * @returns true：启用测试模式；false：禁用测试模式
     */
    get isTestMode(): boolean {
        if (this.isDev) return true;
        const testModeCookie = CookieMgr.getCookie('isTestMode');
        return testModeCookie === '1';
    }

    /**
     * 判断当前是否处于浏览器窗口环境（避免非浏览器环境执行window相关代码报错）
     * 适用场景：区分浏览器（有window）和Node.js（无window）环境
     * @returns true：浏览器环境（window存在）；false：非浏览器环境
     */
    get isWindow(): boolean {
        // 用"typeof window === 'undefined'"判断，避免直接访问window导致报错
        return !(typeof window === 'undefined');
    }

    /**
     * 获取当前页面的路径（不含查询参数和哈希）
     * 浏览器环境：取window.location.pathname（如"/home"、"/user/profile"）
     * 非浏览器环境：默认返回"/"，避免后续逻辑因空值出错
     * @returns 页面路径字符串
     */
    get pathname(): string {
        if (this.isWindow) {
            return `${window.location.pathname}`;
        }
        return '/';
    }

    /**
     * 判断当前是否存在浏览器导航对象（navigator）
     * 需同时满足两个条件：1. window存在；2. navigator存在（部分特殊环境可能缺失navigator）
     * @returns true：存在navigator（可用于UA判断、设备识别）；false：不存在
     */
    get isNavigator(): boolean {
        return !(typeof window === 'undefined' || typeof navigator === 'undefined');
    }

    /**
     * 特殊判断：是否为iPadOS 13+设备
     * 背景：iPadOS 13及以上版本的UserAgent会伪装成"MacIntel"（类似Mac电脑），需额外判断触摸能力
     * 判断逻辑：1. 存在navigator；2. 平台为"MacIntel"；3. 支持触摸（maxTouchPoints > 1）
     * @returns true：iPadOS设备；false：非iPadOS设备
     */
    get isIPadOS() {
        if (!this.isNavigator) return false;
        return navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
    }

    /**
     * 判断是否为iOS设备（含iPhone、iPad、iPod，兼容iPadOS的特殊情况）
     * 判断逻辑分层：
     * 1. 基础UA匹配：包含"iPhone"/"iPad"/"iPod"关键字
     * 2. 排除IE浏览器：通过!(window as any).MSStream（IE的特殊属性）
     * 3. 兼容iPadOS：合并isIPadOS的判断结果（因iPadOS UA已不包含"iPad"）
     * @returns true：iOS设备；false：非iOS设备
     */
    get isIOS() {
        if (!this.isNavigator) return false;
        // 基础iOS设备UA判断，排除IE
        const isBaseIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent) && !(window as any).MSStream;
        // 合并iPadOS判断，确保全版本iPad识别
        return isBaseIOS || this.isIPadOS;
    }

    /**
     * 判断是否为Android设备
     * 核心逻辑：通过UserAgent匹配"Android"关键字（不区分大小写，因UA可能有"Aandroid"/"ANDROID"等变体）
     * @returns true：Android设备；false：非Android设备
     */
    get isAndroid(): boolean {
        if (!this.isNavigator) return false;
        return /Android/i.test(navigator.userAgent);
    }

    /**
     * 判断是否为移动端或WebView环境（用于适配移动端UI或限制WebView特殊行为）
     * UA识别关键词说明：
     * - "Android"/"iPhone"/"iPad"/"iPod"/"Mobile"：移动端设备标识
     * - "wv"/"WebView"/"; wv"：WebView环境标识（如微信内置浏览器、App内嵌WebView）
     * @returns true：移动端或WebView；false：桌面端非WebView
     */
    get isMobileOrWebView(): boolean {
        if (!this.isNavigator) return false;
        const userAgent = navigator.userAgent || '';
        return /Android|iPhone|iPad|iPod|Mobile|wv|WebView|; wv/.test(userAgent);
    }

    /**
     * 获取当前时区相对于UTC的偏移量（单位：小时）
     * 计算逻辑：
     * 1. new Date().getTimezoneOffset()：返回UTC与本地时间的分钟差（如东8区返回-480，西5区返回300）
     * 2. 取反并除以60：将分钟差转为小时偏移（-480 → +8，300 → -5）
     * 3. 格式处理：正数加"+"，负数保留"-"（如"+8"、"-5"）
     * @returns 时区偏移字符串（格式：±数字）
     */
    get GetTimeZone() {
        // 分钟差转小时差，取反后处理符号
        const hourOffset = -new Date().getTimezoneOffset() / 60;
        return hourOffset >= 0 ? `+${hourOffset}` : `${hourOffset}`;
    }
}

/**
 * 导出环境工具单例实例
 * 全局共享一个实例，确保所有模块获取的环境状态一致（如isDev、时区等不会出现多实例不一致问题）
 */
export default new EnvTool();
