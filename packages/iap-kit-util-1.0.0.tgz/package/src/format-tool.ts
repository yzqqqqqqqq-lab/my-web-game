/**
 * 格式转换工具接口
 * 定义格式转换的核心能力，涵盖数字格式化（千分位、单位换算、精度控制）、
 * 数组序列化（一维/二维数组转字符串）、路由路径匹配等功能
 */
export interface IFormatTool {
    /**
     * 数字转换为带千分位的字符串
     * @param v 待转换的数字
     * @returns 带千分位的字符串（v≤0时返回"0"）
     */
    toThousandsString(v: number): string;

    /**
     * 数字×10000后转换为带千分位的字符串（适配原子值场景）
     * @param v 待转换的原始数字
     * @returns 处理后的带千分位字符串（先×10000再按原子值规则格式化）
     */
    toThousandString(v: number): string;

    /**
     * 原子值转换为带千分位的字符串（原子值：内部计算用的高精度单位，10000原子值=1个业务单位）
     * @param atomValue 待转换的原子值
     * @param keepCount 保留的小数位数（默认3位）
     * @returns 带千分位的业务单位字符串
     */
    toThousandAtomString(atomValue: number, keepCount?: number): string;

    /**
     * 原子值自动转换为美元字符串（10000原子值=1美元）
     * @param value 待转换的原子值
     * @returns 保留3位小数的美元字符串
     */
    toUsdStrAuto(value: number): string;

    /**
     * 一维数组序列化为字符串（格式：[元素1,元素2,...]）
     * @param values 待序列化的一维数组（可为null）
     * @returns 序列化字符串（null时返回"null"）
     */
    listToStr(values: any[] | null): string;

    /**
     * 二维数组序列化为字符串（格式：[[元素1,元素2],[元素3,元素4],...]）
     * @param values 待序列化的二维数组（可为null）
     * @returns 序列化字符串（null时返回"null"）
     */
    listToStr2(values: any[][] | null): string;

    /**
     * 提取二维数组指定列并序列化为字符串
     * @param values 待处理的二维数组（可为null）
     * @param index 要提取的列索引
     * @returns 列元素序列化字符串（如[[1,2],[3,4]]+index=1 → "[2, 4]"，null时返回"null"）
     */
    list2ToStr(values: any[][] | null, index: number): string;

    /**
     * 检查数组是否包含指定元素（基于Array.includes实现）
     * @param arr 目标数组
     * @param cashIndex 待检查的元素
     * @returns 包含返回true，否则false
     */
    hasArrayKey(arr: any[], cashIndex: any): boolean;

    /**
     * 数字转换为带K/M/B/T/Q单位的简化字符串（固定精度规则）
     * @param v 待转换的数字（支持正负）
     * @returns 带单位的字符串（如1234→"1.2K"，1234567→"1.2M"）
     */
    toKmbtUnitString(v: number): string;

    /**
     * 数字转换为带千分位的字符串（基于正则表达式实现）
     * @param v 待转换的数字
     * @returns 带千分位的字符串（null/undefined时返回空）
     */
    toThousandsTagString(v: number): string;

    /**
     * 检查当前页面路径是否与目标路由匹配（支持路由兼容性匹配）
     * @param targetRoute 目标路由（如"/home"、"/"）
     * @param pathname 当前页面路径（如window.location.pathname）
     * @returns 匹配返回true，否则false（主页"/"需精确匹配，其他路由支持"/home"和"/home/"）
     */
    isCurPathName(targetRoute: string, pathname: string): boolean;

    /**
     * 数字转换为指定小数位数的字符串（截断处理，非四舍五入）
     * @param value 待转换的数字
     * @param keepCount 保留的小数位数（默认2位）
     * @param isTrimZero 是否去除末尾多余0和小数点（默认true）
     * @returns 格式化后的字符串（NaN/无限大时返回"0"）
     */
    NumberToString(value: number, keepCount?: number, isTrimZero?: boolean): string;

    /**
     * 数字转换为带K/M/B/T等单位的字符串（基于对数计算单位，支持自定义小数位）
     * @param value 待转换的数字（支持正负）
     * @param decimals 保留的小数位数（默认1位）
     * @returns 带单位的字符串（如1234→"1.2K"，1234567→"1.2M"）
     */
    ToKMBTUnitString(value: number, decimals?: number): string;

    /**
     * 数字转换为带K/M/B/T等单位的整数字符串（截断小数，仅保留整数部分）
     * @param value 待转换的数字（支持正负）
     * @returns 带单位的整数字符串（如1234→"1K"，1234567→"1M"）
     */
    ToKMBTUnitStringInt(value: number): string;

    /**
     * 数字转换为带千分位的字符串（基于toLocaleString简化实现）
     * @param value 待转换的数字
     * @returns 带千分位的字符串
     */
    ToThousandsString(value: number): string;

    /**
     * 小数精度控制系数表（索引=保留的小数位数，子数组[放大系数, 缩小系数]）
     * 例：索引3（保留3位小数）→ [1000, 0.001]（×1000取整后×0.001恢复精度）
     */
    dotFormats: Record<number, number>[];

    /**
     * 数字转换为指定精度的字符串（截断处理，支持去除末尾0）
     * @param v 待转换的数字
     * @param keepCount 保留的小数位数（默认3位，需与dotFormats索引对应）
     * @param isTrimZero 是否去除末尾多余0和小数点（默认true）
     * @returns 格式化后的字符串
     */
    numberToString(v: number, keepCount?: number, isTrimZero?: boolean): string;

    /**
     * 根据数字大小动态调整显示精度（自适应精度规则）
     * @param v 待处理的数字
     * @returns 格式化后的字符串（≥100→整数，≥10→1位小数，<10→2位小数）
     */
    fixValue(v: number): string;

    /**
     * 数字单位列表（对应数量级：K=10³，M=10⁶，B=10⁹，T=10¹²，Q=10¹⁵，Qi=10¹⁸，S=10²¹）
     */
    units: string[];
}

/**
 * 格式转换工具类（单例实现）
 * 核心能力：
 * 1. 数字格式化：千分位、动态精度、单位换算（K/M/B等）、原子值转业务单位
 * 2. 数组序列化：一维/二维数组转字符串、提取二维数组指定列
 * 3. 路由匹配：判断当前路径与目标路由是否匹配（兼容路由末尾/）
 * 设计特点：所有方法无状态依赖，支持全局统一格式规则，避免重复开发
 */
export class FormatTool implements IFormatTool {
    /**
     * 小数精度控制系数表（索引对应保留的小数位数，子数组[放大系数, 缩小系数]）
     * 作用：通过"×放大系数→取整→×缩小系数"实现精确截断（避免浮点数四舍五入误差）
     */
    dotFormats = [
        [1, 1], // 0位小数：×1（无放大）→ 取整 → ×1（无缩小）
        [10, 0.1], // 1位小数：×10→取整→×0.1
        [100, 0.01], // 2位小数：×100→取整→×0.01
        [1000, 0.001], // 3位小数：×1000→取整→×0.001
        [10000, 0.0001], // 4位小数：×10000→取整→×0.0001
        [100000, 0.00001] // 5位小数：×100000→取整→×0.00001
    ];

    /**
     * 数字单位列表（对应国际通用数量级，用于大数字简化显示）
     * 单位含义：K(千,10³)、M(百万,10⁶)、B(十亿,10⁹)、T(万亿,10¹²)、Q(千万亿,10¹⁵)、Qi(千兆,10¹⁸)、S(万兆,10²¹)
     */
    units = ['K', 'M', 'B', 'T', 'Q', 'Qi', 'S'];

    /**
     * 数字转换为带千分位的字符串（仅处理正数，负数/零返回"0"）
     * @param v 待转换的数字（需≥0，否则返回"0"）
     * @returns 带千分位的字符串（如123456→"123,456"）
     */
    toThousandsString(v: number): string {
        return v <= 0 ? '0' : v.toLocaleString();
    }

    /**
     * 数字×10000后按原子值规则转换为带千分位的字符串
     * 适用场景：原始数据为业务单位，需先转为原子值再格式化（如1.23业务单位→12300原子值）
     * @param v 待转换的业务单位数字
     * @returns 原子值格式化后的带千分位字符串
     */
    toThousandString(v: number): string {
        return this.toThousandAtomString(v * 10000);
    }

    /**
     * 原子值转换为带千分位的业务单位字符串（核心原子值处理逻辑）
     * 原子值定义：内部计算用的最小单位，10000原子值 = 1个业务单位（如10000分=100元）
     * @param atomValue 待转换的原子值
     * @param keepCount 保留的小数位数（默认3位，需与dotFormats索引对应）
     * @returns 带千分位的业务单位字符串（如12345678原子值→"1,235"）
     */
    toThousandAtomString(atomValue: number, keepCount: number = 3): string {
        // 原子值为0时直接返回"0"
        if (atomValue === 0) return '0';

        // 原子值<10000（即业务单位<1）：直接转小数并控制精度
        if (atomValue > -10000 && atomValue < 10000) {
            return this.numberToString(atomValue * 0.0001, keepCount, true);
        }

        // 原子值≥10000：拆分整数部分（业务单位整数）和小数部分（业务单位小数）
        const intSection = Math.floor(atomValue / 10000); // 业务单位整数部分
        const intStr = intSection.toLocaleString(); // 整数部分加千分位
        const delta = atomValue - intSection * 10000; // 剩余原子值（对应业务单位小数）

        // 无小数部分：仅返回整数部分
        if (delta === 0) return intStr;

        // 有小数部分：处理小数并拼接（仅保留小数点及后面的有效数字）
        let decimalStr = this.numberToString(delta * 0.0001, keepCount, true);
        const dotIndex = decimalStr.indexOf('.');
        if (dotIndex !== -1) decimalStr = decimalStr.slice(dotIndex); // 提取".xxx"

        return intStr + decimalStr;
    }

    /**
     * 原子值自动转换为美元字符串（适配金融场景的美元单位）
     * 规则：10000原子值 = 1美元，保留3位小数（满足金融数据精度要求）
     * @param value 待转换的原子值
     * @returns 美元单位字符串（如12345原子值→"1.235"）
     */
    toUsdStrAuto(value: number): string {
        return (value / 10000)?.toFixed(3);
    }

    /**
     * 一维数组序列化为字符串（便于日志打印或数据传输）
     * @param values 待序列化的一维数组（可为null，元素支持任意类型）
     * @returns 序列化字符串（如[1, "a", true]→"[1,a,true]"，null→"null"）
     */
    listToStr(values: any[] | null): string {
        return values == null ? 'null' : `[${values.join(',')}]`;
    }

    /**
     * 二维数组序列化为字符串（保留二维结构）
     * @param values 待序列化的二维数组（可为null，元素支持任意类型）
     * @returns 序列化字符串（如[[1,2],[3,4]]→"[[1,2], [3,4]]"，null→"null"）
     */
    listToStr2(values: any[][] | null): string {
        if (values == null) return 'null';
        const parts = values.map(this.listToStr); // 先序列化每一行
        return `[${parts.join(', ')}]`;
    }

    /**
     * 提取二维数组指定列并序列化为字符串（快速获取某一列数据）
     * @param values 待处理的二维数组（可为null）
     * @param index 要提取的列索引（需≥0且<数组每行长度，否则可能返回undefined）
     * @returns 列元素序列化字符串（如[[1,2],[3,4]]+index=1→"[2, 4]"，null→"null"）
     */
    list2ToStr(values: any[][] | null, index: number): string {
        if (values == null) return 'null';
        return `[${values.map((arr) => arr[index]).join(', ')}]`;
    }

    /**
     * 检查数组是否包含指定元素（基于ES6 Array.includes，支持任意类型元素）
     * @param arr 目标数组（元素类型需与cashIndex一致）
     * @param cashIndex 待检查的元素（严格相等===匹配）
     * @returns 包含返回true，否则false（数组为空返回false）
     */
    hasArrayKey(arr: any[], cashIndex: any): boolean {
        return arr.includes(cashIndex);
    }

    /**
     * 数字转换为带K/M/B/T/Q单位的简化字符串（固定精度规则，适配通用显示场景）
     * 精度规则：通过fixValue动态调整（≥100→整数，≥10→1位小数，<10→2位小数）
     * @param v 待转换的数字（支持正负，会保留符号）
     * @returns 带单位的简化字符串（如-1234→"-1.2K"，1234567→"1.2M"）
     */
    toKmbtUnitString(v: number) {
        const sign = v < 0 ? -1 : 1; // 保留数字符号
        v = Math.abs(v); // 按绝对值处理单位
        let result = '';

        // 按数量级匹配单位
        if (v < 1000) result = v.toString();
        else if (v < 1e6)
            result = this.fixValue(v * 0.001) + 'K'; // 1e6=1000000（百万）
        else if (v < 1e9)
            result = this.fixValue(v * 1e-6) + 'M'; // 1e9=1000000000（十亿）
        else if (v < 1e12)
            result = this.fixValue(v * 1e-9) + 'B'; // 1e12=1万亿
        else if (v < 1e15)
            result = this.fixValue(v * 1e-12) + 'T'; // 1e15=千万亿
        else result = this.fixValue(v * 1e-15) + 'Q'; // ≥1e15用Q单位

        // 恢复符号并返回
        return sign < 0 ? '-' + result : result;
    }

    /**
     * 数字转换为带千分位的字符串（基于正则表达式实现，兼容更多数字场景）
     * 正则逻辑：匹配非开头且后面跟着3的倍数个数字的位置，插入逗号
     * @param v 待转换的数字（支持整数、小数，如1234.56→"1,234.56"）
     * @returns 带千分位的字符串（null/undefined时返回空）
     */
    toThousandsTagString(v: number) {
        return v?.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    /**
     * 检查当前页面路径是否与目标路由匹配（路由兼容性处理）
     * 匹配规则：
     * 1. 目标路由为"/"（主页）：仅精确匹配当前路径为"/"
     * 2. 其他路由：同时匹配"目标路由"（如"/home"）和"目标路由/"（如"/home/"）
     * @param targetRoute 目标路由（如"/"、"/home"）
     * @param pathname 当前页面路径（如window.location.pathname）
     * @returns 匹配返回true，否则false
     */
    isCurPathName(targetRoute: string, pathname: string) {
        if (targetRoute === '/') {
            return pathname === targetRoute; // 主页精确匹配
        }
        if (targetRoute + '/' === pathname) {
            return true; // 匹配带/的路由（如"/home/"）
        }
        return pathname === targetRoute; // 匹配不带/的路由（如"/home"）
    }

    /**
     * 数字转换为指定小数位数的字符串（截断处理，非四舍五入，适配精确显示场景）
     * 核心逻辑：直接截取指定小数位数，不进行四舍五入（如1.239→保留2位→"1.23"）
     * @param value 待转换的数字
     * @param keepCount 保留的小数位数（默认2位）
     * @param isTrimZero 是否去除末尾多余0和小数点（默认true，如"1.20"→"1.2"，"1.00"→"1"）
     * @returns 格式化后的字符串（NaN/无限大时返回"0"）
     */
    NumberToString(value: number, keepCount: number = 2, isTrimZero: boolean = true): string {
        // 处理非数字或无限大的异常情况
        if (isNaN(value) || !isFinite(value)) return '0';

        const str = value.toString();
        const dotIndex = str.indexOf('.'); // 找到小数点位置

        // 无小数部分：直接返回整数字符串
        if (dotIndex === -1) return str;

        // 有小数部分：截取整数部分和指定长度的小数部分
        const intPart = str.slice(0, dotIndex); // 整数部分
        const decPart = str.slice(dotIndex + 1, dotIndex + 1 + keepCount); // 截取指定小数位数
        let result = intPart + (decPart ? '.' + decPart : ''); // 拼接整数和小数

        // 去除末尾多余0和小数点（如需要）
        if (isTrimZero) {
            result = result.replace(/\.?0+$/, ''); // 正则匹配末尾的0和小数点
            if (result === '') result = '0'; // 处理极端情况（如"0.00"→""→"0"）
        }

        return result;
    }

    /**
     * 数字转换为带K/M/B/T等单位的字符串（基于对数计算，灵活适配不同数量级）
     * 核心优势：通过log10计算数量级，无需硬编码判断，支持自定义小数位
     * @param value 待转换的数字（支持正负）
     * @param decimals 保留的小数位数（默认1位）
     * @returns 带单位的字符串（如1234→"1.2K"，1234567890→"1.2B"）
     */
    ToKMBTUnitString(value: number, decimals: number = 1): string {
        const absValue = Math.abs(value);
        // 数字<1000：无需单位，直接返回原数字字符串
        if (absValue < 1000) return value.toString();

        // 计算数量级指数（log10(absValue)/3 → 千=1，百万=2，十亿=3...）
        const exponent = Math.floor(Math.log10(absValue) / 3);
        // 匹配对应的单位（指数-1对应units索引，超出索引默认用"Q"）
        const unit = this.units[exponent - 1] || 'Q';
        // 缩放数字到对应单位（如1234→1234 / 1000^1 = 1.234）
        const scaled = value / Math.pow(1000, exponent);

        // 保留指定小数位并拼接单位
        return `${scaled?.toFixed(decimals)}${unit}`;
    }

    /**
     * 数字转换为带K/M/B/T等单位的整数字符串（截断小数，适配整数显示场景）
     * 逻辑：缩放后取整（Math.floor），不保留小数部分
     * @param value 待转换的数字（支持正负）
     * @returns 带单位的整数字符串（如1234→"1K"，1234567→"1M"）
     */
    ToKMBTUnitStringInt(value: number): string {
        const absValue = Math.abs(value);
        if (absValue < 1000) return value.toString();

        const exponent = Math.floor(Math.log10(absValue) / 3);
        const unit = this.units[exponent - 1] || 'Q';
        const scaled = Math.floor(value / Math.pow(1000, exponent)); // 缩放后取整

        return `${scaled}${unit}`;
    }

    /**
     * 数字转换为带千分位的字符串（基于浏览器原生toLocaleString，简化实现）
     * 优势：自动适配浏览器 locale 规则（如部分地区用"."分隔千分位）
     * @param value 待转换的数字（支持整数、小数）
     * @returns 带千分位的本地化字符串（如123456.78→"123,456.78"）
     */
    ToThousandsString(value: number): string {
        return value.toLocaleString();
    }

    /**
     * 数字转换为指定精度的字符串（基于dotFormats的截断逻辑，避免浮点数误差）
     * 核心优化：通过"放大→取整→缩小"流程，解决浮点数精度问题（如0.1+0.2=0.30000000000000004）
     * @param v 待转换的数字
     * @param keepCount 保留的小数位数（默认3位，需与dotFormats索引对应）
     * @param isTrimZero 是否去除末尾多余0和小数点（默认true）
     * @returns 格式化后的字符串
     */
    numberToString(v: number, keepCount: number = 3, isTrimZero: boolean = true) {
        const format = this.dotFormats[keepCount]; // 获取对应精度的系数
        // 微小偏移量：解决浮点数截断时的精度误差（如2.3339999999999996→×1000→2333.999...→取整2333→×0.001→2.333）
        const offset = v >= 0 ? 1e-14 : -1e-14;
        // 计算流程：×放大系数→取整（Math.trunc去除小数）→×缩小系数→固定小数位数
        let result = (Math.trunc(v * format[0]) * format[1] + offset)?.toFixed(keepCount);

        // 无需去除末尾0：直接返回
        if (!isTrimZero) return result;

        // 无小数部分（不含.或,）：直接返回
        if (!result.includes('.') && !result.includes(',')) return result;

        // 去除末尾多余0（循环删除直到末尾非0）
        while (result.endsWith('0')) {
            result = result.slice(0, -1);
        }

        // 去除末尾的小数点或逗号（如"123."→"123"）
        if (result.endsWith('.') || result.endsWith(',')) {
            result = result.slice(0, -1);
        }

        return result;
    }

    /**
     * 根据数字大小动态调整显示精度（自适应精度，优化不同大小数字的可读性）
     * 精度规则：
     * - 数字≥100：显示整数（无需小数，如123→"123"）
     * - 10≤数字<100：显示1位小数（如12.34→"12.3"）
     * - 数字<10：显示2位小数（如1.234→"1.23"）
     * @param v 待处理的数字
     * @returns 自适应精度的字符串
     */
    fixValue(v: number) {
        if (v >= 100) {
            return Math.floor(v).toFixed(0); // ≥100→取整，0位小数
        } else if (v >= 10) {
            return this.numberToString(v, 1); // 10≤v<100→1位小数
        } else {
            return this.numberToString(v, 2); // <10→2位小数
        }
    }
}

// 导出格式转换工具单例实例
// 全局共享一个实例，确保所有模块使用统一的格式规则（如单位、精度），避免格式不一致
export default new FormatTool();
