import envTool from './env-tool';

/**
 * 通用工具接口
 * 定义通用基础能力的标准方法，涵盖数组操作、类型检查、格式转换、缓存检测等核心功能
 */
export interface ICommonTool {
    /**
     * 随机打乱数组（原地修改）
     * @param array 待打乱的泛型数组
     */
    shuffle<T>(array: T[]): void;

    /**
     * 忽略大小写比较两个字符串是否相等
     * @param str1 第一个字符串
     * @param str2 第二个字符串
     * @returns 相等返回true，否则false
     */
    equalsIgnoreCase(str1: string, str2: string): boolean;

    /**
     * 安全获取数组指定索引的值（处理边界情况）
     * @param args 待取值的数组（可能为null/undefined）
     * @param index 目标索引（需≥0）
     * @param defaultValue 索引无效时的默认值
     * @returns 索引对应的值或默认值
     */
    tryGetArgs<T>(args: any[] | null | undefined, index: number, defaultValue: T): T;

    /**
     * 类型守卫：判断值是否为undefined
     * @param obj 待判断的值（任意类型）
     * @returns 是undefined返回true，否则false
     */
    isUndefined(obj: any): obj is undefined;

    /**
     * 类型守卫：判断值是否为null
     * @param obj 待判断的值（任意类型）
     * @returns 是null返回true，否则false
     */
    isNull(obj: any): obj is null;

    /**
     * 类型守卫：判断值是否为字符串
     * @param obj 待判断的值（任意类型）
     * @returns 是string返回true，否则false
     */
    isString(obj: any): obj is string;

    /**
     * 类型守卫：判断值是否为函数
     * @param obj 待判断的值（任意类型）
     * @returns 是函数返回true，否则false
     */
    isFunction(obj: any): obj is (...args: any[]) => any;

    /**
     * 类型守卫：判断值是否为非null对象（含数组、函数）
     * @param obj 待判断的值（任意类型）
     * @returns 是object且非null返回true，否则false
     */
    isObject(obj: any): obj is object;

    /** 全局对象ID计数器（用于checkObjId方法，给对象分配唯一标识） */
    s_globalId: number;

    /** 角度转弧度的系数（π/180，如90° → π/2 弧度） */
    Deg2Rad: number;

    /** 弧度转角度的系数（180/π，如π/2 弧度 → 90°） */
    Rad2Deg: number;

    /**
     * 角度转换为弧度
     * @param degree 待转换的角度值（如30、90）
     * @returns 对应的弧度值
     */
    toRadian(degree: number): number;

    /**
     * 弧度转换为角度
     * @param radian 待转换的弧度值（如Math.PI/6、Math.PI/2）
     * @returns 对应的角度值
     */
    toDegree(radian: number): number;

    /**
     * 检查数字的二进制位是否包含指定标志位（位运算）
     * @param target 目标数字（需判断的二进制值）
     * @param flag 标志位数字（待检查的二进制位）
     * @returns 包含标志位返回true，否则false
     */
    hasFlag(target: number, flag: number): boolean;

    /**
     * 判断字符串是否为null或空字符串（不含仅空格判断）
     * @param str 待判断的字符串
     * @returns 是null或''返回true，否则false
     */
    isNullOrEmpty(str: string): boolean;

    /**
     * 从数组中移除指定元素（原地修改数组）
     * @param array 目标数组（任意类型）
     * @param item 待移除的元素
     * @returns 移除成功返回true，元素不存在返回false
     */
    arrayRemoveItem(array: any[], item: any): boolean;

    /**
     * 给对象分配唯一ID（通过__s_id属性标识）
     * @param obj 目标对象（任意非null对象）
     * @returns 对象的唯一ID（__s_id的值）
     */
    checkObjId(obj: object): string;

    /**
     * 计算平面直角坐标系中（0,0）到（x,y）的直线距离（勾股定理）
     * @param x 目标点的x轴坐标
     * @param y 目标点的y轴坐标
     * @returns 两点之间的距离值
     */
    distanceXY(x: number, y: number): number;

    /**
     * 深拷贝对象（基于JSON序列化）
     * @param obj 待拷贝的泛型对象（支持JSON可序列化类型）
     * @returns 拷贝后的新对象
     */
    DeepClone<T>(obj: T): T;

    /**
     * 根据枚举值获取对应的枚举名称（适用于“值→名称”映射的枚举）
     * @param enumObj 目标枚举对象（如enum Status { Success=1, Fail=2 }）
     * @param value 待查询的枚举值（如1）
     * @returns 对应的枚举名称（如"Success"），无匹配返回undefined
     */
    getEnumName<T extends { [key: number]: string }>(enumObj: T, value: number): string | undefined;

    /**
     * 检测浏览器是否支持Cache Storage API（离线缓存能力）
     * @returns Promise<boolean> 支持返回true，否则false
     */
    isCachesSupported(): Promise<boolean>;

    /**
     * 类型守卫：判断值是否已定义（非null且非undefined）
     * @param v 待判断的泛型值
     * @returns 已定义返回true，否则false
     */
    isDefined: <T>(v: T | null | undefined) => v is T;
}

/**
 * 通用工具类（单例实现）
 * 核心能力：数组操作（打乱、移除元素）、类型安全检查（类型守卫）、
 * 格式转换（角度/弧度）、对象标识（唯一ID）、缓存兼容性检测等
 * 设计特点：无状态依赖（除envTool环境判断），可全局安全复用
 */
export class CommonTool implements ICommonTool {
    /** 全局对象ID计数器（用于checkObjId，确保每个对象ID唯一） */
    s_globalId = 0;

    /** 角度转弧度的系数（固定值：Math.PI / 180，避免重复计算） */
    Deg2Rad = Math.PI / 180.0;

    /** 弧度转角度的系数（固定值：180 / Math.PI，避免重复计算） */
    Rad2Deg = 180.0 / Math.PI;

    /**
     * 随机打乱数组（Fisher-Yates 洗牌算法）
     * @param array 待打乱的泛型数组
     * @注意 原地修改原数组，若需保留原数组，需先手动拷贝（如[...array]）
     */
    shuffle<T>(array: T[]): void {
        // 从数组末尾向前遍历，每次将当前元素与前面随机位置的元素交换
        for (let i = array.length - 1; i > 0; i--) {
            // 生成[0, i]范围内的随机整数（确保每个位置概率均等）
            const j = Math.floor(Math.random() * (i + 1));
            // 交换i和j位置的元素（ES6解构赋值）
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    /**
     * 忽略大小写比较两个字符串
     * @param str1 第一个字符串（如"Hello"）
     * @param str2 第二个字符串（如"hello"）
     * @returns 忽略大小写后相等返回true，否则false
     */
    equalsIgnoreCase(str1: string, str2: string): boolean {
        // 先将两个字符串转为小写，再比较是否全等
        return str1.toLowerCase() === str2.toLowerCase();
    }

    /**
     * 安全获取数组指定索引的值（处理多种边界情况）
     * 适用场景：不确定数组是否存在、索引是否合法时，避免抛出越界错误
     * @param args 待取值的数组（可能为null/undefined）
     * @param index 目标索引（需≥0，否则返回默认值）
     * @param defaultValue 索引无效时的默认值（确保返回类型安全）
     * @returns 索引有效则返回对应值，否则返回默认值
     */
    tryGetArgs<T>(args: any[] | null | undefined, index: number, defaultValue: T): T {
        // 边界条件判断：数组不存在、索引为负、索引超出数组长度
        if (!args || index < 0 || index >= args.length) {
            return defaultValue;
        }
        // 索引存在但值为undefined时，也返回默认值
        return args[index] !== undefined ? args[index] : defaultValue;
    }

    /**
     * 类型守卫：精确判断值是否为undefined（排除null等其他 falsy 值）
     * @param obj 待判断的值（任意类型）
     * @returns 严格等于undefined返回true，否则false
     */
    isUndefined(obj: any): obj is undefined {
        return obj === undefined;
    }

    /**
     * 类型守卫：精确判断值是否为null（排除undefined等其他 falsy 值）
     * @param obj 待判断的值（任意类型）
     * @returns 严格等于null返回true，否则false
     */
    isNull(obj: any): obj is null {
        return obj === null;
    }

    /**
     * 类型守卫：判断值是否为字符串（排除String对象，仅判断原始类型）
     * @param obj 待判断的值（任意类型）
     * @returns typeof 为"string"返回true，否则false
     */
    isString(obj: any): obj is string {
        return typeof obj === 'string';
    }

    /**
     * 类型守卫：判断值是否为函数（排除箭头函数以外的其他类型）
     * @param obj 待判断的值（任意类型）
     * @returns typeof 为"function"返回true，否则false
     */
    isFunction(obj: any): obj is (...args: any[]) => any {
        return typeof obj === 'function';
    }

    /**
     * 类型守卫：判断值是否为非null的对象（含数组、函数，因typeof数组/函数均为"object"）
     * @param obj 待判断的值（任意类型）
     * @returns typeof 为"object"且非null返回true，否则false
     * @注意 若需严格判断“纯对象”（排除数组/函数），需额外添加 Array.isArray(obj) 和 isFunction(obj) 检查
     */
    isObject(obj: any): obj is object {
        return typeof obj === 'object' && obj !== null;
    }

    /**
     * 角度转换为弧度（用于几何计算，如Canvas绘图、三角函数）
     * @param degree 待转换的角度值（如0°、90°、180°）
     * @returns 对应的弧度值（如0、Math.PI/2、Math.PI）
     */
    toRadian(degree: number): number {
        return degree * this.Deg2Rad;
    }

    /**
     * 弧度转换为角度（用于将计算结果转为人类易读的角度）
     * @param radian 待转换的弧度值（如Math.PI/6、Math.PI）
     * @returns 对应的角度值（如30°、180°）
     */
    toDegree(radian: number): number {
        return radian * this.Rad2Deg;
    }

    /**
     * 检查数字的二进制位是否包含指定标志位（常用于状态位判断）
     * 原理：通过按位与（&）运算，若结果非0则表示包含该标志位
     * @param target 目标数字（如0b1010，即十进制10）
     * @param flag 标志位数字（如0b1000，即十进制8）
     * @returns 包含标志位返回true，否则false
     * @示例 hasFlag(10, 8) → 0b1010 & 0b1000 = 0b1000 → true
     */
    hasFlag(target: number, flag: number): boolean {
        // 按位与运算后，用Boolean转为布尔值（非0为true，0为false）
        return Boolean(target & flag);
    }

    /**
     * 判断字符串是否为null或空字符串（不处理仅含空格的情况）
     * @param str 待判断的字符串（可能为null）
     * @returns 是null或空字符串（''）返回true，否则false
     * @注意 若需判断“空值或仅空格”，需修改为：str == null || str.trim() === ''
     */
    isNullOrEmpty(str: string): boolean {
        return str == null || str === '';
    }

    /**
     * 从数组中移除指定元素（仅移除第一个匹配项，原地修改数组）
     * @param array 目标数组（任意类型，需为引用类型）
     * @param item 待移除的元素（通过严格相等===匹配）
     * @returns 找到并移除元素返回true，元素不存在返回false
     */
    arrayRemoveItem(array: any[], item: any): boolean {
        // 找到元素在数组中的索引（仅第一个匹配项）
        const index = array.indexOf(item);
        // 索引有效（≠-1）时，通过splice移除该元素
        if (index !== -1) {
            array.splice(index, 1); // 从index位置删除1个元素
            return true;
        }
        return false;
    }

    /**
     * 给对象分配唯一ID（通过给对象添加__s_id属性实现）
     * 用途：用于对象标识、缓存key生成等场景，确保每个对象ID唯一
     * @param obj 目标对象（任意非null对象，如{}、[]）
     * @returns 对象的唯一ID（首次调用生成，后续调用直接返回已存在的__s_id）
     * @ts-ignore 忽略__s_id属性不存在的类型检查（因该属性为动态添加）
     */
    checkObjId(obj: Record<any, any>): string {
        // 尝试获取对象已有的__s_id
        const objId: string = obj.__s_id;
        // 若不存在__s_id，生成新ID并赋值给对象
        if (!objId) {
            this.s_globalId++; // 计数器自增（确保ID唯一）
            obj.__s_id = this.s_globalId.toString(); // 存储为字符串类型，避免数字精度问题
            return this.s_globalId.toString();
        }
        // 若已存在__s_id，直接返回
        return objId;
    }

    /**
     * 计算平面直角坐标系中（原点0,0）到目标点（x,y）的直线距离
     * 原理：勾股定理 → 距离 = √(x² + y²)
     * @param x 目标点的x轴坐标（可为正负）
     * @param y 目标点的y轴坐标（可为正负）
     * @returns 两点之间的距离值（非负）
     */
    distanceXY(x: number, y: number): number {
        return Math.sqrt(x * x + y * y);
    }

    /**
     * 深拷贝对象（基于JSON序列化实现，简单轻量）
     * @param obj 待拷贝的泛型对象（支持JSON可序列化类型：对象、数组、基础类型等）
     * @returns 拷贝后的新对象（与原对象完全独立，修改新对象不影响原对象）
     * @注意 不支持以下类型：函数、Symbol、循环引用对象、Date对象（会转为字符串）、RegExp对象（会丢失属性）
     */
    DeepClone<T>(obj: T): T {
        // JSON.stringify：将对象转为JSON字符串（忽略不可序列化属性）
        // JSON.parse：将JSON字符串转为新对象（实现深拷贝）
        return JSON.parse(JSON.stringify(obj));
    }

    /**
     * 根据枚举值获取对应的枚举名称（适用于“数字值→字符串名称”映射的枚举）
     * @param enumObj 目标枚举对象（需满足“值为数字、名称为字符串”的结构，如enum E { A=1, B=2 }）
     * @param value 待查询的枚举值（如1）
     * @returns 对应的枚举名称（如"A"），无匹配值返回undefined
     */
    getEnumName<T extends { [key: number]: string }>(enumObj: T, value: number): string | undefined {
        // 枚举对象的结构为 { 名称: 值, 值: 名称 }，直接通过值取名称
        return enumObj[value];
    }

    /**
     * 检测浏览器是否支持Cache Storage API（用于离线缓存、PWA等场景）
     * 分4步严格检查，确保API可用且功能正常
     * @returns Promise<boolean> 支持返回true，不支持/异常返回false
     */
    async isCachesSupported(): Promise<boolean> {
        try {
            // 1. 基础存在性检查：确保在浏览器环境且window.caches存在
            if (!envTool.isWindow || !('caches' in window)) return false;

            // 2. 安全上下文检查：Cache Storage仅支持HTTPS协议或localhost（避免明文传输风险）
            if (!window.isSecureContext) {
                console.warn('Caches API only supports HTTPS/localhost (Insecure context not supported)');
                return false;
            }

            // 3. 类型存在性检查：确保CacheStorage和Cache构造函数存在（避免部分浏览器实现不完整）
            if (typeof CacheStorage === 'undefined' || typeof Cache === 'undefined') return false;

            // 4. 功能可用性测试：尝试打开一个测试缓存，验证API可正常调用
            const testKey = '__caches_support_test__'; // 测试用的缓存key（避免与业务key冲突）
            const cache = await caches.open(testKey); // 尝试打开缓存
            await caches.delete(testKey); // 清理测试缓存（避免占用存储空间）
            return !!cache; // 缓存对象存在，说明API可用
        } catch (e) {
            // 捕获任何异常（如浏览器权限限制、存储空间不足等）
            console.error('Caches support check failed (Cache Storage check failed):', e);
            return false;
        }
    }

    /**
     * 类型守卫：判断值是否“已定义”（非null且非undefined）
     * 用途：过滤null和undefined，确保后续操作的类型安全
     * @param v 待判断的泛型值（可能为null/undefined）
     * @returns 已定义返回true，否则false
     */
    isDefined = <T>(v: T | null | undefined): v is T => v !== undefined && v !== null;
}

/**
 * 导出通用工具单例实例
 * 全局共享一个实例，确保s_globalId等状态全局唯一，避免重复初始化导致的逻辑冲突
 */
export default new CommonTool();
