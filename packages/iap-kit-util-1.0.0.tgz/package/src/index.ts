import envTool, { EnvTool, type IEnvTool } from './env-tool';
import logTool, { LogTool, type ILogTool } from './log-tool';
import timeTool, { TimeTool, type ITimeTool } from './time-tool';
import formatTool, { FormatTool, type IFormatTool } from './format-tool';
import commonTool, { CommonTool, type ICommonTool } from './common-tool';
import browserTool, { BrowserTool, type IBrowserTool } from './browser-tool';
import communicationTool, { CommunicationTool, type ICommunicationTool } from './communication-tool';
import performanceMonitor, { PerformanceMonitor, type IPerformanceMonitor } from './tools/PerformanceMonitor';
import driveTool, { DriveTool, type IDriveTool } from './drive-tool';

export { PerformanceMonitor, type IPerformanceMonitor };

/**
 * 混入（Mixins）工具函数
 * TypeScript官方推荐的多继承模拟方案，用于将多个基类的原型方法复制到目标类的原型上
 * 核心逻辑：遍历每个基类的原型属性，排除constructor（避免覆盖目标类构造函数），
 * 将基类的方法/属性定义到目标类原型，实现“多继承”效果
 * @param derivedCtor 目标类（要混入其他基类的类，此处为Toolbox）
 * @param baseCtors 待混入的基类数组（EnvTool、LogTool等）
 */
function applyMixins(derivedCtor: any, baseCtors: any[]) {
    baseCtors.forEach((baseCtor) => {
        // 遍历基类原型的所有自有属性（不含继承属性）
        Object.getOwnPropertyNames(baseCtor.prototype).forEach((name) => {
            // 排除constructor：避免基类的构造函数覆盖目标类的构造函数（目标类Toolbox无自定义构造）
            if (name !== 'constructor') {
                // 将基类原型的属性描述符复制到目标类原型
                // 若基类属性不存在描述符，创建空对象避免报错
                Object.defineProperty(
                    derivedCtor.prototype,
                    name,
                    Object.getOwnPropertyDescriptor(baseCtor.prototype, name) || Object.create(null)
                );
            }
        });
    });
}

/**
 * 聚合工具接口（IToolbox）
 * 继承所有子工具的接口（IEnvTool、ILogTool等），确保Toolbox实例拥有所有子工具的方法/属性，
 * 保持与原有调用方式的类型兼容（如Toolbox.isDev、Toolbox.logDebug等）
 */
export interface IToolbox
    extends IEnvTool,
        ILogTool,
        ITimeTool,
        IFormatTool,
        ICommonTool,
        ICommunicationTool,
        IBrowserTool,
        IDriveTool {}

/**
 * 空的Toolbox类（混入目标类）
 * 本身无业务逻辑，仅作为“容器”接收其他基类的混入，
 * 最终通过混入获得所有子工具的方法/属性，实现功能聚合
 */
class Toolbox {}

/**
 * 执行混入操作：将所有子工具基类混入Toolbox
 * 注意：混入顺序决定同名成员的覆盖优先级——**后面的基类会覆盖前面的基类**
 * 例：若EnvTool和LogTool都有startTimeMill属性，LogTool（后混入）的实现会生效
 * 此处顺序：EnvTool → LogTool → TimeTool → FormatTool → CommonTool → CommunicationTool
 */
applyMixins(Toolbox, [EnvTool, LogTool, TimeTool, FormatTool, CommonTool, CommunicationTool, BrowserTool, DriveTool]);

/**
 * 导出独立的子工具实例
 * 兼容“单独使用某个子工具”的场景（如仅用envTool判断环境），
 * 避免因依赖Toolbox聚合类导致的不必要耦合
 */
export {
    envTool,
    logTool,
    timeTool,
    formatTool,
    communicationTool,
    commonTool,
    browserTool,
    performanceMonitor,
    driveTool
};

/**
 * 导出所有子工具的接口类型
 * 供外部模块在需要类型约束时导入使用（如函数参数类型、变量类型定义）
 */
export type { IEnvTool, ILogTool, ITimeTool, IFormatTool, ICommonTool, ICommunicationTool, IBrowserTool, IDriveTool };

/**
 * 创建并导出Toolbox单例实例
 * 通过类型断言（as IToolbox）确保TypeScript识别实例的完整类型，
 * 全局唯一实例，避免多实例导致的状态混乱（如CommonTool的s_globalId计数不一致）
 *
 * ⚠️ 重要注意事项：
 * 1. 混入仅复制基类的**原型方法/属性**，基类的**构造函数不会执行**（如EnvTool的构造逻辑、CommonTool的s_globalId初始化），
 *    若基类有需要构造函数初始化的状态（如实例属性、依赖注入），需手动补充初始化逻辑；
 * 2. 同名成员覆盖风险：若多个基类有同名方法/属性，后混入的基类会覆盖前面的，需提前梳理避免命名冲突；
 * 3. 状态共享问题：混入后Toolbox实例的状态与独立子工具实例（如envTool）不共享，若需全局统一状态，建议优先使用独立子工具实例。
 */
const toolbox: IToolbox = new Toolbox() as IToolbox;
export default toolbox;
